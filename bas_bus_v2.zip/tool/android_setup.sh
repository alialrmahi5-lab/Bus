#!/usr/bin/env bash
# يضيف الصلاحيات والاسم والأيقونة إلى مجلد android المُولَّد تلقائياً.
set -euo pipefail
M=android/app/src/main/AndroidManifest.xml
python3 - "$M" <<'PY'
import re, sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
perms = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
]
add = "".join(f'    <uses-permission android:name="{x}"/>\n' for x in perms if x not in s)
s = s.replace("<application", add + "    <application", 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="باص النجف"', s, count=1)
open(p, "w", encoding="utf-8").write(s)
print("manifest patched")
PY
cp -r android_overlay/res/. android/app/src/main/res/
echo "icons copied"
