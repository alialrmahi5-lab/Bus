import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'package:shared_preferences/shared_preferences.dart';

import '../core/geo.dart';
import '../core/models.dart';

enum Role { passenger, driver, owner }

const double kDwell = 12; // ثوانٍ (زمن محاكاة) للوقوف في كل محطة
const double kDefaultSpeed = 5.5; // م/ث ≈ 20 كم/س

late AppStore store;

class Arrival {
  Arrival(this.line, this.bus, this.secs);
  final BusLine line;
  final Bus bus;
  final double secs;
}

class TripOption {
  TripOption(this.line, this.bus, this.waitSecs, this.rideSecs, this.hops);
  final BusLine line;
  final Bus? bus;
  final double? waitSecs;
  final double rideSecs;
  final int hops;
  double get totalSecs => (waitSecs ?? 1e9) + rideSecs;
}

class AppStore extends ChangeNotifier {
  AppStore._(this._prefs);

  final SharedPreferences _prefs;

  final Map<String, Stop> stops = {};
  final List<BusLine> lines = [];
  final List<Bus> buses = [];
  final List<Report> reports = [];
  final Map<String, List<int>> days = {}; // yyyy-MM-dd -> [ركاب, إيراد]
  final Set<String> favStops = {};
  final Set<String> alerts = {}; // stopId|lineId

  final ValueNotifier<Role> role = ValueNotifier<Role>(Role.passenger);
  final ValueNotifier<ThemeMode> themeMode = ValueNotifier<ThemeMode>(ThemeMode.system);
  bool simEnabled = true;
  double simSpeed = 4;

  LatLng? userPos;
  String? driverBusId;
  bool tripActive = false;
  bool tripGps = false;

  final Map<String, RoutePath> _paths = {};
  final StreamController<String> _msg = StreamController<String>.broadcast();
  Stream<String> get messages => _msg.stream;

  Timer? _timer;
  Timer? _saveTimer;
  DateTime _last = DateTime.now();
  int _ticks = 0;
  StreamSubscription<Position>? _gps;
  final math.Random _rnd = math.Random();

  // ───────────────────────── التحميل والحفظ ─────────────────────────

  static Future<AppStore> load() async {
    final s = AppStore._(await SharedPreferences.getInstance());
    var ok = false;
    final raw = s._prefs.getString('data_v2');
    if (raw != null) {
      try {
        s._fromJson(jsonDecode(raw) as Map<String, dynamic>);
        ok = true;
      } catch (_) {
        ok = false;
      }
    }
    if (!ok) s._seed();
    s.driverBusId ??= s.buses.isEmpty ? null : s.buses.first.id;
    s._timer = Timer.periodic(const Duration(milliseconds: 400), (_) => s._tick());
    unawaited(s.snapPending());
    return s;
  }

  Map<String, dynamic> _toJson() {
    for (final b in buses) {
      final l = lineById(b.lineId);
      final t = l == null ? 0.0 : pathOf(l).total;
      b.frac = t > 0 ? (b.d / t) % 1.0 : 0.0;
    }
    return {
      'v': 2,
      'stops': stops.values.map((s) => s.toJson()).toList(),
      'lines': lines.map((l) => l.toJson()).toList(),
      'buses': buses.map((b) => b.toJson()).toList(),
      'reports': reports.map((r) => r.toJson()).toList(),
      'days': days,
      'fav': favStops.toList(),
      'alerts': alerts.toList(),
      'role': role.value.index,
      'theme': themeMode.value.index,
      'sim': simEnabled,
      'simSpeed': simSpeed,
    };
  }

  void _fromJson(Map<String, dynamic> j) {
    stops.clear();
    lines.clear();
    buses.clear();
    reports.clear();
    days.clear();
    favStops.clear();
    alerts.clear();
    _paths.clear();
    for (final e in (j['stops'] as List<dynamic>)) {
      final s = Stop.fromJson(e as Map<String, dynamic>);
      stops[s.id] = s;
    }
    for (final e in (j['lines'] as List<dynamic>)) {
      final l = BusLine.fromJson(e as Map<String, dynamic>);
      l.stopIds.removeWhere((id) => !stops.containsKey(id));
      if (l.legs.length != l.stopIds.length) {
        l.legs = <List<LatLng>>[];
        l.snapped = false;
      }
      lines.add(l);
    }
    for (final e in (j['buses'] as List<dynamic>)) {
      buses.add(Bus.fromJson(e as Map<String, dynamic>));
    }
    for (final e in (j['reports'] as List<dynamic>? ?? <dynamic>[])) {
      reports.add(Report.fromJson(e as Map<String, dynamic>));
    }
    final d = j['days'] as Map<String, dynamic>? ?? <String, dynamic>{};
    d.forEach((k, v) {
      final l = (v as List<dynamic>).map((x) => (x as num).toInt()).toList();
      if (l.length == 2) days[k] = l;
    });
    for (final e in (j['fav'] as List<dynamic>? ?? <dynamic>[])) {
      favStops.add(e as String);
    }
    for (final e in (j['alerts'] as List<dynamic>? ?? <dynamic>[])) {
      alerts.add(e as String);
    }
    final r = (j['role'] as num?)?.toInt() ?? 0;
    role.value = Role.values[r.clamp(0, Role.values.length - 1).toInt()];
    final t = (j['theme'] as num?)?.toInt() ?? 0;
    themeMode.value = ThemeMode.values[t.clamp(0, ThemeMode.values.length - 1).toInt()];
    simEnabled = j['sim'] as bool? ?? true;
    simSpeed = (j['simSpeed'] as num?)?.toDouble() ?? 4;
    for (final b in buses) {
      final l = lineById(b.lineId);
      b.d = l == null ? 0.0 : b.frac * pathOf(l).total;
    }
  }

  void _save() {
    try {
      _prefs.setString('data_v2', jsonEncode(_toJson()));
    } catch (_) {}
  }

  void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 700), _save);
  }

  void _seed() {
    stops.clear();
    lines.clear();
    buses.clear();
    reports.clear();
    days.clear();
    favStops.clear();
    alerts.clear();
    _paths.clear();
    void s(String id, String name, double la, double lo) => stops[id] = Stop(id, name, LatLng(la, lo));
    // مواقع تقريبية للتجربة فقط — يضبطها المالك من لوحة الخطوط.
    s('center', 'مركز النجف', 32.0003, 44.3148);
    s('rawan', 'محطة شارع الروان', 31.9990, 44.3290);
    s('ameer', 'محطة حي الأمير', 31.9960, 44.3560);
    s('airport', 'محطة المطار', 31.9899, 44.4043);
    s('univ', 'محطة الجامعة', 32.0180, 44.3250);
    s('t2', 'محطة تجريبية ٢', 32.0100, 44.3050);
    s('t3', 'محطة تجريبية ٣', 32.0020, 44.3010);
    lines.add(BusLine(
      id: 'l1',
      name: 'الخط الأول — المطار',
      colorValue: 0xFF0B7A62,
      fare: 1000,
      stopIds: ['center', 'rawan', 'ameer', 'airport'],
    ));
    lines.add(BusLine(
      id: 'l2',
      name: 'الخط الثاني — الجامعة',
      colorValue: 0xFFE07B00,
      fare: 750,
      stopIds: ['center', 'univ', 't2', 't3'],
    ));
    buses.addAll([
      Bus(id: 'b1', number: '101', driver: 'سائق تجريبي ١', lineId: 'l1', frac: 0.05, speed: 5.8, onboard: 8),
      Bus(id: 'b2', number: '102', driver: 'سائق تجريبي ٢', lineId: 'l1', frac: 0.55, speed: 5.2, onboard: 21),
      Bus(id: 'b3', number: '201', driver: 'سائق تجريبي ٣', lineId: 'l2', frac: 0.30, speed: 6.0, onboard: 14),
      Bus(id: 'b4', number: '202', driver: 'سائق تجريبي ٤', lineId: 'l2', frac: 0.80, speed: 5.4, onboard: 3),
    ]);
    for (final b in buses) {
      final l = lineById(b.lineId);
      b.d = l == null ? 0.0 : b.frac * pathOf(l).total;
    }
    _scheduleSave();
  }

  // ───────────────────────── استعلامات ─────────────────────────

  BusLine? lineById(String? id) {
    if (id == null) return null;
    for (final l in lines) {
      if (l.id == id) return l;
    }
    return null;
  }

  Bus? busById(String? id) {
    if (id == null) return null;
    for (final b in buses) {
      if (b.id == id) return b;
    }
    return null;
  }

  RoutePath pathOf(BusLine l) {
    return _paths.putIfAbsent(l.id, () {
      final pts = <LatLng>[];
      for (final id in l.stopIds) {
        final s = stops[id];
        if (s != null) pts.add(s.pos);
      }
      return RoutePath.build(pts, l.legs);
    });
  }

  void _invalidate(BusLine l) => _paths.remove(l.id);

  bool isLive(Bus b) {
    if (!b.online || lineById(b.lineId) == null) return false;
    return b.sim ? simEnabled : b.livePos != null;
  }

  LatLng? busPos(Bus b) {
    if (!b.sim && b.livePos != null) return b.livePos;
    final l = lineById(b.lineId);
    if (l == null) return null;
    final p = pathOf(l);
    if (p.pts.isEmpty) return null;
    return p.pointAt(b.d);
  }

  List<Stop> servedStops() {
    final ids = <String>{};
    for (final l in lines) {
      ids.addAll(l.stopIds);
    }
    final out = ids.map((id) => stops[id]).whereType<Stop>().toList();
    out.sort((a, b) => a.name.compareTo(b.name));
    return out;
  }

  Stop? nearestStop(LatLng p) {
    Stop? best;
    var bd = double.infinity;
    for (final s in servedStops()) {
      final d = haversine(p, s.pos);
      if (d < bd) {
        bd = d;
        best = s;
      }
    }
    return best;
  }

  /// فهرس المحطة التالية للباص على خطه.
  int? nextStopIndex(Bus b) {
    final l = lineById(b.lineId);
    if (l == null) return null;
    final p = pathOf(l);
    if (p.total <= 0 || p.stopDist.length != l.stopIds.length) return null;
    int? bi;
    var best = double.infinity;
    for (var i = 0; i < p.stopDist.length; i++) {
      var a = p.ahead(b.d, p.stopDist[i]);
      if (a < 0.5) {
        if (b.dwell > 0) {
          a = 0;
        } else {
          a += p.total;
        }
      }
      if (a < best) {
        best = a;
        bi = i;
      }
    }
    return bi;
  }

  double _scale(Bus b) => b.sim ? simSpeed : 1.0;

  double? _eta(Bus b, RoutePath p, int stopIdx) {
    if (!b.online || b.fault || p.total <= 0) return null;
    final sc = _scale(b);
    final sp = math.max(2.0, b.speed) * sc;
    var a = p.ahead(b.d, p.stopDist[stopIdx]);
    final dwelling = b.dwell > 0;
    if (a < 0.5 && dwelling) return b.dwell / sc;
    if (a < 0.5) a += p.total;
    var between = 0;
    for (var i = 0; i < p.stopDist.length; i++) {
      if (i == stopIdx) continue;
      final x = p.ahead(b.d, p.stopDist[i]);
      if (x > 0.5 && x < a) between++;
    }
    final double extra = (dwelling ? b.dwell : 0.0) + between * kDwell;
    return a / sp + extra / sc;
  }

  double? etaTo(Bus b, String stopId) {
    final l = lineById(b.lineId);
    if (l == null) return null;
    final idx = l.stopIds.indexOf(stopId);
    final p = pathOf(l);
    if (idx < 0 || p.stopDist.length != l.stopIds.length) return null;
    return _eta(b, p, idx);
  }

  List<Arrival> arrivalsAt(String stopId, {String? lineId}) {
    final out = <Arrival>[];
    for (final l in lines) {
      if (lineId != null && l.id != lineId) continue;
      final idx = l.stopIds.indexOf(stopId);
      if (idx < 0) continue;
      final p = pathOf(l);
      if (p.stopDist.length != l.stopIds.length) continue;
      for (final b in buses) {
        if (b.lineId != l.id || !isLive(b)) continue;
        final e = _eta(b, p, idx);
        if (e != null) out.add(Arrival(l, b, e));
      }
    }
    out.sort((x, y) => x.secs.compareTo(y.secs));
    return out;
  }

  List<TripOption> plan(String fromId, String toId) {
    final out = <TripOption>[];
    for (final l in lines) {
      final i = l.stopIds.indexOf(fromId);
      final j = l.stopIds.indexOf(toId);
      if (i < 0 || j < 0 || i == j) continue;
      final p = pathOf(l);
      if (p.stopDist.length != l.stopIds.length || p.total <= 0) continue;
      final rideDist = p.ahead(p.stopDist[i], p.stopDist[j]);
      final hops = (j - i) % l.stopIds.length;
      final arr = arrivalsAt(fromId, lineId: l.id);
      final best = arr.isEmpty ? null : arr.first;
      final sc = best == null ? simSpeed : _scale(best.bus);
      final sp = math.max(2.0, best?.bus.speed ?? kDefaultSpeed) * sc;
      final ride = rideDist / sp + (hops - 1) * kDwell / sc;
      out.add(TripOption(l, best?.bus, best?.secs, ride, hops));
    }
    out.sort((a, b) => a.totalSecs.compareTo(b.totalSecs));
    return out;
  }

  // ───────────────────────── المحاكاة ─────────────────────────

  void _tick() {
    final now = DateTime.now();
    var dt = now.difference(_last).inMilliseconds / 1000.0;
    _last = now;
    if (dt > 2) dt = 2;
    var changed = false;
    if (simEnabled) {
      final sdt = dt * simSpeed;
      for (final b in buses) {
        if (!b.sim || !b.online || b.fault) continue;
        final l = lineById(b.lineId);
        if (l == null) continue;
        final p = pathOf(l);
        if (p.total <= 0 || p.stopDist.length < 2) continue;
        _advance(b, p, sdt);
        changed = true;
      }
    }
    _checkAlerts();
    _ticks++;
    if (_ticks % 40 == 0) _save();
    if (changed) notifyListeners();
  }

  void _advance(Bus b, RoutePath p, double sdt) {
    var t = sdt;
    if (b.dwell > 0) {
      if (b.dwell >= t) {
        b.dwell -= t;
        return;
      }
      t -= b.dwell;
      b.dwell = 0;
    }
    final step = b.speed * t;
    var best = double.infinity;
    for (final sd in p.stopDist) {
      final a = p.ahead(b.d, sd);
      if (a > 0.01 && a < best) best = a;
    }
    if (best <= step) {
      b.d = (b.d + best) % p.total;
      b.dwell = kDwell;
      final delta = _rnd.nextInt(7) - 3;
      b.onboard = (b.onboard + delta).clamp(0, b.capacity).toInt();
    } else {
      b.d = (b.d + step) % p.total;
    }
  }

  void _checkAlerts() {
    if (alerts.isEmpty) return;
    for (final k in alerts.toList()) {
      final parts = k.split('|');
      if (parts.length != 2) {
        alerts.remove(k);
        continue;
      }
      final arr = arrivalsAt(parts[0], lineId: parts[1]);
      if (arr.isNotEmpty && arr.first.secs <= 120) {
        alerts.remove(k);
        final st = stops[parts[0]];
        final l = lineById(parts[1]);
        HapticFeedback.heavyImpact();
        _msg.add('🚌 ${l?.shortName ?? 'الباص'} يقترب من «${st?.name ?? ''}» — أقل من دقيقتين');
        _scheduleSave();
      }
    }
  }

  // ───────────────────────── الموقع و GPS ─────────────────────────

  Future<String?> _ensurePermission() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        return 'فعّل خدمة الموقع من إعدادات الهاتف.';
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        return 'يرجى السماح للتطبيق بالوصول إلى الموقع.';
      }
      return null;
    } catch (_) {
      return 'تعذّر الوصول إلى خدمة الموقع.';
    }
  }

  /// يحدّد موقع المستخدم؛ يعيد رسالة خطأ أو null عند النجاح.
  Future<String?> locate() async {
    final err = await _ensurePermission();
    if (err != null) return err;
    try {
      final p = await Geolocator.getCurrentPosition().timeout(const Duration(seconds: 20));
      userPos = LatLng(p.latitude, p.longitude);
      notifyListeners();
      return null;
    } catch (_) {
      return 'تعذّر تحديد موقعك، حاول في مكان مكشوف.';
    }
  }

  void _startGps() {
    _gps?.cancel();
    _gps = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 5),
    ).listen(_onGps, onError: (Object _) {});
  }

  void _stopGps() {
    _gps?.cancel();
    _gps = null;
  }

  void _onGps(Position p) {
    final pos = LatLng(p.latitude, p.longitude);
    userPos = pos;
    final b = busById(driverBusId);
    if (b != null && tripActive && tripGps) {
      b.livePos = pos;
      b.dwell = 0;
      if (p.speed.isFinite && p.speed > 0.5) b.speed = 0.7 * b.speed + 0.3 * p.speed;
      final l = lineById(b.lineId);
      if (l != null) {
        final pr = pathOf(l).nearest(pos);
        if (pr.off < 200) b.d = pr.along;
      }
    }
    notifyListeners();
  }

  // ───────────────────────── السائق ─────────────────────────

  void selectDriverBus(String id) {
    if (tripActive) return;
    driverBusId = id;
    notifyListeners();
  }

  Future<String?> startTrip(String busId, bool gps) async {
    final b = busById(busId);
    if (b == null) return 'اختر باصاً أولاً.';
    if (lineById(b.lineId) == null) return 'هذا الباص غير مرتبط بخط سير.';
    if (gps) {
      final err = await _ensurePermission();
      if (err != null) return err;
    }
    driverBusId = busId;
    tripActive = true;
    tripGps = gps;
    b.online = true;
    b.sim = !gps;
    b.livePos = null;
    if (gps) {
      _startGps();
    } else {
      _stopGps();
    }
    _scheduleSave();
    notifyListeners();
    return null;
  }

  void endTrip() {
    final b = busById(driverBusId);
    _stopGps();
    if (b != null) {
      b.sim = true;
      b.livePos = null;
    }
    tripActive = false;
    tripGps = false;
    _scheduleSave();
    notifyListeners();
  }

  String get todayKey {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  List<int> statsOf(DateTime day) {
    final k = '${day.year}-${day.month.toString().padLeft(2, '0')}-${day.day.toString().padLeft(2, '0')}';
    return days[k] ?? <int>[0, 0];
  }

  void boardPassenger(Bus b) {
    final l = lineById(b.lineId);
    final st = days.putIfAbsent(todayKey, () => <int>[0, 0]);
    st[0] += 1;
    st[1] += l?.fare ?? 0;
    b.onboard = math.min(b.onboard + 1, 999);
    _scheduleSave();
    notifyListeners();
  }

  void alightPassenger(Bus b) {
    b.onboard = math.max(0, b.onboard - 1);
    _scheduleSave();
    notifyListeners();
  }

  void addReport(String busId, String type, String note) {
    reports.insert(
      0,
      Report(
        id: 'r${DateTime.now().microsecondsSinceEpoch}',
        ts: DateTime.now().millisecondsSinceEpoch,
        busId: busId,
        type: type,
        note: note,
      ),
    );
    final b = busById(busId);
    if (b != null && type == kReportTypes.first) b.fault = true;
    _scheduleSave();
    notifyListeners();
  }

  void resolveReport(Report r) {
    r.resolved = true;
    final b = busById(r.busId);
    if (b != null) {
      final stillBroken = reports.any((x) => !x.resolved && x.busId == b.id && x.type == kReportTypes.first);
      if (!stillBroken) b.fault = false;
    }
    _scheduleSave();
    notifyListeners();
  }

  // ───────────────────────── المالك: الأسطول والخطوط ─────────────────────────

  void upsertBus(Bus? old, {required String number, required String driver, required String lineId, required int capacity}) {
    if (old != null) {
      final changedLine = old.lineId != lineId;
      old.number = number;
      old.driver = driver;
      old.capacity = capacity;
      old.lineId = lineId;
      if (changedLine) {
        old.d = 0;
        old.dwell = 0;
      }
    } else {
      final b = Bus(
        id: 'b${DateTime.now().microsecondsSinceEpoch}',
        number: number,
        driver: driver,
        lineId: lineId,
        capacity: capacity,
        speed: 5.0 + _rnd.nextDouble() * 1.5,
        frac: _rnd.nextDouble(),
      );
      final l = lineById(lineId);
      b.d = l == null ? 0.0 : b.frac * pathOf(l).total;
      buses.add(b);
      driverBusId ??= b.id;
    }
    _scheduleSave();
    notifyListeners();
  }

  void deleteBus(Bus b) {
    if (tripActive && driverBusId == b.id) endTrip();
    buses.remove(b);
    if (driverBusId == b.id) driverBusId = buses.isEmpty ? null : buses.first.id;
    _scheduleSave();
    notifyListeners();
  }

  void setBusOnline(Bus b, bool v) {
    b.online = v;
    _scheduleSave();
    notifyListeners();
  }

  BusLine saveLine(
    BusLine? old, {
    required String name,
    required int fare,
    required int colorValue,
    required List<String> stopIds,
    required Map<String, Stop> stopsMap,
  }) {
    for (final id in stopIds) {
      final s = stopsMap[id];
      if (s != null) stops[id] = s;
    }
    final l = old ??
        BusLine(
          id: 'l${DateTime.now().millisecondsSinceEpoch}',
          name: name,
          colorValue: colorValue,
          fare: fare,
          stopIds: <String>[],
        );
    final changed = old == null || l.stopIds.join(',') != stopIds.join(',');
    l.name = name;
    l.fare = fare;
    l.colorValue = colorValue;
    if (changed) {
      final onLine = buses.where((b) => b.lineId == l.id).toList();
      final fracs = <String, double>{};
      final oldTotal = pathOf(l).total;
      for (final b in onLine) {
        fracs[b.id] = oldTotal > 0 ? (b.d / oldTotal) % 1.0 : 0.0;
      }
      l.stopIds = List<String>.from(stopIds);
      l.legs = <List<LatLng>>[];
      l.snapped = false;
      _invalidate(l);
      final nt = pathOf(l).total;
      for (final b in onLine) {
        b.d = (fracs[b.id] ?? 0.0) * nt;
        b.dwell = 0;
      }
    }
    if (old == null) lines.add(l);
    _gcStops();
    _scheduleSave();
    notifyListeners();
    return l;
  }

  void deleteLine(BusLine l) {
    lines.remove(l);
    _paths.remove(l.id);
    for (final b in buses) {
      if (b.lineId == l.id) b.lineId = '';
    }
    if (tripActive && busById(driverBusId)?.lineId == '') endTrip();
    _gcStops();
    _scheduleSave();
    notifyListeners();
  }

  void _gcStops() {
    final used = <String>{};
    for (final l in lines) {
      used.addAll(l.stopIds);
    }
    stops.removeWhere((k, v) => !used.contains(k));
    favStops.removeWhere((k) => !used.contains(k));
    alerts.removeWhere((k) => !used.contains(k.split('|').first));
  }

  /// يجلب هندسة الطرق الحقيقية لخط ويستبدل الخطوط المستقيمة.
  Future<bool> snapLine(BusLine l, {bool announce = false}) async {
    final ids = List<String>.from(l.stopIds);
    final pts = <LatLng>[];
    for (final id in ids) {
      final s = stops[id];
      if (s == null) return false;
      pts.add(s.pos);
    }
    if (pts.length < 2) return false;
    final legs = <List<LatLng>>[];
    var okCount = 0;
    for (var i = 0; i < pts.length; i++) {
      final a = pts[i];
      final b = pts[(i + 1) % pts.length];
      final g = await osrmLeg(a, b);
      if (g != null) {
        legs.add(g);
        okCount++;
      } else {
        legs.add(<LatLng>[a, b]);
      }
    }
    if (ids.join(',') != l.stopIds.join(',') || !lines.contains(l)) return false;
    if (okCount == 0) {
      if (announce) _msg.add('تعذّر الاتصال بخدمة الطرق؛ سيُرسم الخط مستقيماً بين المحطات.');
      return false;
    }
    final old = pathOf(l).total;
    l.legs = legs;
    l.snapped = okCount == pts.length;
    _invalidate(l);
    final nw = pathOf(l).total;
    if (old > 0) {
      for (final b in buses) {
        if (b.lineId == l.id) b.d = b.d / old * nw;
      }
    }
    if (announce) _msg.add('تم تثبيت «${l.shortName}» على الطرق الفعلية ✓');
    _scheduleSave();
    notifyListeners();
    return true;
  }

  Future<void> snapPending() async {
    for (final l in List<BusLine>.from(lines)) {
      if (!l.snapped && l.stopIds.length >= 2) await snapLine(l);
    }
  }

  // ───────────────────────── المفضلة والتنبيهات ─────────────────────────

  void toggleFav(String stopId) {
    if (!favStops.remove(stopId)) favStops.add(stopId);
    _scheduleSave();
    notifyListeners();
  }

  void toggleAlert(String stopId, String lineId) {
    final k = '$stopId|$lineId';
    if (!alerts.remove(k)) {
      alerts.add(k);
      _msg.add('سنُنبّهك عندما يقترب الباص من المحطة (أثناء فتح التطبيق).');
    }
    _scheduleSave();
    notifyListeners();
  }

  // ───────────────────────── الإعدادات والبيانات ─────────────────────────

  void setRole(Role r) {
    role.value = r;
    _scheduleSave();
  }

  void setTheme(ThemeMode m) {
    themeMode.value = m;
    _scheduleSave();
  }

  void setSim(bool v) {
    simEnabled = v;
    _scheduleSave();
    notifyListeners();
  }

  void setSimSpeed(double v) {
    simSpeed = v;
    _scheduleSave();
    notifyListeners();
  }

  String exportJson() => const JsonEncoder.withIndent('  ').convert(_toJson());

  bool importJson(String text) {
    final backup = _toJson();
    try {
      final j = jsonDecode(text) as Map<String, dynamic>;
      if (j['lines'] is! List || j['stops'] is! List) return false;
      _fromJson(j);
      driverBusId = buses.isEmpty ? null : buses.first.id;
      tripActive = false;
      _scheduleSave();
      notifyListeners();
      unawaited(snapPending());
      return true;
    } catch (_) {
      _fromJson(backup);
      return false;
    }
  }

  void resetDemo() {
    if (tripActive) endTrip();
    _seed();
    driverBusId = buses.first.id;
    notifyListeners();
    unawaited(snapPending());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _saveTimer?.cancel();
    _gps?.cancel();
    _msg.close();
    super.dispose();
  }
}
