import 'package:flutter/material.dart';

const Color kGreen = Color(0xFF0B7A62);
const Color kGold = Color(0xFFE9A800);
const List<int> kLineColors = <int>[
  0xFF0B7A62, 0xFFE07B00, 0xFF2563EB, 0xFF9333EA, 0xFFDC2626, 0xFF0891B2,
];

ThemeData buildTheme(Brightness b) {
  final scheme = ColorScheme.fromSeed(seedColor: kGreen, brightness: b);
  final dark = b == Brightness.dark;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    fontFamily: 'Cairo',
    scaffoldBackgroundColor: dark ? const Color(0xFF0D1311) : const Color(0xFFF3F7F5),
    appBarTheme: AppBarTheme(
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: dark ? const Color(0xFF0D1311) : const Color(0xFFF3F7F5),
      foregroundColor: scheme.onSurface,
      titleTextStyle: TextStyle(
        fontFamily: 'Cairo',
        fontWeight: FontWeight.w700,
        fontSize: 20,
        color: scheme.onSurface,
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      height: 66,
      backgroundColor: scheme.surface,
      indicatorColor: scheme.primaryContainer,
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
