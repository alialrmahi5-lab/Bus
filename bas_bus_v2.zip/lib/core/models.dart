import 'package:latlong2/latlong.dart' show LatLng;

const List<String> kReportTypes = <String>[
  'عطل ميكانيكي',
  'حادث',
  'ازدحام مروري',
  'تأخير',
  'أخرى',
];

class Stop {
  Stop(this.id, this.name, this.pos);
  final String id;
  String name;
  LatLng pos;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'lat': pos.latitude,
        'lng': pos.longitude,
      };

  factory Stop.fromJson(Map<String, dynamic> j) => Stop(
        j['id'] as String,
        j['name'] as String,
        LatLng((j['lat'] as num).toDouble(), (j['lng'] as num).toDouble()),
      );
}

/// خط دائري: يمرّ بالمحطات بالترتيب ثم يعود إلى المحطة الأولى.
class BusLine {
  BusLine({
    required this.id,
    required this.name,
    required this.colorValue,
    required this.fare,
    required this.stopIds,
    List<List<LatLng>>? legs,
    this.snapped = false,
  }) : legs = legs ?? <List<LatLng>>[];

  final String id;
  String name;
  int colorValue;
  int fare;
  List<String> stopIds;
  List<List<LatLng>> legs; // هندسة الطريق بين كل محطتين متتاليتين
  bool snapped;

  String get shortName => name.split(' — ').first;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'color': colorValue,
        'fare': fare,
        'stops': stopIds,
        'snapped': snapped,
        'legs': legs
            .map((leg) => leg
                .map((p) => [
                      double.parse(p.latitude.toStringAsFixed(5)),
                      double.parse(p.longitude.toStringAsFixed(5)),
                    ])
                .toList())
            .toList(),
      };

  factory BusLine.fromJson(Map<String, dynamic> j) {
    final legs = <List<LatLng>>[];
    for (final leg in (j['legs'] as List<dynamic>? ?? <dynamic>[])) {
      final pts = <LatLng>[];
      for (final p in (leg as List<dynamic>)) {
        final xy = p as List<dynamic>;
        pts.add(LatLng((xy[0] as num).toDouble(), (xy[1] as num).toDouble()));
      }
      legs.add(pts);
    }
    return BusLine(
      id: j['id'] as String,
      name: j['name'] as String,
      colorValue: j['color'] as int,
      fare: (j['fare'] as num).toInt(),
      stopIds: (j['stops'] as List<dynamic>).map((e) => e as String).toList(),
      legs: legs,
      snapped: j['snapped'] as bool? ?? false,
    );
  }
}

class Bus {
  Bus({
    required this.id,
    required this.number,
    required this.driver,
    required this.lineId,
    this.capacity = 30,
    this.sim = true,
    this.online = true,
    this.speed = 5.5,
    this.frac = 0,
    this.onboard = 0,
    this.fault = false,
  });

  final String id;
  String number;
  String driver;
  String lineId;
  int capacity;
  bool sim; // true = حركة محاكاة، false = موقع GPS حقيقي من هاتف السائق
  bool online;
  bool fault;
  double speed; // م/ث
  double frac; // نسبة التقدّم على الخط (للحفظ فقط)
  int onboard;

  // حالة وقت التشغيل
  double d = 0; // المسافة المقطوعة على الخط (متر)
  double dwell = 0; // ثوانٍ متبقية للوقوف في المحطة
  LatLng? livePos;

  double get loadRatio => capacity <= 0 ? 0 : onboard / capacity;
  String get loadLabel => loadRatio < 0.4 ? 'خفيف' : (loadRatio < 0.8 ? 'متوسط' : 'مزدحم');

  Map<String, dynamic> toJson() => {
        'id': id,
        'number': number,
        'driver': driver,
        'lineId': lineId,
        'capacity': capacity,
        'sim': sim,
        'online': online,
        'fault': fault,
        'speed': speed,
        'frac': frac,
        'onboard': onboard,
      };

  factory Bus.fromJson(Map<String, dynamic> j) => Bus(
        id: j['id'] as String,
        number: j['number'] as String,
        driver: j['driver'] as String? ?? '',
        lineId: j['lineId'] as String? ?? '',
        capacity: (j['capacity'] as num?)?.toInt() ?? 30,
        sim: j['sim'] as bool? ?? true,
        online: j['online'] as bool? ?? true,
        fault: j['fault'] as bool? ?? false,
        speed: (j['speed'] as num?)?.toDouble() ?? 5.5,
        frac: (j['frac'] as num?)?.toDouble() ?? 0,
        onboard: (j['onboard'] as num?)?.toInt() ?? 0,
      );
}

class Report {
  Report({
    required this.id,
    required this.ts,
    required this.busId,
    required this.type,
    required this.note,
    this.resolved = false,
  });

  final String id;
  final int ts;
  final String busId;
  final String type;
  final String note;
  bool resolved;

  Map<String, dynamic> toJson() => {
        'id': id,
        'ts': ts,
        'busId': busId,
        'type': type,
        'note': note,
        'resolved': resolved,
      };

  factory Report.fromJson(Map<String, dynamic> j) => Report(
        id: j['id'] as String,
        ts: (j['ts'] as num).toInt(),
        busId: j['busId'] as String,
        type: j['type'] as String,
        note: j['note'] as String? ?? '',
        resolved: j['resolved'] as bool? ?? false,
      );
}
