import 'package:flutter/material.dart';

import '../core/models.dart';
import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

class DriverPage extends StatefulWidget {
  const DriverPage({super.key});

  @override
  State<DriverPage> createState() => _DriverPageState();
}

class _DriverPageState extends State<DriverPage> {
  bool _gps = false;
  String _type = kReportTypes.first;
  final TextEditingController _note = TextEditingController();

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickBus() async {
    final id = await showSheet<String>(
      context,
      (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text('اختر باصك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            ),
          ),
          Flexible(
            child: ListView(shrinkWrap: true, children: [
              for (final b in store.buses)
                ListTile(
                  leading: const Icon(Icons.directions_bus_rounded),
                  title: Text('باص ${b.number}'),
                  subtitle: Text(store.lineById(b.lineId)?.name ?? 'بلا خط'),
                  onTap: () => Navigator.pop(c, b.id),
                ),
            ]),
          ),
        ]),
      ),
    );
    if (id != null) store.selectDriverBus(id);
  }

  Future<void> _start(Bus b) async {
    final err = await store.startTrip(b.id, _gps);
    if (err != null && mounted) snack(context, err);
  }

  void _sendReport(Bus b) {
    store.addReport(b.id, _type, _note.text.trim());
    _note.clear();
    snack(context, 'تم إرسال البلاغ إلى إدارة الأسطول.');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final b = store.busById(store.driverBusId);
        final l = b == null ? null : store.lineById(b.lineId);
        final active = store.tripActive;
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Panel(
            onTap: active ? null : _pickBus,
            child: Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: (l == null ? cs.primary : lineColor(l)).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(Icons.directions_bus_rounded, color: l == null ? cs.primary : lineColor(l), size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(b == null ? 'لم تختر باصاً' : 'باص ${b.number}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  if (l != null) LineBadge(l) else Text('اضغط لاختيار الباص', style: TextStyle(color: cs.onSurfaceVariant)),
                ]),
              ),
              if (!active) Icon(Icons.unfold_more_rounded, color: cs.onSurfaceVariant),
            ]),
          ),
          const SizedBox(height: 14),
          if (b == null || l == null)
            Panel(
              child: Text(
                'لا يوجد باص مرتبط بخط. اطلب من المالك إضافة باص وربطه بخط سير.',
                style: TextStyle(color: cs.onSurfaceVariant),
              ),
            )
          else ...[
            if (!active) ...[
              Panel(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('وضع الرحلة', style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment<bool>(value: false, label: Text('محاكاة'), icon: Icon(Icons.auto_mode_rounded)),
                      ButtonSegment<bool>(value: true, label: Text('GPS حقيقي'), icon: Icon(Icons.gps_fixed_rounded)),
                    ],
                    selected: <bool>{_gps},
                    onSelectionChanged: (s) => setState(() => _gps = s.first),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _gps
                        ? 'يُرسل موقع هاتفك ليتحرك الباص على الخريطة الحقيقية (يُحفظ محلياً حتى ربط الخادم).'
                        : 'يتحرك الباص تلقائياً لتجربة الواجهات دون الحاجة إلى GPS.',
                    style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                  ),
                ]),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('ابدأ الرحلة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  onPressed: () => _start(b),
                ),
              ),
            ] else ...[
              _NextStopCard(bus: b, line: l),
              const SizedBox(height: 12),
              _Counter(bus: b, line: l),
              const SizedBox(height: 12),
              SizedBox(
                height: 50,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFDC2626)),
                  icon: const Icon(Icons.stop_circle_rounded),
                  label: const Text('إنهاء الرحلة', style: TextStyle(fontWeight: FontWeight.w800)),
                  onPressed: store.endTrip,
                ),
              ),
            ],
            const SizedBox(height: 18),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 4),
              child: Text('الإبلاغ عن عطل', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            const SizedBox(height: 8),
            Panel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Wrap(spacing: 8, runSpacing: 6, children: [
                  for (final t in kReportTypes)
                    ChoiceChip(label: Text(t), selected: _type == t, onSelected: (_) => setState(() => _type = t)),
                ]),
                const SizedBox(height: 10),
                TextField(
                  controller: _note,
                  maxLines: 2,
                  decoration: InputDecoration(
                    hintText: 'ملاحظات (اختياري)',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonalIcon(
                    icon: const Icon(Icons.send_rounded),
                    label: const Text('إرسال بلاغ إلى إدارة الأسطول'),
                    onPressed: () => _sendReport(b),
                  ),
                ),
                if (b.fault)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text('الباص مُعلَّم متعطّلاً حتى تُغلق الإدارة البلاغ.', style: TextStyle(fontSize: 12, color: cs.error)),
                  ),
              ]),
            ),
          ],
        ]);
      },
    );
  }
}

class _NextStopCard extends StatelessWidget {
  const _NextStopCard({required this.bus, required this.line});
  final Bus bus;
  final BusLine line;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ni = store.nextStopIndex(bus);
    final n = line.stopIds.length;
    final order = <Stop>[];
    if (ni != null) {
      for (var k = 0; k < n; k++) {
        final s = store.stops[line.stopIds[(ni + k) % n]];
        if (s != null) order.add(s);
      }
    }
    final next = order.isEmpty ? null : order.first;
    final eta = next == null ? null : store.etaTo(bus, next.id);
    return Panel(
      color: lineColor(line).withValues(alpha: 0.08),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(bus.sim ? Icons.auto_mode_rounded : Icons.gps_fixed_rounded, size: 16, color: cs.primary),
          const SizedBox(width: 6),
          Text(bus.sim ? 'رحلة تجريبية (محاكاة)' : 'رحلة حقيقية — GPS يعمل', style: TextStyle(fontSize: 12, color: cs.primary, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 10),
        Text('المحطة التالية', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
        Row(children: [
          Expanded(child: Text(next?.name ?? '—', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
          Text(fmtEta(eta), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: lineColor(line))),
        ]),
        const SizedBox(height: 10),
        for (var i = 0; i < order.length; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(children: [
              Icon(i == 0 ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded,
                  size: 16, color: i == 0 ? lineColor(line) : cs.outline),
              const SizedBox(width: 8),
              Text(order[i].name, style: TextStyle(fontWeight: i == 0 ? FontWeight.w700 : FontWeight.w400)),
            ]),
          ),
      ]),
    );
  }
}

class _Counter extends StatelessWidget {
  const _Counter({required this.bus, required this.line});
  final Bus bus;
  final BusLine line;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final today = store.statsOf(DateTime.now());
    return Panel(
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          IconButton.filledTonal(
            iconSize: 30,
            onPressed: () => store.alightPassenger(bus),
            icon: const Icon(Icons.remove_rounded),
          ),
          Column(children: [
            Text('${bus.onboard}', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800)),
            Row(mainAxisSize: MainAxisSize.min, children: [
              Text('من ${bus.capacity} · ', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
              LoadChip(bus),
            ]),
          ]),
          IconButton.filled(
            iconSize: 30,
            onPressed: () => store.boardPassenger(bus),
            icon: const Icon(Icons.add_rounded),
          ),
        ]),
        const SizedBox(height: 8),
        Text(
          '＋ عند صعود راكب (تُسجَّل الأجرة ${fmtIqd(line.fare)})  ·  － عند نزوله',
          style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
          textAlign: TextAlign.center,
        ),
        const Divider(height: 22),
        Row(children: [
          Expanded(child: _Stat(Icons.people_alt_rounded, '${today[0]}', 'ركاب اليوم')),
          Expanded(child: _Stat(Icons.payments_rounded, fmtIqd(today[1]), 'إيراد اليوم')),
        ]),
      ]),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.icon, this.value, this.label);
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(children: [
      Icon(icon, color: kGold),
      const SizedBox(height: 2),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      Text(label, style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
    ]);
  }
}
