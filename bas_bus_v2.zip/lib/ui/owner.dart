import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;

import '../core/geo.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

const List<String> _weekdays = ['إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت', 'أحد'];

// ───────────────────────── لوحة المؤشرات ─────────────────────────

class OwnerDashboard extends StatelessWidget {
  const OwnerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final online = store.buses.where((b) => store.isLive(b)).length;
        final faulty = store.buses.where((b) => b.fault).length;
        final today = store.statsOf(DateTime.now());
        final open = store.reports.where((r) => !r.resolved).toList();
        final week = <MapEntry<DateTime, List<int>>>[];
        for (var i = 6; i >= 0; i--) {
          final d = DateTime.now().subtract(Duration(days: i));
          week.add(MapEntry(d, store.statsOf(d)));
        }
        var maxRev = 1;
        for (final e in week) {
          if (e.value[1] > maxRev) maxRev = e.value[1];
        }
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Row(children: [
            Expanded(child: _Kpi(Icons.directions_bus_rounded, '$online / ${store.buses.length}', 'باصات متصلة', cs.primary)),
            const SizedBox(width: 10),
            Expanded(child: _Kpi(Icons.warning_amber_rounded, '$faulty', 'باصات معطّلة', faulty > 0 ? cs.error : cs.outline)),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _Kpi(Icons.people_alt_rounded, '${today[0]}', 'ركاب اليوم', const Color(0xFF2563EB))),
            const SizedBox(width: 10),
            Expanded(child: _Kpi(Icons.payments_rounded, fmtIqd(today[1]), 'إيراد اليوم', kGold)),
          ]),
          const SizedBox(height: 18),
          const Text('الإيراد خلال 7 أيام', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Panel(
            child: SizedBox(
              height: 150,
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                for (final e in week)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                        Text(e.value[1] == 0 ? '' : '${(e.value[1] / 1000).round()}k', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 2),
                        Container(
                          height: 4 + 90 * (e.value[1] / maxRev),
                          decoration: BoxDecoration(
                            color: e.key.day == DateTime.now().day ? cs.primary : cs.primary.withValues(alpha: 0.35),
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(_weekdays[e.key.weekday - 1], style: TextStyle(fontSize: 10, color: cs.onSurfaceVariant)),
                      ]),
                    ),
                  ),
              ]),
            ),
          ),
          const SizedBox(height: 4),
          Text('الأرقام من عدّاد الركاب لدى السائقين (بالألف د.ع).', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
          const SizedBox(height: 18),
          Text('البلاغات المفتوحة (${open.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          if (open.isEmpty)
            Panel(
              child: Row(children: [
                const Icon(Icons.check_circle_rounded, color: Color(0xFF16A34A)),
                const SizedBox(width: 10),
                Text('لا توجد بلاغات مفتوحة', style: TextStyle(color: cs.onSurfaceVariant)),
              ]),
            )
          else
            for (final r in open.take(10))
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Panel(
                  child: Row(children: [
                    Icon(r.type == kReportTypes.first ? Icons.build_rounded : Icons.report_rounded, color: cs.error),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${r.type} — باص ${store.busById(r.busId)?.number ?? '؟'}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        if (r.note.isNotEmpty) Text(r.note, style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
                        Text(fmtAgo(r.ts), style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                      ]),
                    ),
                    FilledButton.tonal(onPressed: () => store.resolveReport(r), child: const Text('تم الحل')),
                  ]),
                ),
              ),
        ]);
      },
    );
  }
}

class _Kpi extends StatelessWidget {
  const _Kpi(this.icon, this.value, this.label, this.color);
  final IconData icon;
  final String value;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(height: 10),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: AlignmentDirectional.centerStart,
          child: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        ),
        Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}

// ───────────────────────── الأسطول ─────────────────────────

class FleetPage extends StatelessWidget {
  const FleetPage({super.key});

  void _edit(BuildContext context, Bus? b) {
    if (store.lines.isEmpty) {
      snack(context, 'أضف خطاً أولاً ثم اربط الباص به.');
      return;
    }
    showDialog<void>(context: context, builder: (_) => _BusDialog(bus: b));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'addBus',
        onPressed: () => _edit(context, null),
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة باص'),
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (c, _) {
          final cs = Theme.of(c).colorScheme;
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 90), children: [
            if (store.buses.isEmpty) const Text('لا توجد باصات. اضغط «إضافة باص».'),
            for (final b in store.buses)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Panel(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Text('باص ${b.number}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(width: 10),
                      if (store.lineById(b.lineId) != null) LineBadge(store.lineById(b.lineId)!) else const Text('بلا خط'),
                      const Spacer(),
                      Switch(value: b.online, onChanged: (v) => store.setBusOnline(b, v)),
                    ]),
                    InfoRow(Icons.person_rounded, b.driver.isEmpty ? 'بلا سائق' : b.driver),
                    InfoRow(
                      b.fault ? Icons.build_rounded : (store.isLive(b) ? Icons.wifi_rounded : Icons.wifi_off_rounded),
                      b.fault ? 'معطّل — بانتظار حل البلاغ' : (store.isLive(b) ? (b.sim ? 'متصل (محاكاة)' : 'متصل (GPS حقيقي)') : 'غير متصل'),
                    ),
                    InfoRow(Icons.groups_rounded, 'الركاب ${b.onboard} / ${b.capacity}'),
                    Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                      IconButton(
                        tooltip: 'تعديل',
                        icon: const Icon(Icons.edit_rounded),
                        onPressed: () => _edit(c, b),
                      ),
                      IconButton(
                        tooltip: 'حذف',
                        icon: Icon(Icons.delete_outline_rounded, color: cs.error),
                        onPressed: () async {
                          final ok = await _confirm(c, 'حذف باص ${b.number}؟');
                          if (ok) store.deleteBus(b);
                        },
                      ),
                    ]),
                  ]),
                ),
              ),
          ]);
        },
      ),
    );
  }
}

Future<bool> _confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('تأكيد')),
      ],
    ),
  );
  return r ?? false;
}

class _BusDialog extends StatefulWidget {
  const _BusDialog({this.bus});
  final Bus? bus;

  @override
  State<_BusDialog> createState() => _BusDialogState();
}

class _BusDialogState extends State<_BusDialog> {
  late final TextEditingController _num;
  late final TextEditingController _driver;
  late final TextEditingController _cap;
  String? _lineId;

  @override
  void initState() {
    super.initState();
    final b = widget.bus;
    _num = TextEditingController(text: b?.number ?? '');
    _driver = TextEditingController(text: b?.driver ?? '');
    _cap = TextEditingController(text: '${b?.capacity ?? 30}');
    _lineId = (b != null && store.lineById(b.lineId) != null) ? b.lineId : (store.lines.isEmpty ? null : store.lines.first.id);
  }

  @override
  void dispose() {
    _num.dispose();
    _driver.dispose();
    _cap.dispose();
    super.dispose();
  }

  void _save() {
    final n = _num.text.trim();
    if (n.isEmpty || _lineId == null) {
      snack(context, 'أدخل رقم الباص واختر الخط.');
      return;
    }
    final cap = int.tryParse(_cap.text.trim()) ?? 30;
    store.upsertBus(widget.bus, number: n, driver: _driver.text.trim(), lineId: _lineId!, capacity: cap.clamp(1, 200).toInt());
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.bus == null ? 'إضافة باص' : 'تعديل الباص'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(controller: _num, decoration: const InputDecoration(labelText: 'رقم الباص')),
          const SizedBox(height: 8),
          TextField(controller: _driver, decoration: const InputDecoration(labelText: 'اسم السائق')),
          const SizedBox(height: 8),
          TextField(controller: _cap, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعة (راكب)')),
          const SizedBox(height: 14),
          const Text('الخط', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, children: [
            for (final l in store.lines)
              ChoiceChip(label: Text(l.shortName), selected: _lineId == l.id, onSelected: (_) => setState(() => _lineId = l.id)),
          ]),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: _save, child: const Text('حفظ')),
      ],
    );
  }
}

// ───────────────────────── إدارة الخطوط ─────────────────────────

class LinesAdminPage extends StatelessWidget {
  const LinesAdminPage({super.key});

  void _open(BuildContext context, BusLine? l) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => LineEditorPage(line: l)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'addLine',
        onPressed: () => _open(context, null),
        icon: const Icon(Icons.add_road_rounded),
        label: const Text('خط جديد'),
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (c, _) {
          final cs = Theme.of(c).colorScheme;
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 90), children: [
            Text(
              'ارسم خطك بالنقر على الخريطة لإضافة المحطات؛ يثبّت التطبيق المسار على الطرق الفعلية تلقائياً.',
              style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
            ),
            const SizedBox(height: 10),
            for (final l in store.lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Panel(
                  onTap: () => _open(c, l),
                  child: Row(children: [
                    Container(width: 8, height: 46, decoration: BoxDecoration(color: lineColor(l), borderRadius: BorderRadius.circular(6))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(l.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text(
                          '${l.stopIds.length} محطات · ${fmtIqd(l.fare)} · ${store.pathOf(l).total >= 1000 ? '${(store.pathOf(l).total / 1000).toStringAsFixed(1)} كم' : '${store.pathOf(l).total.round()} م'}',
                          style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                        ),
                        Row(children: [
                          Icon(l.snapped ? Icons.check_circle_rounded : Icons.timeline_rounded, size: 14, color: l.snapped ? const Color(0xFF16A34A) : cs.outline),
                          const SizedBox(width: 4),
                          Text(l.snapped ? 'مثبّت على الطرق' : 'خط مستقيم بين المحطات', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                        ]),
                      ]),
                    ),
                    if (!l.snapped)
                      IconButton(
                        tooltip: 'تثبيت على الطرق',
                        icon: const Icon(Icons.alt_route_rounded),
                        onPressed: () => unawaited(store.snapLine(l, announce: true)),
                      ),
                    const Icon(Icons.chevron_left_rounded),
                  ]),
                ),
              ),
          ]);
        },
      ),
    );
  }
}

class LineEditorPage extends StatefulWidget {
  const LineEditorPage({super.key, this.line});
  final BusLine? line;

  @override
  State<LineEditorPage> createState() => _LineEditorPageState();
}

class _LineEditorPageState extends State<LineEditorPage> {
  late final TextEditingController _name;
  late final TextEditingController _fare;
  late int _color;
  late List<String> _ids;
  late Map<String, Stop> _local;
  final MapController _map = MapController();

  @override
  void initState() {
    super.initState();
    final l = widget.line;
    _name = TextEditingController(text: l?.name ?? 'خط جديد');
    _fare = TextEditingController(text: '${l?.fare ?? 1000}');
    _color = l?.colorValue ?? kLineColors[store.lines.length % kLineColors.length];
    _ids = List<String>.from(l?.stopIds ?? <String>[]);
    _local = <String, Stop>{};
    for (final e in store.stops.entries) {
      _local[e.key] = Stop(e.value.id, e.value.name, e.value.pos);
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _fare.dispose();
    super.dispose();
  }

  LatLng _center() {
    if (_ids.isNotEmpty && _local[_ids.first] != null) return _local[_ids.first]!.pos;
    final list = store.servedStops();
    return list.isEmpty ? LatLng(32.0003, 44.3148) : list.first.pos;
  }

  void _onTap(LatLng p) {
    Stop? near;
    var best = 40.0;
    for (final s in _local.values) {
      final d = haversine(s.pos, p);
      if (d < best) {
        best = d;
        near = s;
      }
    }
    if (near != null) {
      if (_ids.contains(near.id)) {
        snack(context, 'هذه المحطة مضافة مسبقاً إلى الخط.');
        return;
      }
      final id = near.id;
      setState(() => _ids.add(id));
    } else {
      final id = 's${DateTime.now().microsecondsSinceEpoch}';
      setState(() {
        _local[id] = Stop(id, 'محطة ${_ids.length + 1}', p);
        _ids.add(id);
      });
    }
  }

  Future<void> _rename(String id) async {
    final s = _local[id];
    if (s == null) return;
    final ctl = TextEditingController(text: s.name);
    final name = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('اسم المحطة'),
        content: TextField(controller: ctl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, ctl.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
    ctl.dispose();
    if (name != null && name.isNotEmpty) setState(() => s.name = name);
  }

  void _save() {
    if (_ids.length < 2) {
      snack(context, 'أضف محطتين على الأقل.');
      return;
    }
    final nm = _name.text.trim().isEmpty ? 'خط جديد' : _name.text.trim();
    final fare = int.tryParse(_fare.text.trim()) ?? 1000;
    final l = store.saveLine(widget.line, name: nm, fare: fare, colorValue: _color, stopIds: _ids, stopsMap: _local);
    Navigator.pop(context);
    unawaited(store.snapLine(l, announce: true));
  }

  Future<void> _delete() async {
    final l = widget.line;
    if (l == null) return;
    final ok = await _confirm(context, 'حذف «${l.name}» نهائياً؟');
    if (!ok || !mounted) return;
    store.deleteLine(l);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final color = Color(_color);
    final pts = <LatLng>[];
    for (final id in _ids) {
      final s = _local[id];
      if (s != null) pts.add(s.pos);
    }
    final loop = pts.length >= 2 ? <LatLng>[...pts, pts.first] : pts;
    final markers = <Marker>[];
    for (final s in _local.values) {
      if (_ids.contains(s.id)) continue;
      markers.add(Marker(
        point: s.pos,
        width: 30,
        height: 30,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => _onTap(s.pos),
          child: Center(child: Container(width: 12, height: 12, decoration: BoxDecoration(color: Colors.grey, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
        ),
      ));
    }
    for (var i = 0; i < _ids.length; i++) {
      final s = _local[_ids[i]];
      if (s == null) continue;
      markers.add(Marker(
        point: s.pos,
        width: 34,
        height: 34,
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 6)],
          ),
          child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
        ),
      ));
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.line == null ? 'خط جديد' : 'تعديل الخط'),
        actions: [
          if (widget.line != null) IconButton(tooltip: 'حذف الخط', icon: Icon(Icons.delete_outline_rounded, color: cs.error), onPressed: _delete),
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 8),
            child: FilledButton(onPressed: _save, child: const Text('حفظ')),
          ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Row(children: [
            Expanded(flex: 3, child: TextField(controller: _name, decoration: const InputDecoration(labelText: 'اسم الخط (مثال: الخط الأول — المطار)', isDense: true))),
            const SizedBox(width: 10),
            Expanded(flex: 2, child: TextField(controller: _fare, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الأجرة (د.ع)', isDense: true))),
          ]),
        ),
        SizedBox(
          height: 38,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            for (final cv in kLineColors)
              GestureDetector(
                onTap: () => setState(() => _color = cv),
                child: Container(
                  width: 30,
                  height: 30,
                  margin: const EdgeInsetsDirectional.only(end: 10),
                  decoration: BoxDecoration(
                    color: Color(cv),
                    shape: BoxShape.circle,
                    border: Border.all(color: _color == cv ? cs.onSurface : Colors.transparent, width: 3),
                  ),
                ),
              ),
          ]),
        ),
        Expanded(
          flex: 5,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: FlutterMap(
              mapController: _map,
              options: MapOptions(
                initialCenter: _center(),
                initialZoom: 14,
                minZoom: 6,
                maxZoom: 19,
                interactionOptions: const InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
                onTap: (tapPosition, point) => _onTap(point),
              ),
              children: [
                TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'iq.bas.bus.bas_bus'),
                PolylineLayer(polylines: [
                  if (loop.length >= 2) Polyline(points: loop, strokeWidth: 5, color: color.withValues(alpha: 0.85), borderStrokeWidth: 1.5, borderColor: Colors.white),
                ]),
                MarkerLayer(markers: markers),
                RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: Row(children: [
            Expanded(child: Text('المحطات (${_ids.length}) — انقر على الخريطة للإضافة، واسحب لإعادة الترتيب', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant))),
          ]),
        ),
        Expanded(
          flex: 4,
          child: ReorderableListView(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            onReorder: (o, n) => setState(() {
              if (n > o) n -= 1;
              final id = _ids.removeAt(o);
              _ids.insert(n, id);
            }),
            children: [
              for (var i = 0; i < _ids.length; i++)
                ListTile(
                  key: ValueKey(_ids[i]),
                  dense: true,
                  leading: CircleAvatar(radius: 13, backgroundColor: color, child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800))),
                  title: Text(_local[_ids[i]]?.name ?? '—'),
                  onTap: () => _rename(_ids[i]),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(icon: const Icon(Icons.edit_rounded, size: 20), onPressed: () => _rename(_ids[i])),
                    IconButton(icon: Icon(Icons.close_rounded, size: 20, color: cs.error), onPressed: () => setState(() => _ids.removeAt(i))),
                    const SizedBox(width: 24),
                  ]),
                ),
            ],
          ),
        ),
      ]),
    );
  }
}
