import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

const String kVersion = '0.2.0';

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  Future<void> _import(BuildContext context) async {
    final ctl = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('استيراد بيانات'),
        content: TextField(
          controller: ctl,
          maxLines: 8,
          decoration: const InputDecoration(hintText: 'ألصق ملف JSON الذي صدّرته سابقاً'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, ctl.text), child: const Text('استيراد')),
        ],
      ),
    );
    ctl.dispose();
    if (text == null || text.trim().isEmpty || !context.mounted) return;
    final ok = store.importJson(text);
    snack(context, ok ? 'تم استيراد البيانات.' : 'الملف غير صالح — لم يتغيّر شيء.');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Panel(
            child: Row(children: [
              CircleAvatar(radius: 26, backgroundColor: cs.primaryContainer, child: Icon(Icons.person_rounded, color: cs.primary, size: 30)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('حسابي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  Text('حساب تجريبي غير مرتبط بخادم', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                ]),
              ),
            ]),
          ),
          const _Title('واجهة العرض التجريبية'),
          Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ValueListenableBuilder<Role>(
                valueListenable: store.role,
                builder: (c2, r, _) => SegmentedButton<Role>(
                  segments: [
                    for (final x in Role.values) ButtonSegment<Role>(value: x, label: Text(roleLabel(x)), icon: Icon(roleIcon(x))),
                  ],
                  selected: <Role>{r},
                  onSelectionChanged: (s) {
                    store.setRole(s.first);
                    navIndex.value = 0;
                  },
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'تبديل الأدوار للتجربة فقط. في النسخة الحقيقية تُفرض الصلاحيات من الخادم ولا يستطيع السائق فتح لوحة المالك.',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              ),
            ]),
          ),
          const _Title('المظهر'),
          Panel(
            child: ValueListenableBuilder<ThemeMode>(
              valueListenable: store.themeMode,
              builder: (c2, m, _) => SegmentedButton<ThemeMode>(
                segments: const [
                  ButtonSegment<ThemeMode>(value: ThemeMode.system, label: Text('تلقائي'), icon: Icon(Icons.brightness_auto_rounded)),
                  ButtonSegment<ThemeMode>(value: ThemeMode.light, label: Text('فاتح'), icon: Icon(Icons.light_mode_rounded)),
                  ButtonSegment<ThemeMode>(value: ThemeMode.dark, label: Text('داكن'), icon: Icon(Icons.dark_mode_rounded)),
                ],
                selected: <ThemeMode>{m},
                onSelectionChanged: (s) => store.setTheme(s.first),
              ),
            ),
          ),
          const _Title('المحاكاة'),
          Panel(
            child: Column(children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('باصات تجريبية متحركة', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('أوقفها لعرض الباصات الحقيقية فقط (سائق يشغّل GPS).'),
                value: store.simEnabled,
                onChanged: store.setSim,
              ),
              if (store.simEnabled)
                Row(children: [
                  const Text('سرعة المحاكاة'),
                  Expanded(
                    child: Slider(
                      value: store.simSpeed,
                      min: 1,
                      max: 10,
                      divisions: 9,
                      label: '×${store.simSpeed.round()}',
                      onChanged: store.setSimSpeed,
                    ),
                  ),
                  Text('×${store.simSpeed.round()}', style: const TextStyle(fontWeight: FontWeight.w800)),
                ]),
            ]),
          ),
          const _Title('الموقع'),
          Panel(
            child: Row(children: [
              Icon(Icons.my_location_rounded, color: cs.primary),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  store.userPos == null ? 'صلاحية الموقع: لم يُحدَّد موقعك بعد' : 'تم تحديد موقع هاتفك',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              FilledButton.tonal(
                onPressed: () async {
                  final err = await store.locate();
                  if (c.mounted) snack(c, err ?? 'تم تحديث موقعك ✓');
                },
                child: const Text('تحديث موقعي'),
              ),
            ]),
          ),
          const _Title('البيانات'),
          Panel(
            child: Column(children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.upload_rounded),
                title: const Text('نسخ بيانات الخطوط والأسطول'),
                subtitle: const Text('نسخة JSON تُلصق لاحقاً أو تُرسل إلى الخادم.'),
                onTap: () async {
                  await Clipboard.setData(ClipboardData(text: store.exportJson()));
                  if (c.mounted) snack(c, 'تم النسخ إلى الحافظة.');
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.download_rounded),
                title: const Text('استيراد بيانات'),
                onTap: () => _import(c),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.restart_alt_rounded, color: cs.error),
                title: Text('إعادة البيانات التجريبية', style: TextStyle(color: cs.error)),
                onTap: () async {
                  final ok = await showDialog<bool>(
                    context: c,
                    builder: (d) => AlertDialog(
                      content: const Text('سيُحذف كل ما أضفته وتعود الخطوط التجريبية. متابعة؟'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
                        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('متابعة')),
                      ],
                    ),
                  );
                  if (ok == true) store.resetDemo();
                },
              ),
            ]),
          ),
          const _Title('حول النسخة'),
          Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('باص النجف — إصدار تجريبي $kVersion', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(
                'نسخة لاختبار الواجهة والخريطة والمحاكاة. لا تتصل بأسطول حقيقي بعد: يلزم تزويدنا بأسماء المحطات الحقيقية ثم مراجعة الطريق ميدانياً قبل تشغيل الركاب.\n'
                'الخريطة © مساهمو OpenStreetMap — هندسة الطرق من OSRM (خادم تجريبي).',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant, height: 1.6),
              ),
            ]),
          ),
        ]);
      },
    );
  }
}

class _Title extends StatelessWidget {
  const _Title(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
      child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: kGreen)),
    );
  }
}
