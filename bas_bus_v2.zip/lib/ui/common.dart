import 'package:flutter/material.dart';

import '../core/models.dart';
import '../core/theme.dart';
import '../data/store.dart';

/// تبويب التنقل الحالي، والخط المطلوب إبرازه على الخريطة.
final ValueNotifier<int> navIndex = ValueNotifier<int>(0);
final ValueNotifier<String?> focusLine = ValueNotifier<String?>(null);
final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

Color lineColor(BusLine l) => Color(l.colorValue);

String fmtEta(double? s) {
  if (s == null) return '—';
  if (s < 45) return 'الآن';
  final m = (s / 60).ceil();
  if (m >= 60) return '${m ~/ 60} س ${m % 60} د';
  return '$m د';
}

String fmtDist(double m) => m < 1000 ? '${m.round()} م' : '${(m / 1000).toStringAsFixed(1)} كم';

String fmtIqd(int v) {
  final s = v.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return '$s د.ع';
}

String fmtAgo(int ts) {
  final mins = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ts)).inMinutes;
  if (mins < 1) return 'الآن';
  if (mins < 60) return 'منذ $mins د';
  if (mins < 1440) return 'منذ ${mins ~/ 60} س';
  return 'منذ ${mins ~/ 1440} يوم';
}

String roleLabel(Role r) => r == Role.passenger ? 'راكب' : (r == Role.driver ? 'سائق' : 'مالك');

IconData roleIcon(Role r) =>
    r == Role.passenger ? Icons.person_rounded : (r == Role.driver ? Icons.airline_seat_recline_normal_rounded : Icons.business_center_rounded);

Color loadColor(Bus b) => b.loadRatio < 0.4 ? const Color(0xFF16A34A) : (b.loadRatio < 0.8 ? const Color(0xFFD97706) : const Color(0xFFDC2626));

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

Future<T?> showSheet<T>(BuildContext c, WidgetBuilder b) {
  return showModalBottomSheet<T>(
    context: c,
    isScrollControlled: true,
    showDragHandle: true,
    useSafeArea: true,
    builder: b,
  );
}

/// بطاقة بزوايا مدوّرة وظل خفيف.
class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.onTap, this.color});

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final r = BorderRadius.circular(20);
    return DecoratedBox(
      decoration: BoxDecoration(
        color: color ?? cs.surface,
        borderRadius: r,
        border: Border.all(color: cs.outlineVariant.withValues(alpha: 0.6)),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.07), blurRadius: 16, offset: const Offset(0, 4)),
        ],
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: r,
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class LineBadge extends StatelessWidget {
  const LineBadge(this.line, {super.key});
  final BusLine line;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(color: lineColor(line), borderRadius: BorderRadius.circular(20)),
      child: Text(
        line.shortName,
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12),
      ),
    );
  }
}

class LoadChip extends StatelessWidget {
  const LoadChip(this.bus, {super.key});
  final Bus bus;

  @override
  Widget build(BuildContext context) {
    final c = loadColor(bus);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: c.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.groups_rounded, size: 14, color: c),
        const SizedBox(width: 4),
        Text(bus.loadLabel, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: c)),
      ]),
    );
  }
}

class InfoRow extends StatelessWidget {
  const InfoRow(this.icon, this.text, {super.key});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(children: [
        Icon(icon, size: 16, color: cs.onSurfaceVariant),
        const SizedBox(width: 6),
        Expanded(child: Text(text, style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant))),
      ]),
    );
  }
}

// ───────────────────────── علامات الخريطة ─────────────────────────

Widget stopDot(Color c, {bool fav = false}) {
  return Center(
    child: Container(
      width: fav ? 24 : 18,
      height: fav ? 24 : 18,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: c, width: 4),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
      ),
      child: fav ? const Icon(Icons.star_rounded, size: 14, color: kGold) : null,
    ),
  );
}

Widget busDot(Color c, {bool fault = false, bool selected = false}) {
  final size = selected ? 44.0 : 38.0;
  return Center(
    child: Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: fault ? const Color(0xFF6B7280) : c,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 3),
        boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 8, offset: Offset(0, 2))],
      ),
      child: Icon(fault ? Icons.build_rounded : Icons.directions_bus_rounded, color: Colors.white, size: selected ? 24 : 20),
    ),
  );
}

Widget userDot() {
  return Center(
    child: Container(
      width: 22,
      height: 22,
      decoration: BoxDecoration(
        color: const Color(0xFF2563EB),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 3),
        boxShadow: [BoxShadow(color: const Color(0xFF2563EB).withValues(alpha: 0.35), blurRadius: 0, spreadRadius: 8)],
      ),
    ),
  );
}

/// قائمة اختيار محطة.
Future<Stop?> pickStop(BuildContext context, {String title = 'اختر محطة'}) {
  final list = store.servedStops();
  return showSheet<Stop>(
    context,
    (c) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Align(alignment: AlignmentDirectional.centerStart, child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
        ),
        Flexible(
          child: ListView(shrinkWrap: true, children: [
            for (final s in list)
              ListTile(
                leading: Icon(store.favStops.contains(s.id) ? Icons.star_rounded : Icons.place_rounded, color: store.favStops.contains(s.id) ? kGold : null),
                title: Text(s.name),
                onTap: () => Navigator.pop(c, s),
              ),
          ]),
        ),
      ]),
    ),
  );
}
