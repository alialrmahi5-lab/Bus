import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme.dart';
import 'data/store.dart';
import 'ui/account.dart';
import 'ui/common.dart';
import 'ui/driver.dart';
import 'ui/owner.dart';
import 'ui/passenger.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  store = await AppStore.load();
  runApp(const BasBusApp());
}

class BasBusApp extends StatelessWidget {
  const BasBusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: store.themeMode,
      builder: (context, mode, _) {
        return MaterialApp(
          navigatorKey: navKey,
          debugShowCheckedModeBanner: false,
          title: 'باص النجف',
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: mode,
          home: const Shell(),
        );
      },
    );
  }
}

class _Tab {
  const _Tab(this.label, this.icon, this.page);
  final String label;
  final IconData icon;
  final Widget page;
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  StreamSubscription<String>? _sub;

  @override
  void initState() {
    super.initState();
    _sub = store.messages.listen((m) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  List<_Tab> _tabs(Role r) {
    switch (r) {
      case Role.passenger:
        return const [
          _Tab('الخريطة', Icons.map_rounded, MapPage()),
          _Tab('الخطوط', Icons.route_rounded, LinesPage()),
          _Tab('حسابي', Icons.person_rounded, AccountPage()),
        ];
      case Role.driver:
        return const [
          _Tab('رحلتي', Icons.directions_bus_rounded, DriverPage()),
          _Tab('حسابي', Icons.person_rounded, AccountPage()),
        ];
      case Role.owner:
        return const [
          _Tab('اللوحة', Icons.dashboard_rounded, OwnerDashboard()),
          _Tab('الأسطول', Icons.directions_bus_filled_rounded, FleetPage()),
          _Tab('الخطوط', Icons.add_road_rounded, LinesAdminPage()),
          _Tab('حسابي', Icons.person_rounded, AccountPage()),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ValueListenableBuilder<Role>(
      valueListenable: store.role,
      builder: (context, role, _) {
        final tabs = _tabs(role);
        return ValueListenableBuilder<int>(
          valueListenable: navIndex,
          builder: (context, idx, _) {
            final i = idx < 0 ? 0 : (idx >= tabs.length ? tabs.length - 1 : idx);
            return Scaffold(
              appBar: AppBar(
                title: Row(children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(color: kGreen, borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.directions_bus_rounded, color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 10),
                  const Text('باص النجف'),
                ]),
                actions: [
                  PopupMenuButton<Role>(
                    tooltip: 'تبديل الواجهة التجريبية',
                    onSelected: (r) {
                      store.setRole(r);
                      navIndex.value = 0;
                    },
                    itemBuilder: (_) => [
                      for (final r in Role.values)
                        PopupMenuItem<Role>(
                          value: r,
                          child: Row(children: [Icon(roleIcon(r), size: 20), const SizedBox(width: 10), Text('عرض ${roleLabel(r)} التجريبي')]),
                        ),
                    ],
                    child: Container(
                      margin: const EdgeInsetsDirectional.only(end: 12),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(20)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(roleIcon(role), size: 18, color: cs.onPrimaryContainer),
                        const SizedBox(width: 6),
                        Text(roleLabel(role), style: TextStyle(fontWeight: FontWeight.w700, color: cs.onPrimaryContainer)),
                        Icon(Icons.expand_more_rounded, size: 18, color: cs.onPrimaryContainer),
                      ]),
                    ),
                  ),
                ],
              ),
              body: KeyedSubtree(
                key: ValueKey<Role>(role),
                child: IndexedStack(index: i, children: [for (final t in tabs) t.page]),
              ),
              bottomNavigationBar: NavigationBar(
                selectedIndex: i,
                onDestinationSelected: (v) => navIndex.value = v,
                destinations: [
                  for (final t in tabs) NavigationDestination(icon: Icon(t.icon), label: t.label),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
