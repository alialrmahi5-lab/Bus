import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show AuthException, PostgrestException, Supabase, SupabaseClient;
import 'package:wakelock_plus/wakelock_plus.dart';

import '../config.dart';
import '../core/geo.dart';
import '../core/models.dart';

enum AppPhase { loading, signedOut, ready }

const double kDwell = 12; // ثوانٍ تقريبية للوقوف في كل محطة

late AppStore store;

class Arrival {
  Arrival(this.line, this.bus, this.secs);
  final BusLine line;
  final Bus bus;
  final double secs;
}

class TripOption {
  TripOption(this.line, this.bus, this.waitSecs, this.rideSecs, this.hops);
  final BusLine line;
  final Bus? bus;
  final double? waitSecs;
  final double rideSecs;
  final int hops;
  double get totalSecs => (waitSecs ?? 1e9) + rideSecs;
}

/// يحوّل رقم هاتف عراقي إلى الصيغة الدولية 9647XXXXXXXXX أو null إن كان غير صالح.
String? normalizePhone(String raw) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in raw.trim().split('')) {
    final i = ar.indexOf(ch);
    b.write(i >= 0 ? '$i' : ch);
  }
  var s = b.toString().replaceAll(RegExp(r'[^0-9]'), '');
  if (s.startsWith('00964')) {
    s = s.substring(5);
  } else if (s.startsWith('964')) {
    s = s.substring(3);
  } else if (s.startsWith('0')) {
    s = s.substring(1);
  }
  if (s.length != 10 || !s.startsWith('7')) return null;
  return '964$s';
}

String localPhone(String intl) => '0${intl.substring(3)}';

class AppStore extends ChangeNotifier {
  SharedPreferences? _prefs;
  SupabaseClient? _db;

  AppPhase phase = AppPhase.loading;
  String? setupError;
  Profile? me;

  final Map<String, Stop> stops = {};
  final List<BusLine> lines = [];
  final List<Bus> buses = [];
  final List<Ticket> tickets = [];
  final List<Report> reports = [];
  final List<DriverBalance> balances = [];
  final List<Settlement> settlements = [];
  final List<Profile> drivers = [];
  AppSettings settings = AppSettings();

  final Set<String> favStops = {};
  final Set<String> alerts = {}; // stopId|lineId
  final ValueNotifier<ThemeMode> themeMode = ValueNotifier<ThemeMode>(ThemeMode.system);

  LatLng? userPos;
  bool tripActive = false;

  final Map<String, RoutePath> _paths = {};
  final StreamController<String> _msg = StreamController<String>.broadcast();
  Stream<String> get messages => _msg.stream;

  Timer? _busTimer;
  Timer? _slowTimer;
  Timer? _pubTimer;
  StreamSubscription<Position>? _gps;
  bool _busBusy = false;
  bool _slowBusy = false;
  int _slowTick = 0;
  LatLng? _lastPos;
  double _lastSpeed = 0;

  Role get role => me?.role ?? Role.passenger;
  bool get isOwner => role == Role.owner;

  // ───────────────────────── التهيئة ─────────────────────────

  Future<void> initLocal() async {
    _prefs = await SharedPreferences.getInstance();
    final t = _prefs!.getInt('theme') ?? 0;
    themeMode.value = ThemeMode.values[t.clamp(0, ThemeMode.values.length - 1).toInt()];
    favStops.addAll(_prefs!.getStringList('fav') ?? <String>[]);
    alerts.addAll(_prefs!.getStringList('alerts') ?? <String>[]);
  }

  Future<void> initRemote() async {
    if (!kBackendConfigured) {
      setupError = 'لم يتم ربط الخادم بعد. أضف SUPABASE_URL و SUPABASE_ANON_KEY في GitHub Secrets ثم أعد البناء.';
      phase = AppPhase.signedOut;
      notifyListeners();
      return;
    }
    try {
      await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseKey);
      _db = Supabase.instance.client;
      if (_db!.auth.currentSession != null) {
        await _enter();
      } else {
        phase = AppPhase.signedOut;
      }
    } catch (_) {
      setupError = 'تعذّر الاتصال بالخادم. تحقق من الإنترنت ثم أعد فتح التطبيق.';
      phase = AppPhase.signedOut;
    }
    notifyListeners();
  }

  void _saveLocal() {
    final p = _prefs;
    if (p == null) return;
    p.setInt('theme', themeMode.value.index);
    p.setStringList('fav', favStops.toList());
    p.setStringList('alerts', alerts.toList());
  }

  Future<void> _enter() async {
    final db = _db!;
    final uid = db.auth.currentUser?.id;
    if (uid == null) {
      phase = AppPhase.signedOut;
      return;
    }
    final row = await db.from('profiles').select().eq('id', uid).maybeSingle();
    if (row == null) {
      await db.auth.signOut();
      phase = AppPhase.signedOut;
      return;
    }
    final p = Profile.fromJson(row);
    if (!p.active) {
      await db.auth.signOut();
      phase = AppPhase.signedOut;
      _msg.add('هذا الحساب موقوف. تواصل مع الإدارة.');
      return;
    }
    me = p;
    phase = AppPhase.ready;
    await _loadConfig();
    _startSync();
  }

  void _startSync() {
    _busTimer?.cancel();
    _slowTimer?.cancel();
    _slowTick = 0;
    _busTimer = Timer.periodic(const Duration(seconds: 4), (_) => refreshBuses());
    _slowTimer = Timer.periodic(const Duration(seconds: 8), (_) => refreshSlow());
    unawaited(refreshBuses());
    unawaited(refreshSlow());
  }

  void _stopSync() {
    _busTimer?.cancel();
    _slowTimer?.cancel();
    _busTimer = null;
    _slowTimer = null;
  }

  // ───────────────────────── المصادقة ─────────────────────────

  String _email(String intlPhone) => '$intlPhone@busiq.app';

  String _authMsg(String m) {
    final s = m.toLowerCase();
    if (s.contains('invalid login')) return 'رقم الهاتف أو كلمة المرور غير صحيحة.';
    if (s.contains('already registered') || s.contains('already been registered')) return 'هذا الرقم مسجّل مسبقاً، سجّل الدخول.';
    if (s.contains('at least')) return 'كلمة المرور 6 أحرف على الأقل.';
    if (s.contains('not confirmed')) return 'الحساب غير مفعّل: عطّل خيار Confirm email في إعدادات Supabase.';
    if (s.contains('rate limit')) return 'محاولات كثيرة، انتظر قليلاً ثم أعد المحاولة.';
    return 'تعذّر إتمام العملية: $m';
  }

  Future<String?> signIn(String phone, String password) async {
    final ph = normalizePhone(phone);
    if (ph == null) return 'رقم الهاتف غير صحيح (مثال: 07701234567).';
    if (_db == null) return setupError ?? 'الخادم غير متصل.';
    try {
      await _db!.auth.signInWithPassword(email: _email(ph), password: password);
      await _enter();
      notifyListeners();
      return phase == AppPhase.ready ? null : 'تعذّر تسجيل الدخول.';
    } on AuthException catch (e) {
      return _authMsg(e.message);
    } catch (_) {
      return 'تعذّر الاتصال بالخادم. تحقق من الإنترنت.';
    }
  }

  Future<String?> signUp({required String name, required String phone, required String password, required bool asDriver}) async {
    final ph = normalizePhone(phone);
    if (name.trim().length < 2) return 'اكتب اسمك الكامل.';
    if (ph == null) return 'رقم الهاتف غير صحيح (مثال: 07701234567).';
    if (password.length < 6) return 'كلمة المرور 6 أحرف على الأقل.';
    if (_db == null) return setupError ?? 'الخادم غير متصل.';
    try {
      final res = await _db!.auth.signUp(
        email: _email(ph),
        password: password,
        data: <String, dynamic>{'name': name.trim(), 'phone': localPhone(ph), 'role': asDriver ? 'driver' : 'passenger'},
      );
      if (res.session == null) {
        await _db!.auth.signInWithPassword(email: _email(ph), password: password);
      }
      await _enter();
      notifyListeners();
      return phase == AppPhase.ready ? null : 'تعذّر إنشاء الحساب.';
    } on AuthException catch (e) {
      return _authMsg(e.message);
    } catch (_) {
      return 'تعذّر الاتصال بالخادم. تحقق من الإنترنت.';
    }
  }

  Future<void> signOut() async {
    if (tripActive) await endTrip();
    _stopSync();
    try {
      await _db?.auth.signOut();
    } catch (_) {}
    me = null;
    stops.clear();
    lines.clear();
    buses.clear();
    tickets.clear();
    reports.clear();
    balances.clear();
    settlements.clear();
    drivers.clear();
    _paths.clear();
    phase = AppPhase.signedOut;
    notifyListeners();
  }

  // ───────────────────────── المزامنة ─────────────────────────

  Future<void> _loadConfig() async {
    final rows = await _db!.from('config').select();
    for (final r in rows) {
      final key = r['key'] as String;
      final v = r['value'];
      if (v is! Map) continue;
      final j = Map<String, dynamic>.from(v);
      if (key == 'network') {
        _applyNetwork(j);
      } else if (key == 'settings') {
        settings = AppSettings.fromJson(j);
      }
    }
  }

  void _applyNetwork(Map<String, dynamic> j) {
    final newStops = <String, Stop>{};
    for (final e in (j['stops'] as List<dynamic>? ?? <dynamic>[])) {
      final s = Stop.fromJson(Map<String, dynamic>.from(e as Map));
      newStops[s.id] = s;
    }
    final newLines = <BusLine>[];
    for (final e in (j['lines'] as List<dynamic>? ?? <dynamic>[])) {
      final l = BusLine.fromJson(Map<String, dynamic>.from(e as Map));
      l.stopIds.removeWhere((id) => !newStops.containsKey(id));
      if (l.legs.length != l.stopIds.length) {
        l.legs = <List<LatLng>>[];
        l.snapped = false;
      }
      newLines.add(l);
    }
    stops
      ..clear()
      ..addAll(newStops);
    lines
      ..clear()
      ..addAll(newLines);
    _paths.clear();
  }

  Future<void> refreshBuses() async {
    if (_db == null || phase != AppPhase.ready || _busBusy) return;
    _busBusy = true;
    try {
      final rows = await _db!.from('buses').select();
      final list = rows.map((r) => Bus.fromJson(r)).toList();
      for (final b in list) {
        final l = lineById(b.lineId);
        if (l != null && b.pos != null) b.d = pathOf(l).nearest(b.pos!).along;
      }
      list.sort((a, b) => a.number.compareTo(b.number));
      buses
        ..clear()
        ..addAll(list);
      _checkAlerts();
      notifyListeners();
    } catch (_) {
    } finally {
      _busBusy = false;
    }
  }

  Future<void> refreshSlow() async {
    if (_db == null || phase != AppPhase.ready || _slowBusy) return;
    _slowBusy = true;
    try {
      _slowTick++;
      final uid = _db!.auth.currentUser?.id;
      if (uid != null) {
        final row = await _db!.from('profiles').select().eq('id', uid).maybeSingle();
        if (row != null) me = Profile.fromJson(row);
        if (me != null && !me!.active) {
          await signOut();
          return;
        }
      }
      if (_slowTick % 5 == 0 && !isOwner) await _loadConfig();
      await refreshTickets();
      if (role == Role.driver) {
        final b = await _db!.from('driver_balances').select();
        balances
          ..clear()
          ..addAll(b.map((r) => DriverBalance.fromJson(r)));
        final s = await _db!.from('settlements').select().order('created_at', ascending: false).limit(30);
        settlements
          ..clear()
          ..addAll(s.map((r) => Settlement.fromJson(r)));
      } else if (isOwner) {
        final r = await _db!.from('reports').select().order('created_at', ascending: false).limit(50);
        reports
          ..clear()
          ..addAll(r.map((x) => Report.fromJson(x)));
        final b = await _db!.from('driver_balances').select();
        balances
          ..clear()
          ..addAll(b.map((x) => DriverBalance.fromJson(x)));
        final d = await _db!.from('profiles').select().eq('role', 'driver').order('created_at', ascending: false);
        drivers
          ..clear()
          ..addAll(d.map((x) => Profile.fromJson(x)));
      }
      notifyListeners();
    } catch (_) {
    } finally {
      _slowBusy = false;
    }
  }

  Future<void> refreshTickets() async {
    if (_db == null) return;
    try {
      final since = DateTime.now().subtract(const Duration(days: 8)).toUtc().toIso8601String();
      final rows = isOwner
          ? await _db!.from('tickets').select().gte('created_at', since).order('created_at', ascending: false).limit(1500)
          : await _db!.from('tickets').select().order('created_at', ascending: false).limit(100);
      tickets
        ..clear()
        ..addAll(rows.map((r) => Ticket.fromJson(r)));
      notifyListeners();
    } catch (_) {}
  }

  // ───────────────────────── استعلامات الشبكة ─────────────────────────

  BusLine? lineById(String? id) {
    if (id == null) return null;
    for (final l in lines) {
      if (l.id == id) return l;
    }
    return null;
  }

  Bus? busById(String? id) {
    if (id == null) return null;
    for (final b in buses) {
      if (b.id == id) return b;
    }
    return null;
  }

  Bus? get myBus {
    final id = me?.id;
    if (id == null) return null;
    for (final b in buses) {
      if (b.driverId == id) return b;
    }
    return null;
  }

  RoutePath pathOf(BusLine l) {
    return _paths.putIfAbsent(l.id, () {
      final pts = <LatLng>[];
      for (final id in l.stopIds) {
        final s = stops[id];
        if (s != null) pts.add(s.pos);
      }
      return RoutePath.build(pts, l.legs);
    });
  }

  void _invalidate(BusLine l) => _paths.remove(l.id);

  bool isLive(Bus b) => b.online && b.fresh && b.pos != null && lineById(b.lineId) != null;

  List<Stop> servedStops() {
    final ids = <String>{};
    for (final l in lines) {
      ids.addAll(l.stopIds);
    }
    final out = ids.map((id) => stops[id]).whereType<Stop>().toList();
    out.sort((a, b) => a.name.compareTo(b.name));
    return out;
  }

  Stop? nearestStop(LatLng p) {
    Stop? best;
    var bd = double.infinity;
    for (final s in servedStops()) {
      final d = haversine(p, s.pos);
      if (d < bd) {
        bd = d;
        best = s;
      }
    }
    return best;
  }

  double _aheadTo(Bus b, RoutePath p, int i) {
    var a = p.ahead(b.d, p.stopDist[i]);
    if (a > p.total - 25) a = 0;
    return a;
  }

  /// فهرس المحطة التالية للباص على خطه.
  int? nextStopIndex(Bus b) {
    final l = lineById(b.lineId);
    if (l == null) return null;
    final p = pathOf(l);
    if (p.total <= 0 || p.stopDist.length != l.stopIds.length) return null;
    int? bi;
    var best = double.infinity;
    for (var i = 0; i < p.stopDist.length; i++) {
      final a = _aheadTo(b, p, i);
      if (a < best) {
        best = a;
        bi = i;
      }
    }
    return bi;
  }

  double? _eta(Bus b, RoutePath p, int stopIdx) {
    if (!isLive(b) || b.fault || p.total <= 0) return null;
    final sp = math.max(3.0, b.speed);
    final a = _aheadTo(b, p, stopIdx);
    var between = 0;
    for (var i = 0; i < p.stopDist.length; i++) {
      if (i == stopIdx) continue;
      final x = _aheadTo(b, p, i);
      if (x > 0 && x < a) between++;
    }
    return a / sp + between * kDwell;
  }

  double? etaTo(Bus b, String stopId) {
    final l = lineById(b.lineId);
    if (l == null) return null;
    final idx = l.stopIds.indexOf(stopId);
    final p = pathOf(l);
    if (idx < 0 || p.stopDist.length != l.stopIds.length) return null;
    return _eta(b, p, idx);
  }

  List<Arrival> arrivalsAt(String stopId, {String? lineId}) {
    final out = <Arrival>[];
    for (final l in lines) {
      if (lineId != null && l.id != lineId) continue;
      final idx = l.stopIds.indexOf(stopId);
      if (idx < 0) continue;
      final p = pathOf(l);
      if (p.stopDist.length != l.stopIds.length) continue;
      for (final b in buses) {
        if (b.lineId != l.id) continue;
        final e = _eta(b, p, idx);
        if (e != null) out.add(Arrival(l, b, e));
      }
    }
    out.sort((x, y) => x.secs.compareTo(y.secs));
    return out;
  }

  List<TripOption> plan(String fromId, String toId) {
    final out = <TripOption>[];
    for (final l in lines) {
      final i = l.stopIds.indexOf(fromId);
      final j = l.stopIds.indexOf(toId);
      if (i < 0 || j < 0 || i == j) continue;
      final p = pathOf(l);
      if (p.stopDist.length != l.stopIds.length || p.total <= 0) continue;
      final rideDist = p.ahead(p.stopDist[i], p.stopDist[j]);
      final hops = (j - i) % l.stopIds.length;
      final arr = arrivalsAt(fromId, lineId: l.id);
      final best = arr.isEmpty ? null : arr.first;
      final sp = math.max(3.0, best?.bus.speed ?? 5.5);
      final ride = rideDist / sp + (hops - 1) * kDwell;
      out.add(TripOption(l, best?.bus, best?.secs, ride, hops));
    }
    out.sort((a, b) => a.totalSecs.compareTo(b.totalSecs));
    return out;
  }

  void _checkAlerts() {
    if (alerts.isEmpty) return;
    for (final k in alerts.toList()) {
      final parts = k.split('|');
      if (parts.length != 2) {
        alerts.remove(k);
        continue;
      }
      final arr = arrivalsAt(parts[0], lineId: parts[1]);
      if (arr.isNotEmpty && arr.first.secs <= 120) {
        alerts.remove(k);
        final st = stops[parts[0]];
        final l = lineById(parts[1]);
        HapticFeedback.heavyImpact();
        _msg.add('🚌 ${l?.shortName ?? 'الباص'} يقترب من «${st?.name ?? ''}» — أقل من دقيقتين');
        _saveLocal();
      }
    }
  }

  // ───────────────────────── الموقع و GPS ─────────────────────────

  Future<String?> _ensurePermission() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        return 'فعّل خدمة الموقع من إعدادات الهاتف.';
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        return 'يرجى السماح للتطبيق بالوصول إلى الموقع.';
      }
      return null;
    } catch (_) {
      return 'تعذّر الوصول إلى خدمة الموقع.';
    }
  }

  /// يحدّد موقع المستخدم؛ يعيد رسالة خطأ أو null عند النجاح.
  Future<String?> locate() async {
    final err = await _ensurePermission();
    if (err != null) return err;
    try {
      final p = await Geolocator.getCurrentPosition().timeout(const Duration(seconds: 20));
      userPos = LatLng(p.latitude, p.longitude);
      notifyListeners();
      return null;
    } catch (_) {
      return 'تعذّر تحديد موقعك، حاول في مكان مكشوف.';
    }
  }

  // ───────────────────────── السائق ─────────────────────────

  Future<String?> startTrip() async {
    final b = myBus;
    if (b == null) return 'لم تُعيَّن لك حافلة بعد. تواصل مع الإدارة.';
    if (lineById(b.lineId) == null) return 'حافلتك غير مرتبطة بخط سير.';
    if (b.fault) return 'الحافلة مُعلَّمة متعطّلة حتى تُغلق الإدارة البلاغ.';
    final err = await _ensurePermission();
    if (err != null) return err;
    try {
      final p = await Geolocator.getCurrentPosition().timeout(const Duration(seconds: 20));
      _lastPos = LatLng(p.latitude, p.longitude);
      _lastSpeed = (p.speed.isFinite && p.speed > 0) ? p.speed : 0;
      userPos = _lastPos;
    } catch (_) {
      return 'تعذّر تحديد موقعك، حاول في مكان مكشوف.';
    }
    tripActive = true;
    await _publish(online: true);
    _gps?.cancel();
    _gps = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 5),
    ).listen(_onGps, onError: (Object _) {});
    _pubTimer?.cancel();
    _pubTimer = Timer.periodic(const Duration(seconds: 4), (_) => _publish());
    try {
      await WakelockPlus.enable();
    } catch (_) {}
    unawaited(refreshBuses());
    notifyListeners();
    return null;
  }

  Future<void> endTrip() async {
    _gps?.cancel();
    _gps = null;
    _pubTimer?.cancel();
    _pubTimer = null;
    tripActive = false;
    try {
      await WakelockPlus.disable();
    } catch (_) {}
    try {
      await _db?.rpc('driver_update_bus', params: <String, dynamic>{'p_online': false});
    } catch (_) {}
    unawaited(refreshBuses());
    notifyListeners();
  }

  void _onGps(Position p) {
    _lastPos = LatLng(p.latitude, p.longitude);
    _lastSpeed = (p.speed.isFinite && p.speed > 0) ? p.speed : 0;
    userPos = _lastPos;
    notifyListeners();
  }

  Future<void> _publish({bool? online}) async {
    final p = _lastPos;
    if (p == null || _db == null) return;
    try {
      await _db!.rpc('driver_update_bus', params: <String, dynamic>{
        'p_lat': p.latitude,
        'p_lng': p.longitude,
        'p_speed': _lastSpeed,
        'p_onboard': myBus?.onboard,
        'p_online': online ?? true,
      });
    } catch (_) {}
  }

  Future<void> adjustOnboard(int delta) async {
    final b = myBus;
    if (b == null) return;
    b.onboard = (b.onboard + delta).clamp(0, 999).toInt();
    notifyListeners();
    try {
      await _db!.rpc('driver_update_bus', params: <String, dynamic>{'p_onboard': b.onboard});
    } catch (_) {}
  }

  Future<String?> sendReport(String type, String note) async {
    try {
      await _db!.rpc('driver_report', params: <String, dynamic>{
        'p_type': type,
        'p_note': note,
        'p_fault': type == kReportTypes.first,
      });
      unawaited(refreshBuses());
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  // ───────────────────────── التذاكر والدفع ─────────────────────────

  String _err(Object e) {
    final m = e is PostgrestException ? e.message : e.toString();
    if (m.contains('no line')) return 'هذه الحافلة غير مرتبطة بخط.';
    if (m.contains('not allowed')) return 'غير مسموح لك بهذه العملية.';
    if (m.contains('disabled')) return 'حسابك موقوف.';
    if (m.contains('only passengers')) return 'الحجز متاح لحسابات الركاب.';
    if (m.contains('no bus')) return 'لم تُعيَّن لك حافلة.';
    return 'تعذّرت العملية، تحقق من الإنترنت وأعد المحاولة.';
  }

  Future<String?> createTicket(Bus b, String method, {String ref = '', bool walkup = false}) async {
    try {
      await _db!.rpc('create_ticket', params: <String, dynamic>{
        'p_bus': b.id,
        'p_method': method,
        'p_ref': ref,
        'p_walkup': walkup,
      });
      if (walkup) await adjustOnboard(1);
      await refreshTickets();
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  Future<String?> confirmTicket(Ticket t) async {
    try {
      await _db!.rpc('confirm_ticket', params: <String, dynamic>{'p_id': t.id});
      if (role == Role.driver) await adjustOnboard(1);
      await refreshTickets();
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  Future<String?> cancelTicket(Ticket t) async {
    try {
      await _db!.rpc('cancel_ticket', params: <String, dynamic>{'p_id': t.id});
      await refreshTickets();
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  List<Ticket> ticketsOn(DateTime day, {bool paidOnly = true}) {
    return tickets.where((t) {
      final c = t.createdAt;
      return c.year == day.year && c.month == day.month && c.day == day.day && (!paidOnly || t.paid);
    }).toList();
  }

  List<Ticket> get pendingElectronic => tickets.where((t) => t.pending && !t.isCash).toList();
  List<Ticket> get pendingCashForMyBus {
    final id = me?.id;
    return tickets.where((t) => t.pending && t.isCash && t.driverId == id).toList();
  }

  // ───────────────────────── المالك ─────────────────────────

  Future<String?> _write(Future<dynamic> Function() op) async {
    try {
      await op();
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  Map<String, dynamic> _networkJson() => <String, dynamic>{
        'stops': stops.values.map((s) => s.toJson()).toList(),
        'lines': lines.map((l) => l.toJson()).toList(),
      };

  Future<String?> saveNetwork() => _write(() => _db!.from('config').upsert(<String, dynamic>{
        'key': 'network',
        'value': _networkJson(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }));

  Future<String?> saveSettings(AppSettings s) async {
    final err = await _write(() => _db!.from('config').upsert(<String, dynamic>{
          'key': 'settings',
          'value': s.toJson(),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        }));
    if (err == null) {
      settings = s;
      notifyListeners();
    }
    return err;
  }

  Future<String?> saveLine(
    BusLine? old, {
    required String name,
    required int fare,
    required int colorValue,
    required List<String> stopIds,
    required Map<String, Stop> stopsMap,
  }) async {
    for (final id in stopIds) {
      final s = stopsMap[id];
      if (s != null) stops[id] = s;
    }
    final l = old ??
        BusLine(
          id: 'l${DateTime.now().millisecondsSinceEpoch}',
          name: name,
          colorValue: colorValue,
          fare: fare,
          stopIds: <String>[],
        );
    final changed = old == null || l.stopIds.join(',') != stopIds.join(',');
    l.name = name;
    l.fare = fare;
    l.colorValue = colorValue;
    if (changed) {
      l.stopIds = List<String>.from(stopIds);
      l.legs = <List<LatLng>>[];
      l.snapped = false;
    }
    _invalidate(l);
    if (old == null) lines.add(l);
    _gcStops();
    notifyListeners();
    final err = await saveNetwork();
    if (err == null) unawaited(snapLine(l, announce: true));
    return err;
  }

  Future<String?> deleteLine(BusLine l) async {
    lines.remove(l);
    _paths.remove(l.id);
    _gcStops();
    notifyListeners();
    return saveNetwork();
  }

  void _gcStops() {
    final used = <String>{};
    for (final l in lines) {
      used.addAll(l.stopIds);
    }
    stops.removeWhere((k, v) => !used.contains(k));
    favStops.removeWhere((k) => !used.contains(k));
    alerts.removeWhere((k) => !used.contains(k.split('|').first));
    _saveLocal();
  }

  /// يثبّت مسار الخط على الطرق الفعلية (OSRM) ثم يحفظه للجميع.
  Future<bool> snapLine(BusLine l, {bool announce = false}) async {
    final ids = List<String>.from(l.stopIds);
    final pts = <LatLng>[];
    for (final id in ids) {
      final s = stops[id];
      if (s == null) return false;
      pts.add(s.pos);
    }
    if (pts.length < 2) return false;
    final legs = <List<LatLng>>[];
    var okCount = 0;
    for (var i = 0; i < pts.length; i++) {
      final a = pts[i];
      final b = pts[(i + 1) % pts.length];
      final g = await osrmLeg(a, b);
      if (g != null) {
        legs.add(g);
        okCount++;
      } else {
        legs.add(<LatLng>[a, b]);
      }
    }
    if (ids.join(',') != l.stopIds.join(',') || !lines.contains(l)) return false;
    if (okCount == 0) {
      if (announce) _msg.add('تعذّر الاتصال بخدمة الطرق؛ سيُرسم الخط مستقيماً بين المحطات.');
      return false;
    }
    l.legs = legs;
    l.snapped = okCount == pts.length;
    _invalidate(l);
    notifyListeners();
    final err = await saveNetwork();
    if (announce) _msg.add(err == null ? 'تم تثبيت «${l.shortName}» على الطرق الفعلية ✓' : err);
    return err == null;
  }

  Future<String?> saveBus({
    Bus? old,
    required String number,
    required String lineId,
    required int capacity,
    Profile? driver,
  }) async {
    final data = <String, dynamic>{
      'number': number,
      'line_id': lineId,
      'capacity': capacity,
      'driver_id': driver?.id,
      'driver_name': driver?.name ?? '',
    };
    final err = await _write(() async {
      if (driver != null) {
        // السائق يقود حافلة واحدة فقط
        var q = _db!.from('buses').update(<String, dynamic>{'driver_id': null, 'driver_name': ''}).eq('driver_id', driver.id);
        if (old != null) q = q.neq('id', old.id);
        await q;
      }
      if (old == null) {
        await _db!.from('buses').insert(data);
      } else {
        await _db!.from('buses').update(data).eq('id', old.id);
      }
    });
    await refreshBuses();
    return err;
  }

  Future<String?> deleteBus(Bus b) async {
    final err = await _write(() => _db!.from('buses').delete().eq('id', b.id));
    await refreshBuses();
    return err;
  }

  Future<String?> updateDriver(Profile p, {bool? approved, bool? active, double? percent, bool clearPercent = false}) async {
    final data = <String, dynamic>{};
    if (approved != null) data['approved'] = approved;
    if (active != null) data['active'] = active;
    if (clearPercent) {
      data['driver_percent'] = null;
    } else if (percent != null) {
      data['driver_percent'] = percent;
    }
    final err = await _write(() => _db!.from('profiles').update(data).eq('id', p.id));
    await refreshSlow();
    return err;
  }

  Future<String?> resolveReport(Report r) async {
    final err = await _write(() => _db!.rpc('resolve_report', params: <String, dynamic>{'p_id': r.id}));
    await refreshSlow();
    unawaited(refreshBuses());
    return err;
  }

  /// amount > 0: السائق دفع للإدارة، amount < 0: الإدارة دفعت للسائق
  Future<String?> addSettlement(String driverId, int amount, String note) async {
    final err = await _write(() => _db!.from('settlements').insert(<String, dynamic>{
          'driver_id': driverId,
          'amount': amount,
          'note': note,
          'created_by': me?.id,
        }));
    await refreshSlow();
    return err;
  }

  // ───────────────────────── المفضلة والمظهر ─────────────────────────

  void toggleFav(String stopId) {
    if (!favStops.remove(stopId)) favStops.add(stopId);
    _saveLocal();
    notifyListeners();
  }

  void toggleAlert(String stopId, String lineId) {
    final k = '$stopId|$lineId';
    if (!alerts.remove(k)) {
      alerts.add(k);
      _msg.add('سنُنبّهك عندما يقترب الباص من المحطة (أثناء فتح التطبيق).');
    }
    _saveLocal();
    notifyListeners();
  }

  void setTheme(ThemeMode m) {
    themeMode.value = m;
    _saveLocal();
  }

  String exportNetworkJson() => const JsonEncoder.withIndent('  ').convert(_networkJson());

  @override
  void dispose() {
    _busTimer?.cancel();
    _slowTimer?.cancel();
    _pubTimer?.cancel();
    _gps?.cancel();
    _msg.close();
    super.dispose();
  }
}
