import 'package:latlong2/latlong.dart' show LatLng;

const List<String> kReportTypes = <String>[
  'عطل ميكانيكي',
  'حادث',
  'ازدحام مروري',
  'تأخير',
  'أخرى',
];

/// طرق الدفع: الرمز في قاعدة البيانات → الاسم المعروض.
const Map<String, String> kMethods = <String, String>{
  'cash': 'نقداً',
  'zaincash': 'زين كاش',
  'fastpay': 'فاست باي',
  'qi': 'كي كارد',
  'asiapay': 'آسيا باي',
};

class Stop {
  Stop(this.id, this.name, this.pos);
  final String id;
  String name;
  LatLng pos;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'lat': pos.latitude,
        'lng': pos.longitude,
      };

  factory Stop.fromJson(Map<String, dynamic> j) => Stop(
        j['id'] as String,
        j['name'] as String,
        LatLng((j['lat'] as num).toDouble(), (j['lng'] as num).toDouble()),
      );
}

/// خط دائري: يمرّ بالمحطات بالترتيب ثم يعود إلى المحطة الأولى.
class BusLine {
  BusLine({
    required this.id,
    required this.name,
    required this.colorValue,
    required this.fare,
    required this.stopIds,
    List<List<LatLng>>? legs,
    this.snapped = false,
  }) : legs = legs ?? <List<LatLng>>[];

  final String id;
  String name;
  int colorValue;
  int fare;
  List<String> stopIds;
  List<List<LatLng>> legs; // هندسة الطريق بين كل محطتين متتاليتين
  bool snapped;

  String get shortName => name.split(' — ').first;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'color': colorValue,
        'fare': fare,
        'stops': stopIds,
        'snapped': snapped,
        'legs': legs
            .map((leg) => leg
                .map((p) => [
                      double.parse(p.latitude.toStringAsFixed(5)),
                      double.parse(p.longitude.toStringAsFixed(5)),
                    ])
                .toList())
            .toList(),
      };

  factory BusLine.fromJson(Map<String, dynamic> j) {
    final legs = <List<LatLng>>[];
    for (final leg in (j['legs'] as List<dynamic>? ?? <dynamic>[])) {
      final pts = <LatLng>[];
      for (final p in (leg as List<dynamic>)) {
        final xy = p as List<dynamic>;
        pts.add(LatLng((xy[0] as num).toDouble(), (xy[1] as num).toDouble()));
      }
      legs.add(pts);
    }
    return BusLine(
      id: j['id'] as String,
      name: j['name'] as String,
      colorValue: j['color'] as int,
      fare: (j['fare'] as num).toInt(),
      stopIds: (j['stops'] as List<dynamic>).map((e) => e as String).toList(),
      legs: legs,
      snapped: j['snapped'] as bool? ?? false,
    );
  }
}


DateTime _dt(dynamic v) => v == null ? DateTime.fromMillisecondsSinceEpoch(0) : DateTime.parse(v as String).toLocal();
double _num(dynamic v, [double def = 0]) => v == null ? def : (v as num).toDouble();

enum Role { passenger, driver, owner }

Role roleFrom(String? s) => s == 'owner' ? Role.owner : (s == 'driver' ? Role.driver : Role.passenger);

class Profile {
  Profile({
    required this.id,
    required this.role,
    required this.name,
    required this.phone,
    required this.approved,
    required this.active,
    this.driverPercent,
  });

  final String id;
  Role role;
  String name;
  String phone;
  bool approved;
  bool active;
  double? driverPercent;

  factory Profile.fromJson(Map<String, dynamic> j) => Profile(
        id: j['id'] as String,
        role: roleFrom(j['role'] as String?),
        name: j['name'] as String? ?? '',
        phone: j['phone'] as String? ?? '',
        approved: j['approved'] as bool? ?? true,
        active: j['active'] as bool? ?? true,
        driverPercent: j['driver_percent'] == null ? null : _num(j['driver_percent']),
      );
}

class Bus {
  Bus({
    required this.id,
    required this.number,
    required this.lineId,
    this.driverId,
    this.driverName = '',
    this.capacity = 30,
    this.online = false,
    this.fault = false,
    this.onboard = 0,
    this.pos,
    this.speed = 0,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.fromMillisecondsSinceEpoch(0);

  final String id;
  String number;
  String lineId;
  String? driverId;
  String driverName;
  int capacity;
  bool online;
  bool fault;
  int onboard;
  LatLng? pos;
  double speed; // م/ث
  DateTime updatedAt;

  // يُحسب محلياً بإسقاط الموقع على مسار الخط
  double d = 0;

  double get loadRatio => capacity <= 0 ? 0 : onboard / capacity;
  String get loadLabel => loadRatio < 0.4 ? 'خفيف' : (loadRatio < 0.8 ? 'متوسط' : 'مزدحم');
  bool get fresh => DateTime.now().difference(updatedAt).inSeconds < 120;

  factory Bus.fromJson(Map<String, dynamic> j) => Bus(
        id: j['id'] as String,
        number: j['number'] as String? ?? '',
        lineId: j['line_id'] as String? ?? '',
        driverId: j['driver_id'] as String?,
        driverName: j['driver_name'] as String? ?? '',
        capacity: (j['capacity'] as num?)?.toInt() ?? 30,
        online: j['online'] as bool? ?? false,
        fault: j['fault'] as bool? ?? false,
        onboard: (j['onboard'] as num?)?.toInt() ?? 0,
        pos: (j['lat'] == null || j['lng'] == null) ? null : LatLng(_num(j['lat']), _num(j['lng'])),
        speed: _num(j['speed']),
        updatedAt: _dt(j['updated_at']),
      );
}

class Ticket {
  Ticket({
    required this.id,
    required this.createdAt,
    required this.passengerId,
    required this.passengerName,
    required this.busId,
    required this.busNumber,
    required this.lineId,
    required this.lineName,
    required this.driverId,
    required this.fare,
    required this.method,
    required this.ref,
    required this.status,
    required this.percent,
    required this.driverShare,
    required this.ownerShare,
  });

  final String id;
  final DateTime createdAt;
  final String? passengerId;
  final String passengerName;
  final String? busId;
  final String busNumber;
  final String lineId;
  final String lineName;
  final String? driverId;
  final int fare;
  final String method;
  final String ref;
  final String status; // pending | paid | cancelled
  final double percent;
  final int driverShare;
  final int ownerShare;

  bool get isCash => method == 'cash';
  bool get pending => status == 'pending';
  bool get paid => status == 'paid';
  String get methodLabel => kMethods[method] ?? method;
  String get statusLabel => status == 'paid' ? 'مدفوعة' : (status == 'pending' ? 'بانتظار التأكيد' : 'ملغاة');

  factory Ticket.fromJson(Map<String, dynamic> j) => Ticket(
        id: j['id'] as String,
        createdAt: _dt(j['created_at']),
        passengerId: j['passenger_id'] as String?,
        passengerName: j['passenger_name'] as String? ?? '',
        busId: j['bus_id'] as String?,
        busNumber: j['bus_number'] as String? ?? '',
        lineId: j['line_id'] as String? ?? '',
        lineName: j['line_name'] as String? ?? '',
        driverId: j['driver_id'] as String?,
        fare: (j['fare'] as num).toInt(),
        method: j['method'] as String? ?? 'cash',
        ref: j['ref'] as String? ?? '',
        status: j['status'] as String? ?? 'pending',
        percent: _num(j['percent']),
        driverShare: (j['driver_share'] as num?)?.toInt() ?? 0,
        ownerShare: (j['owner_share'] as num?)?.toInt() ?? 0,
      );
}

class Report {
  Report({
    required this.id,
    required this.createdAt,
    required this.busNumber,
    required this.type,
    required this.note,
    required this.resolved,
  });

  final String id;
  final DateTime createdAt;
  final String busNumber;
  final String type;
  final String note;
  final bool resolved;

  factory Report.fromJson(Map<String, dynamic> j) => Report(
        id: j['id'] as String,
        createdAt: _dt(j['created_at']),
        busNumber: j['bus_number'] as String? ?? '',
        type: j['type'] as String? ?? '',
        note: j['note'] as String? ?? '',
        resolved: j['resolved'] as bool? ?? false,
      );
}

class Settlement {
  Settlement(this.id, this.createdAt, this.amount, this.note);
  final String id;
  final DateTime createdAt;
  final int amount; // موجب: السائق دفع للإدارة، سالب: الإدارة دفعت للسائق
  final String note;

  factory Settlement.fromJson(Map<String, dynamic> j) => Settlement(
        j['id'] as String,
        _dt(j['created_at']),
        (j['amount'] as num).toInt(),
        j['note'] as String? ?? '',
      );
}

class DriverBalance {
  DriverBalance({
    required this.driverId,
    required this.name,
    required this.phone,
    required this.rides,
    required this.gross,
    required this.driverTotal,
    required this.net,
  });

  final String driverId;
  final String name;
  final String phone;
  final int rides;
  final int gross;
  final int driverTotal;
  final int net; // > 0: على السائق للإدارة، < 0: للسائق على الإدارة

  factory DriverBalance.fromJson(Map<String, dynamic> j) => DriverBalance(
        driverId: j['driver_id'] as String,
        name: j['name'] as String? ?? '',
        phone: j['phone'] as String? ?? '',
        rides: (j['rides'] as num?)?.toInt() ?? 0,
        gross: (j['gross'] as num?)?.toInt() ?? 0,
        driverTotal: (j['driver_total'] as num?)?.toInt() ?? 0,
        net: (j['net'] as num?)?.toInt() ?? 0,
      );
}

class AppSettings {
  AppSettings({this.defaultPercent = 70, Map<String, String>? wallets}) : wallets = wallets ?? <String, String>{};
  double defaultPercent;
  Map<String, String> wallets; // method -> رقم/حساب استلام المالك

  /// طرق الدفع المتاحة للراكب: النقد دائماً + كل محفظة أدخل المالك رقمها.
  List<String> get methods => <String>['cash', ...kMethods.keys.where((k) => k != 'cash' && (wallets[k] ?? '').trim().isNotEmpty)];

  Map<String, dynamic> toJson() => {'default_percent': defaultPercent, 'wallets': wallets};

  factory AppSettings.fromJson(Map<String, dynamic> j) {
    final w = <String, String>{};
    final raw = j['wallets'];
    if (raw is Map) {
      raw.forEach((k, v) => w[k.toString()] = (v ?? '').toString());
    }
    return AppSettings(defaultPercent: _num(j['default_percent'], 70), wallets: w);
  }
}
