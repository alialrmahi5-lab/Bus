import 'dart:convert';
import 'dart:math' as math;

import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' show LatLng;

double _rad(double d) => d * math.pi / 180;

/// المسافة بالمتر بين نقطتين.
double haversine(LatLng a, LatLng b) {
  const r = 6371000.0;
  final dLat = _rad(b.latitude - a.latitude);
  final dLon = _rad(b.longitude - a.longitude);
  final sLat = math.sin(dLat / 2);
  final sLon = math.sin(dLon / 2);
  final h = sLat * sLat + math.cos(_rad(a.latitude)) * math.cos(_rad(b.latitude)) * sLon * sLon;
  return 2 * r * math.asin(math.min(1.0, math.sqrt(h)));
}

class Proj {
  const Proj(this.along, this.off);
  final double along; // المسافة على الخط
  final double off; // البعد عن الخط (متر)
}

/// مسار دائري مغلق مع مسافات تراكمية ومواضع المحطات عليه.
class RoutePath {
  RoutePath._(this.pts, this.cum, this.stopDist) : total = cum.isEmpty ? 0.0 : cum.last;

  final List<LatLng> pts;
  final List<double> cum;
  final List<double> stopDist;
  final double total;

  factory RoutePath.build(List<LatLng> stops, List<List<LatLng>> legs) {
    final pts = <LatLng>[];
    final cum = <double>[];
    final sd = <double>[];
    void add(LatLng p) {
      if (pts.isEmpty) {
        pts.add(p);
        cum.add(0.0);
        return;
      }
      final d = haversine(pts.last, p);
      if (d < 0.5) return;
      pts.add(p);
      cum.add(cum.last + d);
    }

    final n = stops.length;
    if (n >= 2) {
      for (var i = 0; i < n; i++) {
        add(stops[i]);
        sd.add(cum.last);
        if (i < legs.length) {
          for (final p in legs[i]) {
            add(p);
          }
        }
        add(stops[(i + 1) % n]);
      }
    } else {
      for (final s in stops) {
        add(s);
        sd.add(0.0);
      }
    }
    return RoutePath._(pts, cum, sd);
  }

  /// المسافة من [from] إلى [to] في اتجاه الحركة (دائرياً).
  double ahead(double from, double to) {
    if (total <= 0) return 0.0;
    var a = (to - from) % total;
    if (a < 0) a += total;
    return a;
  }

  LatLng pointAt(double d) {
    if (pts.isEmpty) return LatLng(0, 0);
    if (total <= 0 || pts.length < 2) return pts.first;
    var x = d % total;
    if (x < 0) x += total;
    var lo = 0;
    var hi = cum.length - 1;
    while (hi - lo > 1) {
      final mid = (lo + hi) >> 1;
      if (cum[mid] <= x) {
        lo = mid;
      } else {
        hi = mid;
      }
    }
    final seg = cum[hi] - cum[lo];
    final t = seg <= 0 ? 0.0 : (x - cum[lo]) / seg;
    return LatLng(
      pts[lo].latitude + (pts[hi].latitude - pts[lo].latitude) * t,
      pts[lo].longitude + (pts[hi].longitude - pts[lo].longitude) * t,
    );
  }

  /// أقرب نقطة على المسار إلى [p].
  Proj nearest(LatLng p) {
    if (pts.length < 2) return const Proj(0, double.infinity);
    final cosLat = math.cos(_rad(p.latitude));
    var best = double.infinity;
    var bestAlong = 0.0;
    for (var i = 0; i < pts.length - 1; i++) {
      final ax = (pts[i].longitude - p.longitude) * 111320 * cosLat;
      final ay = (pts[i].latitude - p.latitude) * 110540;
      final bx = (pts[i + 1].longitude - p.longitude) * 111320 * cosLat;
      final by = (pts[i + 1].latitude - p.latitude) * 110540;
      final dx = bx - ax;
      final dy = by - ay;
      final len2 = dx * dx + dy * dy;
      var t = len2 == 0 ? 0.0 : -(ax * dx + ay * dy) / len2;
      if (t < 0) t = 0;
      if (t > 1) t = 1;
      final cx = ax + dx * t;
      final cy = ay + dy * t;
      final dist = math.sqrt(cx * cx + cy * cy);
      if (dist < best) {
        best = dist;
        bestAlong = cum[i] + (cum[i + 1] - cum[i]) * t;
      }
    }
    return Proj(bestAlong, best);
  }
}

/// يجلب هندسة الطريق بين نقطتين من خادم OSRM العام (للتجربة).
Future<List<LatLng>?> osrmLeg(LatLng a, LatLng b) async {
  final url = Uri.parse(
    'https://router.project-osrm.org/route/v1/driving/'
    '${a.longitude},${a.latitude};${b.longitude},${b.latitude}'
    '?overview=full&geometries=geojson',
  );
  try {
    final r = await http
        .get(url, headers: {'User-Agent': 'bas_bus/0.2 (iq.bas.bus.bas_bus)'})
        .timeout(const Duration(seconds: 12));
    if (r.statusCode != 200) return null;
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    final routes = j['routes'] as List<dynamic>;
    if (routes.isEmpty) return null;
    final geometry = (routes[0] as Map<String, dynamic>)['geometry'] as Map<String, dynamic>;
    final coords = geometry['coordinates'] as List<dynamic>;
    final out = <LatLng>[];
    for (final c in coords) {
      final xy = c as List<dynamic>;
      out.add(LatLng((xy[1] as num).toDouble(), (xy[0] as num).toDouble()));
    }
    return out.length >= 2 ? out : null;
  } catch (_) {
    return null;
  }
}
