import 'package:flutter/material.dart';

const Color kBrand = Color(0xFF5B3DF5); // بنفسجي-نيلي
const Color kBrandDark = Color(0xFF3A22C9);
const Color kCyan = Color(0xFF06B6D4);
const Color kAccent = Color(0xFFFFB020); // عنبري

const List<int> kLineColors = <int>[
  0xFF5B3DF5, 0xFF06B6D4, 0xFFF97316, 0xFF10B981, 0xFFEC4899, 0xFFEAB308,
];

const LinearGradient kBrandGradient = LinearGradient(
  begin: Alignment.topRight,
  end: Alignment.bottomLeft,
  colors: [Color(0xFF6D4CFF), Color(0xFF3A22C9), Color(0xFF06B6D4)],
  stops: [0.0, 0.55, 1.0],
);

ThemeData buildTheme(Brightness b) {
  final scheme = ColorScheme.fromSeed(seedColor: kBrand, brightness: b);
  final dark = b == Brightness.dark;
  final bg = dark ? const Color(0xFF0E0F1A) : const Color(0xFFF5F6FB);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    fontFamily: 'Cairo',
    scaffoldBackgroundColor: bg,
    appBarTheme: AppBarTheme(
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: bg,
      foregroundColor: scheme.onSurface,
      titleTextStyle: TextStyle(
        fontFamily: 'Cairo',
        fontWeight: FontWeight.w700,
        fontSize: 20,
        color: scheme.onSurface,
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      height: 66,
      backgroundColor: scheme.surface,
      indicatorColor: scheme.primaryContainer,
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
