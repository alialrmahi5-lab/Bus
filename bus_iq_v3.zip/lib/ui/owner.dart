import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;

import '../core/geo.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

const List<String> _weekdays = ['إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت', 'أحد'];

// ───────────────────────── لوحة المؤشرات ─────────────────────────

class OwnerDashboard extends StatelessWidget {
  const OwnerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final live = store.buses.where((b) => store.isLive(b)).length;
        final today = store.ticketsOn(DateTime.now());
        final gross = today.fold<int>(0, (a, t) => a + t.fare);
        final ownerShare = today.fold<int>(0, (a, t) => a + t.ownerShare);
        final driverShare = today.fold<int>(0, (a, t) => a + t.driverShare);
        final pendingE = store.pendingElectronic.length;
        final open = store.reports.where((r) => !r.resolved).toList();
        final week = <MapEntry<DateTime, int>>[];
        for (var i = 6; i >= 0; i--) {
          final d = DateTime.now().subtract(Duration(days: i));
          week.add(MapEntry(d, store.ticketsOn(d).fold<int>(0, (a, t) => a + t.fare)));
        }
        var maxRev = 1;
        for (final e in week) {
          if (e.value > maxRev) maxRev = e.value;
        }
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Panel(
            color: cs.primaryContainer,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('إيراد اليوم', style: TextStyle(color: cs.onPrimaryContainer)),
              const SizedBox(height: 4),
              Text(fmtIqd(gross), style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: cs.onPrimaryContainer)),
              const SizedBox(height: 6),
              Text('${today.length} راكب · للإدارة ${fmtIqd(ownerShare)} · للسائقين ${fmtIqd(driverShare)}',
                  style: TextStyle(fontSize: 13, color: cs.onPrimaryContainer.withValues(alpha: 0.8))),
            ]),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _Kpi(Icons.directions_bus_rounded, '$live / ${store.buses.length}', 'حافلات مباشرة', cs.primary)),
            const SizedBox(width: 10),
            Expanded(child: _Kpi(Icons.hourglass_top_rounded, '$pendingE', 'دفعات بانتظار التأكيد', pendingE > 0 ? kAccent : cs.outline)),
          ]),
          const SizedBox(height: 18),
          const Text('الإيراد خلال 7 أيام', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Panel(
            child: SizedBox(
              height: 150,
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                for (final e in week)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                        Text(e.value == 0 ? '' : '${(e.value / 1000).round()}k', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 2),
                        Container(
                          height: 4 + 90 * (e.value / maxRev),
                          decoration: BoxDecoration(
                            color: e.key.day == DateTime.now().day ? cs.primary : cs.primary.withValues(alpha: 0.35),
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(_weekdays[e.key.weekday - 1], style: TextStyle(fontSize: 10, color: cs.onSurfaceVariant)),
                      ]),
                    ),
                  ),
              ]),
            ),
          ),
          const SizedBox(height: 4),
          Text('بالألف دينار — من التذاكر المدفوعة المؤكدة.', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
          const SizedBox(height: 18),
          Text('البلاغات المفتوحة (${open.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          if (open.isEmpty)
            Panel(
              child: Row(children: [
                const Icon(Icons.check_circle_rounded, color: Color(0xFF16A34A)),
                const SizedBox(width: 10),
                Text('لا توجد بلاغات مفتوحة', style: TextStyle(color: cs.onSurfaceVariant)),
              ]),
            )
          else
            for (final r in open.take(10))
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Panel(
                  child: Row(children: [
                    Icon(r.type == kReportTypes.first ? Icons.build_rounded : Icons.report_rounded, color: cs.error),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${r.type} — باص ${r.busNumber}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        if (r.note.isNotEmpty) Text(r.note, style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
                        Text(fmtAgo(r.createdAt.millisecondsSinceEpoch), style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                      ]),
                    ),
                    FilledButton.tonal(onPressed: () => store.resolveReport(r), child: const Text('تم الحل')),
                  ]),
                ),
              ),
        ]);
      },
    );
  }
}

class _Kpi extends StatelessWidget {
  const _Kpi(this.icon, this.value, this.label, this.color);
  final IconData icon;
  final String value;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(height: 10),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: AlignmentDirectional.centerStart,
          child: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        ),
        Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}

// ───────────────────────── الأسطول والسائقون ─────────────────────────

class FleetPage extends StatefulWidget {
  const FleetPage({super.key});

  @override
  State<FleetPage> createState() => _FleetPageState();
}

class _FleetPageState extends State<FleetPage> {
  bool _drivers = false;

  void _editBus(Bus? b) {
    if (store.lines.isEmpty) {
      snack(context, 'أضف خطاً أولاً ثم اربط الحافلة به.');
      return;
    }
    showDialog<void>(context: context, builder: (_) => _BusDialog(bus: b));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: _drivers
          ? null
          : FloatingActionButton.extended(
              heroTag: 'addBus',
              onPressed: () => _editBus(null),
              icon: const Icon(Icons.add_rounded),
              label: const Text('إضافة حافلة'),
            ),
      body: ListenableBuilder(
        listenable: store,
        builder: (c, _) {
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 90), children: [
            SegmentedButton<bool>(
              segments: [
                const ButtonSegment<bool>(value: false, label: Text('الحافلات'), icon: Icon(Icons.directions_bus_rounded)),
                ButtonSegment<bool>(
                  value: true,
                  label: Text('السائقون${store.drivers.any((d) => !d.approved) ? ' •' : ''}'),
                  icon: const Icon(Icons.badge_rounded),
                ),
              ],
              selected: <bool>{_drivers},
              onSelectionChanged: (s) => setState(() => _drivers = s.first),
            ),
            const SizedBox(height: 12),
            if (_drivers) ..._driverCards(c) else ..._busCards(c),
          ]);
        },
      ),
    );
  }

  List<Widget> _busCards(BuildContext c) {
    final cs = Theme.of(c).colorScheme;
    return [
      if (store.buses.isEmpty) const Text('لا توجد حافلات. اضغط «إضافة حافلة».'),
      for (final b in store.buses)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('باص ${b.number}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(width: 10),
                if (store.lineById(b.lineId) != null) LineBadge(store.lineById(b.lineId)!) else const Text('بلا خط'),
                const Spacer(),
                if (b.fault) const Pill('معطّلة', Color(0xFFDC2626), icon: Icons.build_rounded) else if (store.isLive(b)) const Pill('مباشر', Color(0xFF16A34A), icon: Icons.sensors_rounded) else const Pill('غير متصل', Color(0xFF6B7280)),
              ]),
              InfoRow(Icons.person_rounded, b.driverName.isEmpty ? 'بلا سائق' : b.driverName),
              InfoRow(Icons.groups_rounded, 'الركاب ${b.onboard} / ${b.capacity}'),
              Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                IconButton(tooltip: 'تعديل', icon: const Icon(Icons.edit_rounded), onPressed: () => _editBus(b)),
                IconButton(
                  tooltip: 'حذف',
                  icon: Icon(Icons.delete_outline_rounded, color: cs.error),
                  onPressed: () async {
                    final ok = await _confirm(c, 'حذف حافلة ${b.number}؟');
                    if (!ok) return;
                    final err = await store.deleteBus(b);
                    if (err != null && c.mounted) snack(c, err);
                  },
                ),
              ]),
            ]),
          ),
        ),
    ];
  }

  List<Widget> _driverCards(BuildContext c) {
    final cs = Theme.of(c).colorScheme;
    return [
      if (store.drivers.isEmpty) const Text('لم يسجّل أي سائق بعد. يسجّل السائق حسابه من التطبيق ثم توافق عليه هنا.'),
      for (final d in store.drivers)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(d.name.isEmpty ? 'سائق' : d.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
                if (!d.approved) const Pill('بانتظار الموافقة', Color(0xFFD97706), icon: Icons.hourglass_top_rounded) else if (!d.active) const Pill('موقوف', Color(0xFFDC2626)) else const Pill('نشط', Color(0xFF16A34A)),
              ]),
              InfoRow(Icons.phone_rounded, d.phone),
              InfoRow(
                Icons.percent_rounded,
                d.driverPercent == null ? 'النسبة: افتراضية (${store.settings.defaultPercent.toStringAsFixed(0)}%)' : 'النسبة: ${d.driverPercent!.toStringAsFixed(d.driverPercent! == d.driverPercent!.roundToDouble() ? 0 : 1)}%',
              ),
              InfoRow(
                Icons.directions_bus_rounded,
                () {
                  for (final b in store.buses) {
                    if (b.driverId == d.id) return 'الحافلة: ${b.number}';
                  }
                  return 'بلا حافلة (عيّنه من تعديل الحافلة)';
                }(),
              ),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 4, children: [
                if (!d.approved)
                  FilledButton.icon(
                    icon: const Icon(Icons.check_rounded),
                    label: const Text('موافقة'),
                    onPressed: () async {
                      final err = await store.updateDriver(d, approved: true);
                      if (err != null && c.mounted) snack(c, err);
                    },
                  ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.percent_rounded),
                  label: const Text('النسبة'),
                  onPressed: () => _editPercent(d),
                ),
                if (d.approved)
                  TextButton(
                    style: TextButton.styleFrom(foregroundColor: d.active ? cs.error : null),
                    onPressed: () async {
                      final err = await store.updateDriver(d, active: !d.active);
                      if (err != null && c.mounted) snack(c, err);
                    },
                    child: Text(d.active ? 'إيقاف الحساب' : 'تفعيل الحساب'),
                  ),
              ]),
            ]),
          ),
        ),
    ];
  }

  Future<void> _editPercent(Profile d) async {
    final ctl = TextEditingController(text: d.driverPercent == null ? '' : d.driverPercent!.toStringAsFixed(0));
    final res = await showDialog<String>(
      context: context,
      builder: (x) => AlertDialog(
        title: Text('نسبة ${d.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(
            controller: ctl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: 'نسبة السائق من كل أجرة (%)', hintText: 'فارغ = الافتراضية ${store.settings.defaultPercent.toStringAsFixed(0)}'),
          ),
          const SizedBox(height: 8),
          const Text('تُطبَّق على الرحلات الجديدة فقط.', style: TextStyle(fontSize: 12)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(x), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(x, ctl.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
    if (res == null || !mounted) return;
    String? err;
    if (res.isEmpty) {
      err = await store.updateDriver(d, clearPercent: true);
    } else {
      final v = double.tryParse(res.replaceAll(',', '.'));
      if (v == null || v < 0 || v > 100) {
        snack(context, 'أدخل نسبة بين 0 و 100.');
        return;
      }
      err = await store.updateDriver(d, percent: v);
    }
    if (err != null && mounted) snack(context, err);
  }
}

class _BusDialog extends StatefulWidget {
  const _BusDialog({this.bus});
  final Bus? bus;

  @override
  State<_BusDialog> createState() => _BusDialogState();
}

class _BusDialogState extends State<_BusDialog> {
  late final TextEditingController _num;
  late final TextEditingController _cap;
  String? _lineId;
  String? _driverId;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final b = widget.bus;
    _num = TextEditingController(text: b?.number ?? '');
    _cap = TextEditingController(text: '${b?.capacity ?? 30}');
    _lineId = (b != null && store.lineById(b.lineId) != null) ? b.lineId : (store.lines.isEmpty ? null : store.lines.first.id);
    _driverId = b?.driverId;
  }

  @override
  void dispose() {
    _num.dispose();
    _cap.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final n = _num.text.trim();
    if (n.isEmpty || _lineId == null) {
      snack(context, 'أدخل رقم الحافلة واختر الخط.');
      return;
    }
    Profile? drv;
    for (final d in store.drivers) {
      if (d.id == _driverId) drv = d;
    }
    final cap = (int.tryParse(_cap.text.trim()) ?? 30).clamp(1, 200).toInt();
    setState(() => _busy = true);
    final err = await store.saveBus(old: widget.bus, number: n, lineId: _lineId!, capacity: cap, driver: drv);
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      snack(context, err);
      return;
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final approved = store.drivers.where((d) => d.approved && d.active).toList();
    return AlertDialog(
      title: Text(widget.bus == null ? 'إضافة حافلة' : 'تعديل الحافلة'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(controller: _num, decoration: const InputDecoration(labelText: 'رقم الحافلة')),
          const SizedBox(height: 8),
          TextField(controller: _cap, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعة (راكب)')),
          const SizedBox(height: 14),
          const Text('الخط', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, children: [
            for (final l in store.lines) ChoiceChip(label: Text(l.shortName), selected: _lineId == l.id, onSelected: (_) => setState(() => _lineId = l.id)),
          ]),
          const SizedBox(height: 14),
          const Text('السائق', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, children: [
            ChoiceChip(label: const Text('بلا سائق'), selected: _driverId == null, onSelected: (_) => setState(() => _driverId = null)),
            for (final d in approved) ChoiceChip(label: Text(d.name), selected: _driverId == d.id, onSelected: (_) => setState(() => _driverId = d.id)),
          ]),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('حفظ')),
      ],
    );
  }
}

// ───────────────────────── المالية ─────────────────────────

class FinancePage extends StatelessWidget {
  const FinancePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final pending = store.pendingElectronic;
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Text('دفعات إلكترونية بانتظار التأكيد (${pending.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('طابق رقم العملية مع كشف محفظتك ثم أكّد.', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          const SizedBox(height: 8),
          if (pending.isEmpty)
            Panel(child: Text('لا توجد دفعات معلّقة.', style: TextStyle(color: cs.onSurfaceVariant)))
          else
            for (final t in pending)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Panel(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Icon(methodIcon(t.method), color: cs.primary),
                      const SizedBox(width: 8),
                      Expanded(child: Text('${t.methodLabel} · ${fmtIqd(t.fare)}', style: const TextStyle(fontWeight: FontWeight.w800))),
                      Text(fmtDate(t.createdAt), style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                    ]),
                    InfoRow(Icons.person_rounded, '${t.passengerName} — باص ${t.busNumber}'),
                    InfoRow(Icons.tag_rounded, 'رقم العملية: ${t.ref.isEmpty ? '—' : t.ref}'),
                    const SizedBox(height: 6),
                    Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                      TextButton(
                        style: TextButton.styleFrom(foregroundColor: cs.error),
                        onPressed: () => store.cancelTicket(t),
                        child: const Text('رفض'),
                      ),
                      const SizedBox(width: 6),
                      FilledButton(
                        onPressed: () async {
                          final err = await store.confirmTicket(t);
                          if (err != null && c.mounted) snack(c, err);
                        },
                        child: const Text('تأكيد الاستلام'),
                      ),
                    ]),
                  ]),
                ),
              ),
          const SizedBox(height: 18),
          const Text('حسابات السائقين', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          if (store.balances.isEmpty) Text('لا يوجد سائقون بعد.', style: TextStyle(color: cs.onSurfaceVariant)),
          for (final b in store.balances)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Panel(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(b.name.isEmpty ? 'سائق' : b.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                    Text('${b.rides} راكب', style: TextStyle(color: cs.onSurfaceVariant)),
                  ]),
                  InfoRow(Icons.payments_rounded, 'إجمالي ما جمعه: ${fmtIqd(b.gross)}'),
                  InfoRow(Icons.savings_rounded, 'مجموع حصته: ${fmtIqd(b.driverTotal)}'),
                  const SizedBox(height: 6),
                  Row(children: [
                    Expanded(
                      child: Text(
                        b.net > 0 ? 'عليه للإدارة ${fmtIqd(b.net)}' : (b.net < 0 ? 'له على الإدارة ${fmtIqd(-b.net)}' : 'الحساب مسوّى'),
                        style: TextStyle(fontWeight: FontWeight.w800, color: b.net > 0 ? const Color(0xFFD97706) : (b.net < 0 ? cs.primary : const Color(0xFF16A34A))),
                      ),
                    ),
                    if (b.net != 0)
                      FilledButton.tonal(
                        onPressed: () => _settle(c, b),
                        child: const Text('تسجيل تسوية'),
                      ),
                  ]),
                ]),
              ),
            ),
          const SizedBox(height: 18),
          const _SettingsPanel(),
        ]);
      },
    );
  }

  Future<void> _settle(BuildContext c, DriverBalance b) async {
    final ctl = TextEditingController(text: '${b.net.abs()}');
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
        title: Text(b.net > 0 ? 'استلام من ${b.name}' : 'دفع إلى ${b.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: ctl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ (د.ع)')),
          const SizedBox(height: 8),
          TextField(controller: note, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('تسجيل')),
        ],
      ),
    );
    final amount = int.tryParse(ctl.text.trim().replaceAll(',', ''));
    final noteText = note.text.trim();
    if (ok != true || amount == null || amount <= 0 || !c.mounted) return;
    final err = await store.addSettlement(b.driverId, b.net > 0 ? amount : -amount, noteText);
    if (c.mounted) snack(c, err ?? 'تم تسجيل التسوية.');
  }
}

class _SettingsPanel extends StatefulWidget {
  const _SettingsPanel();

  @override
  State<_SettingsPanel> createState() => _SettingsPanelState();
}

class _SettingsPanelState extends State<_SettingsPanel> {
  late final TextEditingController _pct;
  final Map<String, TextEditingController> _w = {};
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final s = store.settings;
    _pct = TextEditingController(text: s.defaultPercent.toStringAsFixed(s.defaultPercent == s.defaultPercent.roundToDouble() ? 0 : 1));
    for (final k in kMethods.keys) {
      if (k == 'cash') continue;
      _w[k] = TextEditingController(text: s.wallets[k] ?? '');
    }
  }

  @override
  void dispose() {
    _pct.dispose();
    for (final c in _w.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final v = double.tryParse(_pct.text.trim().replaceAll(',', '.'));
    if (v == null || v < 0 || v > 100) {
      snack(context, 'أدخل نسبة بين 0 و 100.');
      return;
    }
    final wallets = <String, String>{for (final e in _w.entries) e.key: e.value.text.trim()};
    setState(() => _busy = true);
    final err = await store.saveSettings(AppSettings(defaultPercent: v, wallets: wallets));
    if (!mounted) return;
    setState(() => _busy = false);
    snack(context, err ?? 'تم حفظ الإعدادات.');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('إعدادات الدفع والنسب', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Panel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(
            controller: _pct,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'نسبة السائق الافتراضية من كل أجرة (%)'),
          ),
          const SizedBox(height: 16),
          Text('حسابات استلام الدفع الإلكتروني', style: TextStyle(fontWeight: FontWeight.w800, color: cs.primary)),
          Text('تظهر للراكب كخيار دفع فقط إذا أدخلت رقم/حساب الاستلام.', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          const SizedBox(height: 8),
          for (final e in _w.entries)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: TextField(
                controller: e.value,
                decoration: InputDecoration(labelText: kMethods[e.key], prefixIcon: Icon(methodIcon(e.key))),
              ),
            ),
          const SizedBox(height: 6),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _busy ? null : _save,
              child: const Text('حفظ الإعدادات'),
            ),
          ),
        ]),
      ),
    ]);
  }
}

Future<bool> _confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('تأكيد')),
      ],
    ),
  );
  return r ?? false;
}

// ───────────────────────── إدارة الخطوط ─────────────────────────

class LinesAdminPage extends StatelessWidget {
  const LinesAdminPage({super.key});

  void _open(BuildContext context, BusLine? l) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => LineEditorPage(line: l)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'addLine',
        onPressed: () => _open(context, null),
        icon: const Icon(Icons.add_road_rounded),
        label: const Text('خط جديد'),
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (c, _) {
          final cs = Theme.of(c).colorScheme;
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 90), children: [
            Text(
              'ارسم خطك بالنقر على الخريطة لإضافة المحطات؛ يثبّت التطبيق المسار على الطرق الفعلية تلقائياً.',
              style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
            ),
            const SizedBox(height: 10),
            for (final l in store.lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Panel(
                  onTap: () => _open(c, l),
                  child: Row(children: [
                    Container(width: 8, height: 46, decoration: BoxDecoration(color: lineColor(l), borderRadius: BorderRadius.circular(6))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(l.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text(
                          '${l.stopIds.length} محطات · ${fmtIqd(l.fare)} · ${store.pathOf(l).total >= 1000 ? '${(store.pathOf(l).total / 1000).toStringAsFixed(1)} كم' : '${store.pathOf(l).total.round()} م'}',
                          style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                        ),
                        Row(children: [
                          Icon(l.snapped ? Icons.check_circle_rounded : Icons.timeline_rounded, size: 14, color: l.snapped ? const Color(0xFF16A34A) : cs.outline),
                          const SizedBox(width: 4),
                          Text(l.snapped ? 'مثبّت على الطرق' : 'خط مستقيم بين المحطات', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                        ]),
                      ]),
                    ),
                    if (!l.snapped)
                      IconButton(
                        tooltip: 'تثبيت على الطرق',
                        icon: const Icon(Icons.alt_route_rounded),
                        onPressed: () => unawaited(store.snapLine(l, announce: true)),
                      ),
                    const Icon(Icons.chevron_left_rounded),
                  ]),
                ),
              ),
          ]);
        },
      ),
    );
  }
}

class LineEditorPage extends StatefulWidget {
  const LineEditorPage({super.key, this.line});
  final BusLine? line;

  @override
  State<LineEditorPage> createState() => _LineEditorPageState();
}

class _LineEditorPageState extends State<LineEditorPage> {
  late final TextEditingController _name;
  late final TextEditingController _fare;
  late int _color;
  late List<String> _ids;
  late Map<String, Stop> _local;
  final MapController _map = MapController();

  @override
  void initState() {
    super.initState();
    final l = widget.line;
    _name = TextEditingController(text: l?.name ?? 'خط جديد');
    _fare = TextEditingController(text: '${l?.fare ?? 1000}');
    _color = l?.colorValue ?? kLineColors[store.lines.length % kLineColors.length];
    _ids = List<String>.from(l?.stopIds ?? <String>[]);
    _local = <String, Stop>{};
    for (final e in store.stops.entries) {
      _local[e.key] = Stop(e.value.id, e.value.name, e.value.pos);
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _fare.dispose();
    super.dispose();
  }

  LatLng _center() {
    if (_ids.isNotEmpty && _local[_ids.first] != null) return _local[_ids.first]!.pos;
    final list = store.servedStops();
    return list.isEmpty ? LatLng(32.0003, 44.3148) : list.first.pos;
  }

  void _onTap(LatLng p) {
    Stop? near;
    var best = 40.0;
    for (final s in _local.values) {
      final d = haversine(s.pos, p);
      if (d < best) {
        best = d;
        near = s;
      }
    }
    if (near != null) {
      if (_ids.contains(near.id)) {
        snack(context, 'هذه المحطة مضافة مسبقاً إلى الخط.');
        return;
      }
      final id = near.id;
      setState(() => _ids.add(id));
    } else {
      final id = 's${DateTime.now().microsecondsSinceEpoch}';
      setState(() {
        _local[id] = Stop(id, 'محطة ${_ids.length + 1}', p);
        _ids.add(id);
      });
    }
  }

  Future<void> _rename(String id) async {
    final s = _local[id];
    if (s == null) return;
    final ctl = TextEditingController(text: s.name);
    final name = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('اسم المحطة'),
        content: TextField(controller: ctl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, ctl.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
    if (name != null && name.isNotEmpty) setState(() => s.name = name);
  }

  bool _saving = false;

  Future<void> _save() async {
    if (_ids.length < 2) {
      snack(context, 'أضف محطتين على الأقل.');
      return;
    }
    final nm = _name.text.trim().isEmpty ? 'خط جديد' : _name.text.trim();
    final fare = int.tryParse(_fare.text.trim()) ?? 1000;
    setState(() => _saving = true);
    final err = await store.saveLine(widget.line, name: nm, fare: fare, colorValue: _color, stopIds: _ids, stopsMap: _local);
    if (!mounted) return;
    setState(() => _saving = false);
    if (err != null) {
      snack(context, err);
      return;
    }
    Navigator.pop(context);
  }

  Future<void> _delete() async {
    final l = widget.line;
    if (l == null) return;
    final ok = await _confirm(context, 'حذف «${l.name}» نهائياً؟');
    if (!ok || !mounted) return;
    final err = await store.deleteLine(l);
    if (!mounted) return;
    if (err != null) {
      snack(context, err);
      return;
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final color = Color(_color);
    final pts = <LatLng>[];
    for (final id in _ids) {
      final s = _local[id];
      if (s != null) pts.add(s.pos);
    }
    final loop = pts.length >= 2 ? <LatLng>[...pts, pts.first] : pts;
    final markers = <Marker>[];
    for (final s in _local.values) {
      if (_ids.contains(s.id)) continue;
      markers.add(Marker(
        point: s.pos,
        width: 30,
        height: 30,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => _onTap(s.pos),
          child: Center(child: Container(width: 12, height: 12, decoration: BoxDecoration(color: Colors.grey, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
        ),
      ));
    }
    for (var i = 0; i < _ids.length; i++) {
      final s = _local[_ids[i]];
      if (s == null) continue;
      markers.add(Marker(
        point: s.pos,
        width: 34,
        height: 34,
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 6)],
          ),
          child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
        ),
      ));
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.line == null ? 'خط جديد' : 'تعديل الخط'),
        actions: [
          if (widget.line != null) IconButton(tooltip: 'حذف الخط', icon: Icon(Icons.delete_outline_rounded, color: cs.error), onPressed: _delete),
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 8),
            child: FilledButton(onPressed: _saving ? null : _save, child: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('حفظ')),
          ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Row(children: [
            Expanded(flex: 3, child: TextField(controller: _name, decoration: const InputDecoration(labelText: 'اسم الخط (مثال: الخط الأول — المطار)', isDense: true))),
            const SizedBox(width: 10),
            Expanded(flex: 2, child: TextField(controller: _fare, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الأجرة (د.ع)', isDense: true))),
          ]),
        ),
        SizedBox(
          height: 38,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            for (final cv in kLineColors)
              GestureDetector(
                onTap: () => setState(() => _color = cv),
                child: Container(
                  width: 30,
                  height: 30,
                  margin: const EdgeInsetsDirectional.only(end: 10),
                  decoration: BoxDecoration(
                    color: Color(cv),
                    shape: BoxShape.circle,
                    border: Border.all(color: _color == cv ? cs.onSurface : Colors.transparent, width: 3),
                  ),
                ),
              ),
          ]),
        ),
        Expanded(
          flex: 5,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: FlutterMap(
              mapController: _map,
              options: MapOptions(
                initialCenter: _center(),
                initialZoom: 14,
                minZoom: 6,
                maxZoom: 19,
                interactionOptions: const InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
                onTap: (tapPosition, point) => _onTap(point),
              ),
              children: [
                TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'iq.bas.bus.bas_bus'),
                PolylineLayer(polylines: [
                  if (loop.length >= 2) Polyline(points: loop, strokeWidth: 5, color: color.withValues(alpha: 0.85), borderStrokeWidth: 1.5, borderColor: Colors.white),
                ]),
                MarkerLayer(markers: markers),
                RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: Row(children: [
            Expanded(child: Text('المحطات (${_ids.length}) — انقر على الخريطة للإضافة، واسحب لإعادة الترتيب', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant))),
          ]),
        ),
        Expanded(
          flex: 4,
          child: ReorderableListView(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            onReorder: (o, n) => setState(() {
              if (n > o) n -= 1;
              final id = _ids.removeAt(o);
              _ids.insert(n, id);
            }),
            children: [
              for (var i = 0; i < _ids.length; i++)
                ListTile(
                  key: ValueKey(_ids[i]),
                  dense: true,
                  leading: CircleAvatar(radius: 13, backgroundColor: color, child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800))),
                  title: Text(_local[_ids[i]]?.name ?? '—'),
                  onTap: () => _rename(_ids[i]),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(icon: const Icon(Icons.edit_rounded, size: 20), onPressed: () => _rename(_ids[i])),
                    IconButton(icon: Icon(Icons.close_rounded, size: 20, color: cs.error), onPressed: () => setState(() => _ids.removeAt(i))),
                    const SizedBox(width: 24),
                  ]),
                ),
            ],
          ),
        ),
      ]),
    );
  }
}
