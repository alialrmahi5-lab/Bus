import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;

import '../core/geo.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

// ───────────────────────── الخريطة ─────────────────────────

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final MapController _map = MapController();
  bool _ready = false;
  String? _selLine;
  String? _selBus;

  @override
  void initState() {
    super.initState();
    focusLine.addListener(_onFocus);
    WidgetsBinding.instance.addPostFrameCallback((_) => _locate(silent: true));
  }

  @override
  void dispose() {
    focusLine.removeListener(_onFocus);
    super.dispose();
  }

  void _onFocus() {
    final id = focusLine.value;
    if (id == null) return;
    setState(() => _selLine = id);
    _fitLine(id);
    focusLine.value = null;
  }

  void _fitLine(String id) {
    if (!_ready) return;
    final l = store.lineById(id);
    if (l == null) return;
    final pts = store.pathOf(l).pts;
    if (pts.length < 2) return;
    try {
      _map.fitCamera(CameraFit.bounds(
        bounds: LatLngBounds.fromPoints(pts),
        padding: const EdgeInsets.fromLTRB(40, 110, 40, 230),
      ));
    } catch (_) {}
  }

  Future<void> _locate({bool silent = false}) async {
    final err = await store.locate();
    if (!mounted) return;
    if (err == null) {
      final u = store.userPos;
      if (u != null && _ready) _map.move(u, 15);
    } else if (!silent) {
      snack(context, err);
    }
  }

  LatLng _initialCenter() {
    final list = store.servedStops();
    if (list.isEmpty) return LatLng(32.0003, 44.3148);
    var la = 0.0;
    var lo = 0.0;
    for (final s in list) {
      la += s.pos.latitude;
      lo += s.pos.longitude;
    }
    return LatLng(la / list.length, lo / list.length);
  }

  void _openStop(Stop s) => showSheet<void>(context, (_) => StopSheet(stop: s));

  void _openBus(Bus b) {
    setState(() => _selBus = b.id);
    showSheet<void>(context, (_) => BusSheet(busId: b.id));
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      PositionedDirectional(
        start: 0,
        end: 0,
        top: 0,
        bottom: 0,
        child: ListenableBuilder(listenable: store, builder: (c, _) => _buildMap(c)),
      ),
      PositionedDirectional(
        top: 8,
        start: 12,
        end: 12,
        child: Panel(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          onTap: () => showSheet<void>(context, (_) => const PlannerSheet()),
          child: Row(children: [
            const Icon(Icons.search_rounded),
            const SizedBox(width: 10),
            const Expanded(child: Text('إلى أين تريد الذهاب؟', style: TextStyle(fontWeight: FontWeight.w700))),
            Icon(Icons.route_rounded, color: Theme.of(context).colorScheme.primary),
          ]),
        ),
      ),
      PositionedDirectional(
        bottom: 26,
        start: 12,
        end: 12,
        child: ListenableBuilder(listenable: store, builder: (c, _) => _bottom(c)),
      ),
    ]);
  }

  Widget _buildMap(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final polylines = <Polyline>[];
    final markers = <Marker>[];
    final seen = <String>{};
    for (final l in store.lines) {
      final sel = _selLine == null || _selLine == l.id;
      final p = store.pathOf(l);
      if (p.pts.length >= 2) {
        polylines.add(Polyline(
          points: p.pts,
          strokeWidth: sel ? 6.0 : 3.0,
          color: lineColor(l).withValues(alpha: sel ? 0.95 : 0.3),
          borderStrokeWidth: sel ? 1.5 : 0.0,
          borderColor: Colors.white,
        ));
      }
      if (!sel) continue;
      for (final id in l.stopIds) {
        if (!seen.add(id)) continue;
        final s = store.stops[id];
        if (s == null) continue;
        markers.add(Marker(
          point: s.pos,
          width: 36,
          height: 36,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => _openStop(s),
            child: stopDot(lineColor(l), fav: store.favStops.contains(id)),
          ),
        ));
      }
    }
    for (final b in store.buses) {
      if (!store.isLive(b)) continue;
      final l = store.lineById(b.lineId);
      if (l == null) continue;
      if (_selLine != null && _selLine != l.id) continue;
      final pos = b.pos;
      if (pos == null) continue;
      markers.add(Marker(
        point: pos,
        width: 48,
        height: 48,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => _openBus(b),
          child: busDot(lineColor(l), fault: b.fault, selected: _selBus == b.id),
        ),
      ));
    }
    final u = store.userPos;
    if (u != null) {
      markers.add(Marker(point: u, width: 44, height: 44, child: userDot()));
    }

    Widget tiles = TileLayer(
      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      userAgentPackageName: 'iq.bas.bus.bas_bus',
    );
    if (dark) {
      tiles = ColorFiltered(
        colorFilter: const ColorFilter.matrix(<double>[
          -0.1807, -0.6079, -0.0614, 0, 245,
          -0.1807, -0.6079, -0.0614, 0, 250,
          -0.1807, -0.6079, -0.0614, 0, 248,
          0, 0, 0, 1, 0,
        ]),
        child: tiles,
      );
    }

    return FlutterMap(
      mapController: _map,
      options: MapOptions(
        initialCenter: _initialCenter(),
        initialZoom: 13.5,
        minZoom: 6,
        maxZoom: 19,
        interactionOptions: const InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
        onMapReady: () {
          _ready = true;
          final uu = store.userPos;
          if (uu != null) _map.move(uu, 14.5);
        },
        onTap: (tapPosition, point) {
          if (_selBus != null) setState(() => _selBus = null);
        },
      ),
      children: [
        tiles,
        PolylineLayer(polylines: polylines),
        MarkerLayer(markers: markers),
        RichAttributionWidget(
          attributions: [TextSourceAttribution('OpenStreetMap contributors')],
        ),
      ],
    );
  }

  Widget _bottom(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Align(
        alignment: AlignmentDirectional.centerEnd,
        child: FloatingActionButton.small(
          heroTag: 'locate',
          onPressed: _locate,
          child: const Icon(Icons.my_location_rounded),
        ),
      ),
      const SizedBox(height: 8),
      SizedBox(
        height: 40,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          for (final l in store.lines)
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: ChoiceChip(
                label: Text(l.shortName, style: const TextStyle(fontWeight: FontWeight.w700)),
                avatar: CircleAvatar(backgroundColor: lineColor(l), radius: 6),
                selected: _selLine == l.id,
                selectedColor: lineColor(l).withValues(alpha: 0.2),
                backgroundColor: cs.surface,
                onSelected: (v) {
                  setState(() => _selLine = v ? l.id : null);
                  if (v) _fitLine(l.id);
                },
              ),
            ),
        ]),
      ),
      const SizedBox(height: 8),
      _NearestCard(onLocate: _locate),
    ]);
  }
}

/// بطاقة "أقرب باص" بحسب موقع المستخدم.
class _NearestCard extends StatelessWidget {
  const _NearestCard({required this.onLocate});
  final VoidCallback onLocate;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final u = store.userPos;
    if (u == null) {
      return Panel(
        onTap: onLocate,
        child: Row(children: [
          Icon(Icons.near_me_rounded, color: cs.primary),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('اضغط لتحديد موقعك ومعرفة أقرب باص إليك', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ]),
      );
    }
    final stop = store.nearestStop(u);
    if (stop == null) {
      return const Panel(child: Text('لا توجد محطات بعد.'));
    }
    final walk = haversine(u, stop.pos);
    final walkSecs = walk / 1.3;
    final arr = store.arrivalsAt(stop.id);
    if (arr.isEmpty) {
      return Panel(
        onTap: () => showSheet<void>(context, (_) => StopSheet(stop: stop)),
        child: Row(children: [
          Icon(Icons.hourglass_empty_rounded, color: cs.onSurfaceVariant),
          const SizedBox(width: 12),
          Expanded(
            child: Text('أقرب محطة: ${stop.name} (${fmtDist(walk)}) — لا توجد باصات متصلة حالياً',
                style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
        ]),
      );
    }
    final a = arr.first;
    final makeIt = a.secs >= walkSecs;
    return Panel(
      onTap: () => showSheet<void>(context, (_) => StopSheet(stop: stop)),
      child: Row(children: [
        Container(
          width: 56,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(color: lineColor(a.line).withValues(alpha: 0.14), borderRadius: BorderRadius.circular(14)),
          child: Column(children: [
            Text(fmtEta(a.secs), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: lineColor(a.line))),
            Text('أقرب باص', style: TextStyle(fontSize: 9, color: cs.onSurfaceVariant)),
          ]),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              LineBadge(a.line),
              const SizedBox(width: 8),
              Text('باص ${a.bus.number}', style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(width: 8),
              LoadChip(a.bus),
            ]),
            const SizedBox(height: 4),
            Text(stop.name, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(
              'مشي ${fmtEta(walkSecs)} (${fmtDist(walk)}) — ${makeIt ? 'تلحقه إن خرجت الآن' : 'قد يفوتك، الباص التالي أنسب'}',
              style: TextStyle(fontSize: 12, color: makeIt ? const Color(0xFF16A34A) : const Color(0xFFD97706)),
            ),
          ]),
        ),
      ]),
    );
  }
}

// ───────────────────────── ورقة المحطة ─────────────────────────

class StopSheet extends StatelessWidget {
  const StopSheet({super.key, required this.stop});
  final Stop stop;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final arr = store.arrivalsAt(stop.id);
        final lns = store.lines.where((l) => l.stopIds.contains(stop.id)).toList();
        final fav = store.favStops.contains(stop.id);
        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                Expanded(child: Text(stop.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                IconButton(
                  tooltip: 'المفضلة',
                  icon: Icon(fav ? Icons.star_rounded : Icons.star_border_rounded, color: fav ? kAccent : null, size: 28),
                  onPressed: () => store.toggleFav(stop.id),
                ),
              ]),
              Wrap(spacing: 6, runSpacing: 6, children: [for (final l in lns) LineBadge(l)]),
              const SizedBox(height: 14),
              if (arr.isEmpty)
                Text('لا توجد باصات قادمة حالياً.', style: TextStyle(color: cs.onSurfaceVariant))
              else
                for (final a in arr.take(6))
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Panel(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: Row(children: [
                        SizedBox(
                          width: 58,
                          child: Text(fmtEta(a.secs),
                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: lineColor(a.line))),
                        ),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            LineBadge(a.line),
                            const SizedBox(height: 4),
                            Row(children: [
                              Text('باص ${a.bus.number}', style: const TextStyle(fontSize: 13)),
                              const SizedBox(width: 8),
                              LoadChip(a.bus),
                            ]),
                          ]),
                        ),
                        IconButton(
                          tooltip: 'نبّهني عند اقترابه',
                          icon: Icon(
                            store.alerts.contains('${stop.id}|${a.line.id}')
                                ? Icons.notifications_active_rounded
                                : Icons.notifications_none_rounded,
                            color: store.alerts.contains('${stop.id}|${a.line.id}') ? kAccent : null,
                          ),
                          onPressed: () => store.toggleAlert(stop.id, a.line.id),
                        ),
                      ]),
                    ),
                  ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  icon: const Icon(Icons.flag_rounded),
                  label: const Text('اذهب إلى هنا'),
                  onPressed: () {
                    Navigator.pop(c);
                    showSheet<void>(navKey.currentContext!, (_) => PlannerSheet(to: stop));
                  },
                ),
              ),
            ]),
          ),
        );
      },
    );
  }
}

// ───────────────────────── ورقة الباص ─────────────────────────

class BusSheet extends StatelessWidget {
  const BusSheet({super.key, required this.busId});
  final String busId;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final b = store.busById(busId);
        final l = b == null ? null : store.lineById(b.lineId);
        if (b == null || l == null) {
          return const Padding(padding: EdgeInsets.all(24), child: Text('لم يعد هذا الباص متاحاً.'));
        }
        final ni = store.nextStopIndex(b);
        final next = ni == null ? null : store.stops[l.stopIds[ni]];
        final eta = next == null ? null : store.etaTo(b, next.id);
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('باص ${b.number}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(width: 10),
                LineBadge(l),
                const Spacer(),
                LoadChip(b),
              ]),
              const SizedBox(height: 10),
              if (b.fault)
                const InfoRow(Icons.build_rounded, 'الباص متوقف بسبب عطل — لن يصل في موعده')
              else if (next != null)
                InfoRow(Icons.arrow_circle_left_rounded, 'المحطة التالية: ${next.name} — ${fmtEta(eta)}'),
              InfoRow(Icons.person_rounded, 'السائق: ${b.driverName.isEmpty ? '—' : b.driverName}'),
              InfoRow(Icons.groups_rounded, 'الركاب: ${b.onboard} من ${b.capacity}'),
              InfoRow(Icons.payments_rounded, 'الأجرة: ${fmtIqd(l.fare)}'),
              const SizedBox(height: 12),
              if (store.role == Role.passenger && !b.fault)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      icon: const Icon(Icons.confirmation_number_rounded),
                      label: const Text('ركبت هذا الباص — ادفع الأجرة'),
                      onPressed: () {
                        Navigator.pop(c);
                        showSheet<void>(navKey.currentContext!, (_) => PaySheet(busId: b.id));
                      },
                    ),
                  ),
                ),
              if (next != null)
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.place_rounded),
                    label: Text('محطة ${next.name}'),
                    onPressed: () {
                      Navigator.pop(c);
                      showSheet<void>(navKey.currentContext!, (_) => StopSheet(stop: next));
                    },
                  ),
                ),
            ]),
          ),
        );
      },
    );
  }
}

// ───────────────────────── مخطط الرحلة ─────────────────────────

class PlannerSheet extends StatefulWidget {
  const PlannerSheet({super.key, this.to});
  final Stop? to;

  @override
  State<PlannerSheet> createState() => _PlannerSheetState();
}

class _PlannerSheetState extends State<PlannerSheet> {
  Stop? _from;
  Stop? _to;

  @override
  void initState() {
    super.initState();
    _to = widget.to;
    final u = store.userPos;
    if (u != null) _from = store.nearestStop(u);
    final all = store.servedStops();
    if (_from == null && all.isNotEmpty) _from = all.first;
    if (_from != null && _to != null && _from!.id == _to!.id) _from = null;
  }

  Future<void> _pick(bool isFrom) async {
    final s = await pickStop(context, title: isFrom ? 'من أين؟' : 'إلى أين؟');
    if (s == null || !mounted) return;
    setState(() {
      if (isFrom) {
        _from = s;
      } else {
        _to = s;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final from = _from;
        final to = _to;
        final opts = (from != null && to != null) ? store.plan(from.id, to.id) : <TripOption>[];
        final u = store.userPos;
        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('خطّط رحلتك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: Column(children: [
                    _SelTile(icon: Icons.trip_origin_rounded, label: 'من', stop: from, onTap: () => _pick(true)),
                    const SizedBox(height: 8),
                    _SelTile(icon: Icons.flag_rounded, label: 'إلى', stop: to, onTap: () => _pick(false)),
                  ]),
                ),
                IconButton(
                  tooltip: 'عكس',
                  icon: const Icon(Icons.swap_vert_rounded),
                  onPressed: () => setState(() {
                    final t = _from;
                    _from = _to;
                    _to = t;
                  }),
                ),
              ]),
              const SizedBox(height: 14),
              if (from == null || to == null)
                Text('اختر محطة الصعود ومحطة النزول.', style: TextStyle(color: cs.onSurfaceVariant))
              else if (from.id == to.id)
                Text('محطة الصعود والنزول متطابقتان.', style: TextStyle(color: cs.onSurfaceVariant))
              else if (opts.isEmpty)
                Text('لا يوجد خط مباشر بين المحطتين حالياً.', style: TextStyle(color: cs.onSurfaceVariant))
              else
                for (final o in opts)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Panel(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          LineBadge(o.line),
                          const Spacer(),
                          Text(
                            o.waitSecs == null ? 'لا باص' : 'يصل ${fmtEta(o.waitSecs)}',
                            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: lineColor(o.line)),
                          ),
                        ]),
                        if (o.bus != null) InfoRow(Icons.directions_bus_rounded, 'باص ${o.bus!.number} هو الأقرب إلى ${from.name}'),
                        InfoRow(Icons.timer_rounded, 'مدة الركوب ≈ ${fmtEta(o.rideSecs)} · ${o.hops} ${o.hops == 1 ? 'محطة' : 'محطات'}'),
                        InfoRow(Icons.payments_rounded, 'الأجرة ${fmtIqd(o.line.fare)}'),
                        if (u != null) InfoRow(Icons.directions_walk_rounded, 'المشي إلى ${from.name}: ${fmtDist(haversine(u, from.pos))}'),
                        if (o.bus == null) const InfoRow(Icons.info_outline_rounded, 'لا توجد باصات متصلة على هذا الخط الآن'),
                        const SizedBox(height: 8),
                        Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: TextButton.icon(
                            icon: const Icon(Icons.map_rounded),
                            label: const Text('عرض على الخريطة'),
                            onPressed: () {
                              Navigator.pop(c);
                              navIndex.value = 0;
                              focusLine.value = o.line.id;
                            },
                          ),
                        ),
                      ]),
                    ),
                  ),
            ]),
          ),
        );
      },
    );
  }
}

class _SelTile extends StatelessWidget {
  const _SelTile({required this.icon, required this.label, required this.stop, required this.onTap});
  final IconData icon;
  final String label;
  final Stop? stop;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Panel(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      onTap: onTap,
      child: Row(children: [
        Icon(icon, size: 20, color: cs.primary),
        const SizedBox(width: 10),
        Text('$label  ', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
        Expanded(
          child: Text(
            stop?.name ?? (label == 'من' ? 'اختر محطة الصعود' : 'اختر محطة النزول'),
            style: TextStyle(fontWeight: FontWeight.w700, color: stop == null ? cs.onSurfaceVariant : null),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Icon(Icons.expand_more_rounded, color: cs.onSurfaceVariant),
      ]),
    );
  }
}

// ───────────────────────── صفحة الخطوط ─────────────────────────

class LinesPage extends StatelessWidget {
  const LinesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final favs = store.servedStops().where((s) => store.favStops.contains(s.id)).toList();
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
          if (favs.isNotEmpty) ...[
            const Padding(
              padding: EdgeInsets.fromLTRB(4, 4, 4, 8),
              child: Text('محطاتي المفضلة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            for (final s in favs)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Panel(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  onTap: () => showSheet<void>(c, (_) => StopSheet(stop: s)),
                  child: Row(children: [
                    const Icon(Icons.star_rounded, color: kAccent),
                    const SizedBox(width: 10),
                    Expanded(child: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700))),
                    Text(fmtEta(store.arrivalsAt(s.id).isEmpty ? null : store.arrivalsAt(s.id).first.secs),
                        style: TextStyle(fontWeight: FontWeight.w800, color: cs.primary)),
                  ]),
                ),
              ),
            const SizedBox(height: 8),
          ],
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 4, 4, 8),
            child: Text('خطوط الباص', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          ),
          if (store.lines.isEmpty) const Text('لا توجد خطوط بعد — ستظهر هنا فور أن تضيفها الإدارة.'),
          for (final l in store.lines) _LineCard(line: l),
        ]);
      },
    );
  }
}

class _LineCard extends StatelessWidget {
  const _LineCard({required this.line});
  final BusLine line;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final live = store.buses.where((b) => b.lineId == line.id && store.isLive(b)).length;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Panel(
        padding: EdgeInsets.zero,
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            leading: Container(
              width: 8,
              height: 44,
              decoration: BoxDecoration(color: lineColor(line), borderRadius: BorderRadius.circular(6)),
            ),
            title: Text(line.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(
              '${line.stopIds.length} محطات · ${fmtIqd(line.fare)} · $live ${live == 1 ? 'باص' : 'باصات'} متصلة',
              style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
            ),
            children: [
              for (final id in line.stopIds)
                if (store.stops[id] != null)
                  ListTile(
                    dense: true,
                    leading: Icon(Icons.circle, size: 12, color: lineColor(line)),
                    title: Text(store.stops[id]!.name),
                    trailing: Text(
                      fmtEta(store.arrivalsAt(id, lineId: line.id).isEmpty ? null : store.arrivalsAt(id, lineId: line.id).first.secs),
                      style: TextStyle(fontWeight: FontWeight.w800, color: lineColor(line)),
                    ),
                    onTap: () => showSheet<void>(context, (_) => StopSheet(stop: store.stops[id]!)),
                  ),
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonalIcon(
                    icon: const Icon(Icons.map_rounded),
                    label: const Text('عرض الخط على الخريطة'),
                    onPressed: () {
                      navIndex.value = 0;
                      focusLine.value = line.id;
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


// ───────────────────────── الدفع ─────────────────────────

class PaySheet extends StatefulWidget {
  const PaySheet({super.key, required this.busId});
  final String busId;

  @override
  State<PaySheet> createState() => _PaySheetState();
}

class _PaySheetState extends State<PaySheet> {
  String _method = 'cash';
  final TextEditingController _ref = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _ref.dispose();
    super.dispose();
  }

  Future<void> _pay(Bus b) async {
    final isCash = _method == 'cash';
    if (!isCash && _ref.text.trim().length < 4) {
      snack(context, 'أدخل رقم العملية (الحوالة) بعد التحويل.');
      return;
    }
    if (store.tickets.any((t) => t.busId == b.id && t.pending && t.passengerId == store.me?.id)) {
      snack(context, 'لديك طلب دفع معلّق لهذا الباص بالفعل.');
      return;
    }
    setState(() => _busy = true);
    final err = await store.createTicket(b, _method, ref: _ref.text.trim());
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      snack(context, err);
      return;
    }
    final msg = isCash ? 'تم الطلب — سلّم الأجرة نقداً للسائق ليؤكد الاستلام.' : 'تم تسجيل الدفع — بانتظار تأكيد الإدارة.';
    final host = navKey.currentContext;
    Navigator.pop(context);
    if (host != null) snack(host, msg);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final b = store.busById(widget.busId);
        final l = b == null ? null : store.lineById(b.lineId);
        if (b == null || l == null) {
          return const Padding(padding: EdgeInsets.all(24), child: Text('لم يعد هذا الباص متاحاً.'));
        }
        final methods = store.settings.methods;
        final wallet = store.settings.wallets[_method] ?? '';
        return SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(c).viewInsets.bottom),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('باص ${b.number}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(width: 10),
                LineBadge(l),
              ]),
              const SizedBox(height: 14),
              Panel(
                color: lineColor(l).withValues(alpha: 0.08),
                child: Row(children: [
                  const Text('الأجرة', style: TextStyle(fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Text(fmtIqd(l.fare), style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: lineColor(l))),
                ]),
              ),
              const SizedBox(height: 14),
              const Text('طريقة الدفع', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final m in methods)
                  ChoiceChip(
                    avatar: Icon(methodIcon(m), size: 18),
                    label: Text(kMethods[m] ?? m),
                    selected: _method == m,
                    onSelected: (_) => setState(() => _method = m),
                  ),
              ]),
              const SizedBox(height: 12),
              if (_method == 'cash')
                Text('ادفع نقداً للسائق، وسيؤكد استلام المبلغ من هاتفه.', style: TextStyle(color: cs.onSurfaceVariant))
              else ...[
                Panel(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('حوّل ${fmtIqd(l.fare)} عبر ${kMethods[_method]} إلى:', style: TextStyle(color: cs.onSurfaceVariant)),
                    const SizedBox(height: 6),
                    Row(children: [
                      Expanded(child: SelectableText(wallet, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                      IconButton(
                        tooltip: 'نسخ',
                        icon: const Icon(Icons.copy_rounded),
                        onPressed: () async {
                          await Clipboard.setData(ClipboardData(text: wallet));
                          if (c.mounted) snack(c, 'تم نسخ الرقم.');
                        },
                      ),
                    ]),
                  ]),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _ref,
                  decoration: InputDecoration(
                    labelText: 'رقم العملية / الحوالة بعد التحويل',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                  onPressed: _busy ? null : () => _pay(b),
                  child: _busy
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                      : Text(_method == 'cash' ? 'تأكيد — سأدفع نقداً' : 'تأكيد الدفع', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                ),
              ),
            ]),
          ),
        );
      },
    );
  }
}

// ───────────────────────── رحلاتي ─────────────────────────

class RidesPage extends StatelessWidget {
  const RidesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final list = store.tickets;
        final paid = list.where((t) => t.paid).toList();
        final spent = paid.fold<int>(0, (a, t) => a + t.fare);
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Row(children: [
            Expanded(child: _MiniStat(Icons.confirmation_number_rounded, '${paid.length}', 'رحلاتك المدفوعة')),
            const SizedBox(width: 10),
            Expanded(child: _MiniStat(Icons.payments_rounded, fmtIqd(spent), 'إجمالي ما دفعته')),
          ]),
          const SizedBox(height: 16),
          const Text('سجل الرحلات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          if (list.isEmpty)
            Text('لا توجد رحلات بعد. اضغط على باص في الخريطة ثم «ركبت هذا الباص».', style: TextStyle(color: cs.onSurfaceVariant)),
          for (final t in list)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Panel(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text('${t.lineName} — باص ${t.busNumber}', style: const TextStyle(fontWeight: FontWeight.w800))),
                    Pill(t.statusLabel, statusColor(t)),
                  ]),
                  InfoRow(Icons.schedule_rounded, fmtDate(t.createdAt)),
                  InfoRow(methodIcon(t.method), '${t.methodLabel} · ${fmtIqd(t.fare)}${t.ref.isEmpty ? '' : ' · عملية ${t.ref}'}'),
                  if (t.pending)
                    Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: TextButton(
                        onPressed: () async {
                          final err = await store.cancelTicket(t);
                          if (err != null && c.mounted) snack(c, err);
                        },
                        child: const Text('إلغاء الطلب'),
                      ),
                    ),
                ]),
              ),
            ),
        ]);
      },
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat(this.icon, this.value, this.label);
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: cs.primary),
        const SizedBox(height: 6),
        FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
        Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}
