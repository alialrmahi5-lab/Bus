import 'package:flutter/material.dart';

import '../core/models.dart';
import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

class DriverPage extends StatefulWidget {
  const DriverPage({super.key});

  @override
  State<DriverPage> createState() => _DriverPageState();
}

class _DriverPageState extends State<DriverPage> {
  String _type = kReportTypes.first;
  bool _busy = false;
  final TextEditingController _note = TextEditingController();

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    setState(() => _busy = true);
    final err = await store.startTrip();
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) snack(context, err);
  }

  Future<void> _report() async {
    final err = await store.sendReport(_type, _note.text.trim());
    if (!mounted) return;
    if (err == null) _note.clear();
    snack(context, err ?? 'تم إرسال البلاغ إلى الإدارة.');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final b = store.myBus;
        final l = b == null ? null : store.lineById(b.lineId);
        final active = store.tripActive;
        if (b == null || l == null) {
          return ListView(padding: const EdgeInsets.all(16), children: [
            Panel(
              child: Column(children: [
                Icon(Icons.directions_bus_outlined, size: 44, color: cs.primary),
                const SizedBox(height: 10),
                const Text('لم تُعيَّن لك حافلة بعد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(
                  b == null ? 'ستعيّن لك الإدارة حافلة وخطاً، وستظهر هنا تلقائياً.' : 'حافلتك غير مرتبطة بخط سير. تواصل مع الإدارة.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: cs.onSurfaceVariant),
                ),
              ]),
            ),
          ]);
        }
        final pending = store.pendingCashForMyBus;
        final waitingElec = store.tickets.where((t) => t.pending && !t.isCash && t.driverId == store.me?.id).toList();
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Panel(
            child: Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(color: lineColor(l).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(16)),
                child: Icon(Icons.directions_bus_rounded, color: lineColor(l), size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('باص ${b.number}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  LineBadge(l),
                ]),
              ),
              if (active) const Pill('مباشر', Color(0xFF16A34A), icon: Icons.sensors_rounded) else const Pill('متوقف', Color(0xFF6B7280)),
            ]),
          ),
          const SizedBox(height: 14),
          if (!active) ...[
            Panel(
              child: Row(children: [
                Icon(Icons.info_outline_rounded, color: cs.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'عند بدء الرحلة يُرسل هاتفك موقع الحافلة للركاب كل بضع ثوانٍ. اترك التطبيق مفتوحاً؛ تبقى الشاشة مضاءة تلقائياً.',
                    style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant, height: 1.6),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 56,
              child: FilledButton.icon(
                icon: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Icon(Icons.play_arrow_rounded),
                label: const Text('ابدأ الرحلة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                onPressed: _busy ? null : _start,
              ),
            ),
          ] else ...[
            _NextStopCard(bus: b, line: l),
            const SizedBox(height: 12),
            _Counter(bus: b, line: l),
            const SizedBox(height: 12),
            if (pending.isNotEmpty) ...[
              const _Title('ركاب بانتظار تأكيد الدفع النقدي'),
              for (final t in pending)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Panel(
                    child: Row(children: [
                      const Icon(Icons.payments_rounded, color: Color(0xFF16A34A)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(t.passengerName.isEmpty ? 'راكب' : t.passengerName, style: const TextStyle(fontWeight: FontWeight.w800)),
                          Text('نقداً · ${fmtIqd(t.fare)}', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                        ]),
                      ),
                      IconButton(
                        tooltip: 'رفض',
                        icon: Icon(Icons.close_rounded, color: cs.error),
                        onPressed: () => store.cancelTicket(t),
                      ),
                      FilledButton(
                        onPressed: () async {
                          final err = await store.confirmTicket(t);
                          if (err != null && c.mounted) snack(c, err);
                        },
                        child: const Text('استلمت'),
                      ),
                    ]),
                  ),
                ),
              const SizedBox(height: 4),
            ],
            if (waitingElec.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  '${waitingElec.length} دفعة إلكترونية بانتظار تأكيد الإدارة — يمكن للراكب الصعود.',
                  style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                ),
              ),
            SizedBox(
              height: 50,
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFDC2626)),
                icon: const Icon(Icons.stop_circle_rounded),
                label: const Text('إنهاء الرحلة', style: TextStyle(fontWeight: FontWeight.w800)),
                onPressed: store.endTrip,
              ),
            ),
          ],
          const SizedBox(height: 18),
          const _Title('الإبلاغ عن عطل'),
          Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 8, runSpacing: 6, children: [
                for (final t in kReportTypes) ChoiceChip(label: Text(t), selected: _type == t, onSelected: (_) => setState(() => _type = t)),
              ]),
              const SizedBox(height: 10),
              TextField(
                controller: _note,
                maxLines: 2,
                decoration: InputDecoration(hintText: 'ملاحظات (اختياري)', border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton.tonalIcon(
                  icon: const Icon(Icons.send_rounded),
                  label: const Text('إرسال بلاغ إلى الإدارة'),
                  onPressed: _report,
                ),
              ),
              if (b.fault)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text('الحافلة مُعلَّمة متعطّلة حتى تُغلق الإدارة البلاغ.', style: TextStyle(fontSize: 12, color: cs.error)),
                ),
            ]),
          ),
        ]);
      },
    );
  }
}

class _Title extends StatelessWidget {
  const _Title(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
      child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
    );
  }
}

class _NextStopCard extends StatelessWidget {
  const _NextStopCard({required this.bus, required this.line});
  final Bus bus;
  final BusLine line;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ni = store.nextStopIndex(bus);
    final n = line.stopIds.length;
    final order = <Stop>[];
    if (ni != null) {
      for (var k = 0; k < n; k++) {
        final s = store.stops[line.stopIds[(ni + k) % n]];
        if (s != null) order.add(s);
      }
    }
    final next = order.isEmpty ? null : order.first;
    final eta = next == null ? null : store.etaTo(bus, next.id);
    return Panel(
      color: lineColor(line).withValues(alpha: 0.08),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('المحطة التالية', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
        Row(children: [
          Expanded(child: Text(next?.name ?? '—', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
          Text(fmtEta(eta), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: lineColor(line))),
        ]),
        const SizedBox(height: 10),
        for (var i = 0; i < order.length; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(children: [
              Icon(i == 0 ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, size: 16, color: i == 0 ? lineColor(line) : cs.outline),
              const SizedBox(width: 8),
              Text(order[i].name, style: TextStyle(fontWeight: i == 0 ? FontWeight.w700 : FontWeight.w400)),
            ]),
          ),
      ]),
    );
  }
}

class _Counter extends StatelessWidget {
  const _Counter({required this.bus, required this.line});
  final Bus bus;
  final BusLine line;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Panel(
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          IconButton.filledTonal(iconSize: 30, onPressed: () => store.adjustOnboard(-1), icon: const Icon(Icons.remove_rounded)),
          Column(children: [
            Text('${bus.onboard}', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800)),
            Row(mainAxisSize: MainAxisSize.min, children: [
              Text('من ${bus.capacity} · ', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
              LoadChip(bus),
            ]),
          ]),
          IconButton.filledTonal(iconSize: 30, onPressed: () => store.adjustOnboard(1), icon: const Icon(Icons.add_rounded)),
        ]),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            icon: const Icon(Icons.person_add_alt_1_rounded),
            label: Text('راكب نقدي بدون حساب (${fmtIqd(line.fare)})'),
            onPressed: () async {
              final err = await store.createTicket(bus, 'cash', walkup: true);
              if (err != null && context.mounted) snack(context, err);
            },
          ),
        ),
        const SizedBox(height: 6),
        Text('± لضبط عدد الركاب فقط. زر «راكب نقدي» يسجّل الأجرة في حسابك.', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}

// ───────────────────────── الأرباح ─────────────────────────

class DriverEarningsPage extends StatelessWidget {
  const DriverEarningsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final me = store.me;
        final today = store.ticketsOn(DateTime.now()).where((t) => t.driverId == me?.id).toList();
        final todayShare = today.fold<int>(0, (a, t) => a + t.driverShare);
        DriverBalance? bal;
        for (final x in store.balances) {
          if (x.driverId == me?.id) bal = x;
        }
        final net = bal?.net ?? 0;
        final pct = me?.driverPercent ?? store.settings.defaultPercent;
        final recent = store.tickets.where((t) => t.paid && t.driverId == me?.id).take(30).toList();
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Panel(
            color: cs.primaryContainer,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('أرباحك اليوم', style: TextStyle(color: cs.onPrimaryContainer)),
              const SizedBox(height: 4),
              Text(fmtIqd(todayShare), style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: cs.onPrimaryContainer)),
              const SizedBox(height: 6),
              Text('${today.length} راكب · نسبتك ${pct.toStringAsFixed(pct == pct.roundToDouble() ? 0 : 1)}% من كل أجرة',
                  style: TextStyle(color: cs.onPrimaryContainer.withValues(alpha: 0.8), fontSize: 13)),
            ]),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _Money(Icons.savings_rounded, fmtIqd(bal?.driverTotal ?? 0), 'إجمالي أرباحك')),
            const SizedBox(width: 10),
            Expanded(child: _Money(Icons.confirmation_number_rounded, '${bal?.rides ?? 0}', 'إجمالي الركاب')),
          ]),
          const SizedBox(height: 12),
          Panel(
            child: Row(children: [
              Icon(net > 0 ? Icons.call_made_rounded : (net < 0 ? Icons.call_received_rounded : Icons.check_circle_rounded),
                  color: net > 0 ? const Color(0xFFD97706) : const Color(0xFF16A34A)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    net > 0 ? 'عليك للإدارة ${fmtIqd(net)}' : (net < 0 ? 'لك على الإدارة ${fmtIqd(-net)}' : 'لا مستحقات بينك وبين الإدارة'),
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  Text(
                    net > 0
                        ? 'حصة الإدارة من النقد الذي استلمته.'
                        : (net < 0 ? 'حصتك من الدفعات الإلكترونية التي استلمتها الإدارة.' : 'حسابك مسوّى.'),
                    style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                  ),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 18),
          const _Title('آخر الرحلات'),
          if (recent.isEmpty) Text('لا توجد رحلات مدفوعة بعد.', style: TextStyle(color: cs.onSurfaceVariant)),
          for (final t in recent)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Panel(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Row(children: [
                  Icon(methodIcon(t.method), color: cs.primary, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${t.passengerName.isEmpty ? 'راكب' : t.passengerName} · ${t.methodLabel}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text(fmtDate(t.createdAt), style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                    ]),
                  ),
                  Text('+${fmtIqd(t.driverShare)}', style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF16A34A))),
                ]),
              ),
            ),
          if (store.settlements.isNotEmpty) ...[
            const SizedBox(height: 14),
            const _Title('التسويات'),
            for (final s in store.settlements)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(s.amount > 0 ? Icons.call_made_rounded : Icons.call_received_rounded, color: kAccent),
                title: Text(s.amount > 0 ? 'سلّمت للإدارة ${fmtIqd(s.amount)}' : 'استلمت من الإدارة ${fmtIqd(-s.amount)}'),
                subtitle: Text('${fmtDate(s.createdAt)}${s.note.isEmpty ? '' : ' · ${s.note}'}'),
              ),
          ],
        ]);
      },
    );
  }
}

class _Money extends StatelessWidget {
  const _Money(this.icon, this.value, this.label);
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: kAccent),
        const SizedBox(height: 6),
        FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
        Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}
