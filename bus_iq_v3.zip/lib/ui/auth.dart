import 'package:flutter/material.dart';

import '../config.dart';
import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: kBrandGradient),
        alignment: Alignment.center,
        child: const Column(mainAxisSize: MainAxisSize.min, children: [
          BrandMark(size: 96),
          SizedBox(height: 16),
          Text(kAppName, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: 1.5)),
          SizedBox(height: 28),
          SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)),
        ]),
      ),
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool _register = false;
  bool _driver = false;
  bool _hide = true;
  bool _busy = false;
  String? _error;
  final TextEditingController _name = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _pass = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    navIndex.value = 0;
    final err = _register
        ? await store.signUp(name: _name.text, phone: _phone.text, password: _pass.text, asDriver: _driver)
        : await store.signIn(_phone.text, _pass.text);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _error = err;
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final setup = store.setupError;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(24, MediaQuery.of(context).padding.top + 36, 24, 44),
            decoration: const BoxDecoration(
              gradient: kBrandGradient,
              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(36), bottomRight: Radius.circular(36)),
            ),
            child: const Column(children: [
              BrandMark(size: 84),
              SizedBox(height: 12),
              Text(kAppName, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: 1.5)),
              SizedBox(height: 2),
              Text('تنقّل بذكاء في مدينتك', style: TextStyle(color: Colors.white70, fontSize: 14)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (setup != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Panel(
                    color: cs.errorContainer,
                    child: Row(children: [
                      Icon(Icons.cloud_off_rounded, color: cs.onErrorContainer),
                      const SizedBox(width: 10),
                      Expanded(child: Text(setup, style: TextStyle(color: cs.onErrorContainer))),
                    ]),
                  ),
                ),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment<bool>(value: false, label: Text('تسجيل الدخول')),
                  ButtonSegment<bool>(value: true, label: Text('حساب جديد')),
                ],
                selected: <bool>{_register},
                onSelectionChanged: (s) => setState(() {
                  _register = s.first;
                  _error = null;
                }),
              ),
              const SizedBox(height: 16),
              if (_register) ...[
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment<bool>(value: false, label: Text('راكب'), icon: Icon(Icons.person_rounded)),
                    ButtonSegment<bool>(value: true, label: Text('سائق'), icon: Icon(Icons.airline_seat_recline_normal_rounded)),
                  ],
                  selected: <bool>{_driver},
                  onSelectionChanged: (s) => setState(() => _driver = s.first),
                ),
                const SizedBox(height: 14),
                _field(_name, 'الاسم الكامل', Icons.badge_rounded, TextInputType.name),
                const SizedBox(height: 12),
              ],
              _field(_phone, 'رقم الهاتف (07xxxxxxxxx)', Icons.phone_rounded, TextInputType.phone),
              const SizedBox(height: 12),
              TextField(
                controller: _pass,
                obscureText: _hide,
                decoration: InputDecoration(
                  labelText: 'كلمة المرور',
                  prefixIcon: const Icon(Icons.lock_rounded),
                  suffixIcon: IconButton(
                    icon: Icon(_hide ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                    onPressed: () => setState(() => _hide = !_hide),
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onSubmitted: (_) => _busy ? null : _submit(),
              ),
              if (_register && _driver)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    'حساب السائق يحتاج موافقة الإدارة وتعيين حافلة قبل بدء العمل.',
                    style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                  ),
                ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(_error!, style: TextStyle(color: cs.error, fontWeight: FontWeight.w700)),
                ),
              const SizedBox(height: 18),
              SizedBox(
                height: 54,
                child: FilledButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.5))
                      : Text(_register ? 'إنشاء الحساب' : 'دخول', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'حساب المالك يُنشأ من الإدارة ويدخل من هنا بنفس الطريقة.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, TextInputType type) {
    return TextField(
      controller: c,
      keyboardType: type,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}

/// سائق سجّل حسابه وبانتظار موافقة المالك.
class PendingPage extends StatelessWidget {
  const PendingPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const BrandMark(size: 72),
            const SizedBox(height: 24),
            Icon(Icons.hourglass_top_rounded, size: 52, color: cs.primary),
            const SizedBox(height: 14),
            const Text('حسابك قيد المراجعة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(
              'أهلاً ${store.me?.name ?? ''}. ستفعّل الإدارة حسابك وتعيّن لك حافلة، وسيفتح التطبيق تلقائياً بعد الموافقة.',
              textAlign: TextAlign.center,
              style: TextStyle(color: cs.onSurfaceVariant, height: 1.7),
            ),
            const SizedBox(height: 24),
            FilledButton.tonalIcon(
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('تحديث الحالة'),
              onPressed: store.refreshSlow,
            ),
            TextButton(onPressed: store.signOut, child: const Text('تسجيل الخروج')),
          ]),
        ),
      ),
    );
  }
}
