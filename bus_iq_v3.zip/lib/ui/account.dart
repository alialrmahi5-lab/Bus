import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../config.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../data/store.dart';
import 'common.dart';

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (c, _) {
        final cs = Theme.of(c).colorScheme;
        final me = store.me;
        return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Panel(
            child: Row(children: [
              CircleAvatar(radius: 28, backgroundColor: cs.primaryContainer, child: Icon(roleIcon(store.role), color: cs.primary, size: 30)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(me?.name.isEmpty ?? true ? 'مستخدم' : me!.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  Text(me?.phone ?? '', style: TextStyle(color: cs.onSurfaceVariant)),
                ]),
              ),
              Pill(roleLabel(store.role), cs.primary),
            ]),
          ),
          if (store.role == Role.driver) ...[
            const _Title('نسبتك'),
            Panel(
              child: Row(children: [
                Icon(Icons.percent_rounded, color: cs.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'تحصل على ${(me?.driverPercent ?? store.settings.defaultPercent).toStringAsFixed(0)}% من كل أجرة.',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ]),
            ),
          ],
          const _Title('المظهر'),
          Panel(
            child: ValueListenableBuilder<ThemeMode>(
              valueListenable: store.themeMode,
              builder: (c2, m, _) => SegmentedButton<ThemeMode>(
                segments: const [
                  ButtonSegment<ThemeMode>(value: ThemeMode.system, label: Text('تلقائي'), icon: Icon(Icons.brightness_auto_rounded)),
                  ButtonSegment<ThemeMode>(value: ThemeMode.light, label: Text('فاتح'), icon: Icon(Icons.light_mode_rounded)),
                  ButtonSegment<ThemeMode>(value: ThemeMode.dark, label: Text('داكن'), icon: Icon(Icons.dark_mode_rounded)),
                ],
                selected: <ThemeMode>{m},
                onSelectionChanged: (s) => store.setTheme(s.first),
              ),
            ),
          ),
          const _Title('الموقع'),
          Panel(
            child: Row(children: [
              Icon(Icons.my_location_rounded, color: cs.primary),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  store.userPos == null ? 'لم يُحدَّد موقعك بعد' : 'تم تحديد موقع هاتفك',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              FilledButton.tonal(
                onPressed: () async {
                  final err = await store.locate();
                  if (c.mounted) snack(c, err ?? 'تم تحديث موقعك ✓');
                },
                child: const Text('تحديث موقعي'),
              ),
            ]),
          ),
          if (store.isOwner) ...[
            const _Title('أدوات المالك'),
            Panel(
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.upload_rounded),
                title: const Text('نسخ بيانات الخطوط والمحطات'),
                subtitle: const Text('نسخة JSON احتياطية.'),
                onTap: () async {
                  await Clipboard.setData(ClipboardData(text: store.exportNetworkJson()));
                  if (c.mounted) snack(c, 'تم النسخ إلى الحافظة.');
                },
              ),
            ),
          ],
          const _Title('حول التطبيق'),
          Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('$kAppName — الإصدار $kVersion', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(
                'الخريطة © مساهمو OpenStreetMap — هندسة الطرق من OSRM.',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant, height: 1.6),
              ),
            ]),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 50,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: cs.error),
              icon: const Icon(Icons.logout_rounded),
              label: const Text('تسجيل الخروج', style: TextStyle(fontWeight: FontWeight.w800)),
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: c,
                  builder: (d) => AlertDialog(
                    content: const Text('تسجيل الخروج من الحساب؟'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
                      FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('خروج')),
                    ],
                  ),
                );
                if (ok == true) {
                  navIndex.value = 0;
                  await store.signOut();
                }
              },
            ),
          ),
        ]);
      },
    );
  }
}

class _Title extends StatelessWidget {
  const _Title(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
      child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: kBrand)),
    );
  }
}
