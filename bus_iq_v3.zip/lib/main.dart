import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'config.dart';
import 'core/models.dart';
import 'core/theme.dart';
import 'data/store.dart';
import 'ui/account.dart';
import 'ui/auth.dart';
import 'ui/common.dart';
import 'ui/driver.dart';
import 'ui/owner.dart';
import 'ui/passenger.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  store = AppStore();
  await store.initLocal();
  runApp(const BusIqApp());
  unawaited(store.initRemote());
}

class BusIqApp extends StatelessWidget {
  const BusIqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: store.themeMode,
      builder: (context, mode, _) {
        return MaterialApp(
          navigatorKey: navKey,
          debugShowCheckedModeBanner: false,
          title: kAppName,
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: mode,
          home: const Gate(),
        );
      },
    );
  }
}

/// يوجّه المستخدم حسب حالته ودوره.
class Gate extends StatelessWidget {
  const Gate({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        switch (store.phase) {
          case AppPhase.loading:
            return const SplashPage();
          case AppPhase.signedOut:
            return const AuthPage();
          case AppPhase.ready:
            final me = store.me;
            if (me == null) return const SplashPage();
            if (me.role == Role.driver && !me.approved) return const PendingPage();
            return Shell(key: ValueKey<String>(me.id));
        }
      },
    );
  }
}

class _Tab {
  const _Tab(this.label, this.icon, this.page);
  final String label;
  final IconData icon;
  final Widget page;
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  StreamSubscription<String>? _sub;

  @override
  void initState() {
    super.initState();
    _sub = store.messages.listen((m) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  List<_Tab> _tabs(Role r) {
    switch (r) {
      case Role.passenger:
        return const [
          _Tab('الخريطة', Icons.map_rounded, MapPage()),
          _Tab('الخطوط', Icons.route_rounded, LinesPage()),
          _Tab('رحلاتي', Icons.confirmation_number_rounded, RidesPage()),
          _Tab('حسابي', Icons.person_rounded, AccountPage()),
        ];
      case Role.driver:
        return const [
          _Tab('رحلتي', Icons.directions_bus_rounded, DriverPage()),
          _Tab('أرباحي', Icons.savings_rounded, DriverEarningsPage()),
          _Tab('حسابي', Icons.person_rounded, AccountPage()),
        ];
      case Role.owner:
        return const [
          _Tab('اللوحة', Icons.dashboard_rounded, OwnerDashboard()),
          _Tab('الأسطول', Icons.directions_bus_filled_rounded, FleetPage()),
          _Tab('الخطوط', Icons.add_road_rounded, LinesAdminPage()),
          _Tab('المالية', Icons.account_balance_wallet_rounded, FinancePage()),
          _Tab('حسابي', Icons.person_rounded, AccountPage()),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final role = store.role;
    final tabs = _tabs(role);
    return ValueListenableBuilder<int>(
      valueListenable: navIndex,
      builder: (context, idx, _) {
        final i = idx < 0 ? 0 : (idx >= tabs.length ? tabs.length - 1 : idx);
        return Scaffold(
          appBar: AppBar(
            titleSpacing: 16,
            title: const Row(children: [
              BrandMark(size: 34),
              SizedBox(width: 10),
              Text(kAppName, style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
            ]),
            actions: [
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 14),
                child: Pill(roleLabel(role), Theme.of(context).colorScheme.primary, icon: roleIcon(role)),
              ),
            ],
          ),
          body: IndexedStack(index: i, children: [for (final t in tabs) t.page]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: i,
            onDestinationSelected: (v) => navIndex.value = v,
            destinations: [
              for (final t in tabs) NavigationDestination(icon: Icon(t.icon), label: t.label),
            ],
          ),
        );
      },
    );
  }
}
