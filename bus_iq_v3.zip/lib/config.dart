/// تُمرَّر القيم وقت البناء عبر GitHub Secrets (انظر build-apk.yml).
const String kSupabaseUrl = String.fromEnvironment('SUPABASE_URL');
const String kSupabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');

bool get kBackendConfigured => kSupabaseUrl.isNotEmpty && kSupabaseKey.isNotEmpty;

const String kAppName = 'BUS.IQ';
const String kVersion = '1.0.0';
