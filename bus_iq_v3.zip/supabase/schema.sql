-- ════════════════════════════════════════════════════════════
--  BUS.IQ — قاعدة البيانات (Supabase / PostgreSQL)
--  الصق هذا الملف كاملاً في: SQL Editor ← New query ← Run (مرة واحدة)
-- ════════════════════════════════════════════════════════════

-- ───────── الجداول ─────────

create table if not exists public.profiles (
  id             uuid primary key references auth.users(id) on delete cascade,
  role           text not null default 'passenger' check (role in ('passenger','driver','owner')),
  name           text not null default '',
  phone          text not null default '',
  approved       boolean not null default true,      -- السائق يحتاج موافقة المالك
  active         boolean not null default true,      -- إيقاف الحساب
  driver_percent numeric(5,2) check (driver_percent between 0 and 100),  -- null = النسبة الافتراضية
  created_at     timestamptz not null default now()
);

create table if not exists public.buses (
  id          uuid primary key default gen_random_uuid(),
  number      text not null,
  line_id     text not null default '',
  driver_id   uuid references public.profiles(id) on delete set null,
  driver_name text not null default '',
  capacity    int  not null default 30,
  online      boolean not null default false,
  fault       boolean not null default false,
  onboard     int  not null default 0,
  lat         double precision,
  lng         double precision,
  speed       double precision not null default 0,
  updated_at  timestamptz not null default now()
);

-- مفاتيح: 'network' (المحطات والخطوط) و 'settings' (النسبة الافتراضية وحسابات الدفع)
create table if not exists public.config (
  key        text primary key,
  value      jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.tickets (
  id             uuid primary key default gen_random_uuid(),
  created_at     timestamptz not null default now(),
  passenger_id   uuid references public.profiles(id) on delete set null,
  passenger_name text not null default '',
  bus_id         uuid references public.buses(id) on delete set null,
  bus_number     text not null default '',
  line_id        text not null default '',
  line_name      text not null default '',
  driver_id      uuid references public.profiles(id) on delete set null,
  fare           int  not null check (fare >= 0),
  method         text not null check (method in ('cash','zaincash','fastpay','qi','asiapay')),
  ref            text not null default '',
  status         text not null default 'pending' check (status in ('pending','paid','cancelled')),
  percent        numeric(5,2) not null,
  driver_share   int  not null,
  owner_share    int  not null,
  confirmed_at   timestamptz,
  confirmed_by   uuid references public.profiles(id) on delete set null
);
create index if not exists tickets_created_idx on public.tickets (created_at desc);
create index if not exists tickets_driver_idx  on public.tickets (driver_id);
create index if not exists tickets_pass_idx    on public.tickets (passenger_id);

-- amount > 0: السائق دفع للإدارة   |   amount < 0: الإدارة دفعت للسائق
create table if not exists public.settlements (
  id         uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  driver_id  uuid not null references public.profiles(id) on delete cascade,
  amount     int  not null,
  note       text not null default '',
  created_by uuid references public.profiles(id) on delete set null
);

create table if not exists public.reports (
  id         uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  bus_id     uuid references public.buses(id) on delete set null,
  bus_number text not null default '',
  driver_id  uuid references public.profiles(id) on delete set null,
  type       text not null,
  note       text not null default '',
  is_fault   boolean not null default false,
  resolved   boolean not null default false
);

-- ───────── دوال مساعدة ─────────

create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'owner' and active);
$$;

-- إنشاء الملف الشخصي تلقائياً عند التسجيل (لا يمكن اختيار دور المالك من التطبيق)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare r text;
begin
  r := case when new.raw_user_meta_data->>'role' = 'driver' then 'driver' else 'passenger' end;
  insert into public.profiles (id, role, name, phone, approved)
  values (
    new.id, r,
    coalesce(new.raw_user_meta_data->>'name', ''),
    coalesce(new.raw_user_meta_data->>'phone', ''),
    (r = 'passenger')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ───────── دوال التطبيق (آمنة: تتحقق من الصلاحية وتحسب المبالغ في الخادم) ─────────

-- إنشاء تذكرة ركوب. السائق يستطيع إنشاء تذكرة "راكب نقدي" بدون حساب (p_walkup).
create or replace function public.create_ticket(
  p_bus uuid, p_method text, p_ref text default '', p_walkup boolean default false
) returns uuid language plpgsql security definer set search_path = public as $$
declare
  b public.buses;
  me public.profiles;
  v_fare int;
  v_line text;
  v_pct numeric;
  v_ds int;
  v_id uuid;
  v_status text := 'pending';
  v_pname text;
  v_pid uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  select * into me from public.profiles where id = auth.uid() and active;
  if not found then raise exception 'account disabled'; end if;
  select * into b from public.buses where id = p_bus;
  if not found then raise exception 'bus not found'; end if;

  select (l->>'fare')::int, l->>'name' into v_fare, v_line
  from public.config c cross join lateral jsonb_array_elements(c.value->'lines') as l
  where c.key = 'network' and l->>'id' = b.line_id
  limit 1;
  if v_fare is null then raise exception 'bus has no line'; end if;

  select coalesce(
    (select driver_percent from public.profiles where id = b.driver_id),
    (select (value->>'default_percent')::numeric from public.config where key = 'settings'),
    70
  ) into v_pct;
  v_ds := round(v_fare * v_pct / 100.0);

  if p_walkup then
    if b.driver_id is distinct from auth.uid() then raise exception 'only the bus driver can add walk-up tickets'; end if;
    p_method := 'cash'; v_status := 'paid'; v_pname := 'راكب نقدي'; v_pid := null;
  else
    if me.role <> 'passenger' and me.role <> 'owner' then raise exception 'only passengers can book'; end if;
    v_pname := me.name; v_pid := auth.uid();
  end if;

  insert into public.tickets (passenger_id, passenger_name, bus_id, bus_number, line_id, line_name, driver_id,
                              fare, method, ref, status, percent, driver_share, owner_share, confirmed_at, confirmed_by)
  values (v_pid, v_pname, b.id, b.number, b.line_id, v_line, b.driver_id,
          v_fare, p_method, left(coalesce(p_ref, ''), 60), v_status, v_pct, v_ds, v_fare - v_ds,
          case when v_status = 'paid' then now() end,
          case when v_status = 'paid' then auth.uid() end)
  returning id into v_id;
  return v_id;
end;
$$;

-- تأكيد استلام الدفع: السائق للنقد فقط، والمالك لكل شيء
create or replace function public.confirm_ticket(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t public.tickets;
begin
  select * into t from public.tickets where id = p_id;
  if not found then raise exception 'ticket not found'; end if;
  if t.status <> 'pending' then return; end if;
  if not (public.is_owner() or (t.driver_id = auth.uid() and t.method = 'cash')) then
    raise exception 'not allowed';
  end if;
  update public.tickets set status = 'paid', confirmed_at = now(), confirmed_by = auth.uid() where id = p_id;
end;
$$;

create or replace function public.cancel_ticket(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t public.tickets;
begin
  select * into t from public.tickets where id = p_id;
  if not found then raise exception 'ticket not found'; end if;
  if t.status <> 'pending' then return; end if;
  if not (public.is_owner() or t.passenger_id = auth.uid() or (t.driver_id = auth.uid() and t.method = 'cash')) then
    raise exception 'not allowed';
  end if;
  update public.tickets set status = 'cancelled', confirmed_at = now(), confirmed_by = auth.uid() where id = p_id;
end;
$$;

-- السائق يحدّث موقع باصه وحالته فقط
create or replace function public.driver_update_bus(
  p_lat double precision default null, p_lng double precision default null,
  p_speed double precision default null, p_onboard int default null, p_online boolean default null
) returns void language plpgsql security definer set search_path = public as $$
begin
  update public.buses set
    lat = coalesce(p_lat, lat),
    lng = coalesce(p_lng, lng),
    speed = coalesce(p_speed, speed),
    onboard = coalesce(p_onboard, onboard),
    online = coalesce(p_online, online),
    updated_at = now()
  where driver_id = auth.uid()
    and exists (select 1 from public.profiles where id = auth.uid() and role = 'driver' and approved and active);
end;
$$;

create or replace function public.driver_report(p_type text, p_note text default '', p_fault boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare b public.buses;
begin
  select * into b from public.buses where driver_id = auth.uid() limit 1;
  if not found then raise exception 'no bus assigned'; end if;
  insert into public.reports (bus_id, bus_number, driver_id, type, note, is_fault)
  values (b.id, b.number, auth.uid(), p_type, left(coalesce(p_note, ''), 300), p_fault);
  if p_fault then update public.buses set fault = true where id = b.id; end if;
end;
$$;

create or replace function public.resolve_report(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare r public.reports;
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  select * into r from public.reports where id = p_id;
  if not found then return; end if;
  update public.reports set resolved = true where id = p_id;
  if r.is_fault and r.bus_id is not null
     and not exists (select 1 from public.reports where bus_id = r.bus_id and is_fault and not resolved) then
    update public.buses set fault = false where id = r.bus_id;
  end if;
end;
$$;

-- ───────── ملخص حسابات السائقين ─────────
-- net > 0: على السائق للإدارة   |   net < 0: للسائق على الإدارة
create or replace view public.driver_balances with (security_invoker = true) as
select
  p.id as driver_id,
  p.name,
  p.phone,
  count(t.id) filter (where t.status = 'paid') as rides,
  coalesce(sum(t.fare)         filter (where t.status = 'paid'), 0) as gross,
  coalesce(sum(t.driver_share) filter (where t.status = 'paid'), 0) as driver_total,
  coalesce(sum(t.owner_share)  filter (where t.status = 'paid' and t.method = 'cash'), 0)
    - coalesce(sum(t.driver_share) filter (where t.status = 'paid' and t.method <> 'cash'), 0)
    - coalesce((select sum(s.amount) from public.settlements s where s.driver_id = p.id), 0) as net
from public.profiles p
left join public.tickets t on t.driver_id = p.id
where p.role = 'driver'
group by p.id, p.name, p.phone;

-- ───────── الصلاحيات (Row Level Security) ─────────

alter table public.profiles    enable row level security;
alter table public.buses       enable row level security;
alter table public.config      enable row level security;
alter table public.tickets     enable row level security;
alter table public.settlements enable row level security;
alter table public.reports     enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_owner());
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
  using (public.is_owner()) with check (public.is_owner());

drop policy if exists buses_select on public.buses;
create policy buses_select on public.buses for select to authenticated using (true);
drop policy if exists buses_owner_write on public.buses;
create policy buses_owner_write on public.buses for all to authenticated
  using (public.is_owner()) with check (public.is_owner());

drop policy if exists config_select on public.config;
create policy config_select on public.config for select to authenticated using (true);
drop policy if exists config_owner_write on public.config;
create policy config_owner_write on public.config for all to authenticated
  using (public.is_owner()) with check (public.is_owner());

drop policy if exists tickets_select on public.tickets;
create policy tickets_select on public.tickets for select to authenticated
  using (passenger_id = auth.uid() or driver_id = auth.uid() or public.is_owner());

drop policy if exists settlements_select on public.settlements;
create policy settlements_select on public.settlements for select to authenticated
  using (driver_id = auth.uid() or public.is_owner());
drop policy if exists settlements_insert on public.settlements;
create policy settlements_insert on public.settlements for insert to authenticated
  with check (public.is_owner());

drop policy if exists reports_select on public.reports;
create policy reports_select on public.reports for select to authenticated
  using (driver_id = auth.uid() or public.is_owner());

-- منع الاستدعاء من غير المسجّلين
revoke all on function public.create_ticket(uuid, text, text, boolean) from public, anon;
revoke all on function public.confirm_ticket(uuid) from public, anon;
revoke all on function public.cancel_ticket(uuid) from public, anon;
revoke all on function public.driver_update_bus(double precision, double precision, double precision, int, boolean) from public, anon;
revoke all on function public.driver_report(text, text, boolean) from public, anon;
revoke all on function public.resolve_report(uuid) from public, anon;
grant execute on function public.create_ticket(uuid, text, text, boolean) to authenticated;
grant execute on function public.confirm_ticket(uuid) to authenticated;
grant execute on function public.cancel_ticket(uuid) to authenticated;
grant execute on function public.driver_update_bus(double precision, double precision, double precision, int, boolean) to authenticated;
grant execute on function public.driver_report(text, text, boolean) to authenticated;
grant execute on function public.resolve_report(uuid) to authenticated;
grant select on public.driver_balances to authenticated;

-- ───────── بيانات أولية ─────────

insert into public.config (key, value) values
  ('network',  '{"stops": [], "lines": []}'::jsonb),
  ('settings', '{"default_percent": 70, "wallets": {"zaincash": "", "fastpay": "", "qi": "", "asiapay": ""}}'::jsonb)
on conflict (key) do nothing;

-- ════════════════════════════════════════════════════════════
--  حساب المالك (نفّذه بعد أن تسجّل حسابك من التطبيق مرة واحدة):
--
--  update public.profiles set role = 'owner', approved = true
--  where phone = '07XXXXXXXXX';      -- ← رقم هاتفك الذي سجّلت به
-- ════════════════════════════════════════════════════════════
